/* 鬼怪详情 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { qs, esc, icon, ghostLevelCls, statusCls, badge } = window.YG;

  const g = D.GHOSTS.find(x => x.id === qs("id"));
  const box = document.getElementById("detail");

  document.getElementById("backBtn").addEventListener("click", () => {
    if (history.length > 1) history.back();
    else location.href = "ghosts.html";
  });

  if (!g) {
    box.innerHTML = `<div class="glass empty" style="border-radius:14px">未找到该鬼怪档案 <a href="ghosts.html" class="text-cyan" style="margin-left:10px">返回图鉴</a></div>`;
    return;
  }

  const cls = ghostLevelCls(g.level);
  const lvInfo = D.GHOST_LEVELS.find(l => l.name === g.level);

  // 已契约的鬼灵状态覆写为「已契约」
  const { MyGhosts, Profiles } = window.YG;
  const me = Profiles.current();
  const owned = me && MyGhosts.all(me.id).list.some(mg => mg.gid === g.id);
  const effStatus = owned ? "已契约" : g.status;

  document.title = g.name + " · 鬼怪图鉴 · 全国御鬼者管控系统";

  box.innerHTML = `
    <div class="detail-hero">
      <div class="glass corner detail-rune-box ${cls}">
        <img class="ghost-detail-img" src="${g.img}" alt="${esc(g.name)}">
        <div class="code">${g.id}</div>
        ${badge(cls, g.level)}
      </div>
      <div class="glass corner detail-main">
        <h1>${esc(g.name)} ${owned ? badge("st-已完成", "已契约") : badge(statusCls(g.status), g.status)}</h1>
        <div class="detail-tags">
          <span class="text-muted" style="font-size:13px">威胁层级</span>
          <span class="badge ${cls}" style="font-size:13px">第 ${lvInfo.order} 级 · ${g.level}</span>
        </div>
        <div class="info-grid" style="margin-top:22px">
          <div class="info-block glass" style="animation-delay:.05s">
            <div class="ib-title">${icon("ghost")} 核心能力</div>
            <p>${esc(g.ability)}</p>
          </div>
          <div class="info-block glass" style="animation-delay:.12s">
            <div class="ib-title">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3 5 20h14L12 3Z"/></svg>
              克制弱点
            </div>
            <p>${esc(g.weakness)}</p>
          </div>
          <div class="info-block glass" style="animation-delay:.19s">
            <div class="ib-title">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s-7-6.4-7-11a7 7 0 0 1 14 0c0 4.6-7 11-7 11Z"/><circle cx="12" cy="10" r="2.5"/></svg>
              出没区域
            </div>
            <p>${esc(g.area)}</p>
          </div>
          <div class="info-block glass" style="animation-delay:.26s">
            <div class="ib-title">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
              当前状态
            </div>
            <p>${badge(statusCls(g.status), g.status)} <span class="text-muted" style="margin-left:8px;font-size:12.5px">数据每小时同步全国档案库</span></p>
          </div>
          <div class="info-block glass full" style="animation-delay:.33s">
            <div class="ib-title">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>
              历史事件记录
            </div>
            <p>${esc(g.event)}</p>
          </div>
          <div class="info-block glass full" style="animation-delay:.4s">
            <div class="ib-title">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3 5 20h14L12 3Z"/><path d="M12 10v4"/></svg>
              镇压处置建议
            </div>
            <p>${esc(g.advice)}</p>
          </div>
        </div>
      </div>
    </div>
  `;
})();

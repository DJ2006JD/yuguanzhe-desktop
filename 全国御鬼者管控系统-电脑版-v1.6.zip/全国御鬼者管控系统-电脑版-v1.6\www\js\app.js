/* ============================================================
   全国御鬼者管控系统 · 核心框架
   LocalStorage 鉴权 / 权限守卫 / 布局注入 / 通用工具
   ============================================================ */
(function () {
  "use strict";

  const D = window.YG_DATA;
  const LS = {
    USERS: "ygu_users",
    SESSION: "ygu_session",
    TASKS: "ygu_tasks_",
    EROSION: "ygu_erosion_",
    ITEMS: "ygu_items_",
    PROMOTIONS: "ygu_promos_",
    EXTRA_MISSIONS: "ygu_extra_missions_",
    MISSION_SEQ: "ygu_mission_seq",
    COINS: "ygu_coins_",
    MYGHOSTS: "ygu_ghosts_"
  };

  /* ---------------- 数据同步层 ----------------
     单机版：不加载 net-sync.js，Net 为空，全部走本地分支。
     联网版：net-sync.js 先于本文件加载并注入 window.__YG_NET__（MQTT/WSS 键值同步）。 */
  const Net = (typeof window !== "undefined") ? window.__YG_NET__ : null;

  /* ---------------- 存储层 ---------------- */
  const Store = {
    get(key, def) {
      try { const v = localStorage.getItem(key); return v === null ? def : JSON.parse(v); }
      catch (e) { return def; }
    },
    set(key, val) { localStorage.setItem(key, JSON.stringify(val)); Sync.onSet(key, val); },
    remove(key) { localStorage.removeItem(key); Sync.onRemove(key); }
  };

  const Sync = Net ? {
    online: true,
    ready: Net.ready,
    applying: false, // 接收远端写入期间置真，防止回声再次外发
    boot() {},
    onSet(key, val) { if (!this.applying) Net.put(key, val); },
    onRemove(key) { if (!this.applying) Net.del(key); },
    registerUser(u) { return Net.registerUser(u); },
    deleteUser(id) { Net.deleteUser(id); },
    postLogin(id, pw) { return Net.postLogin(id, pw); }
  } : {
    /* 纯本地单机：所有账号与存档仅保存在本机 localStorage，不连接任何服务器 */
    online: false,
    ready: Promise.resolve(),
    applying: false,
    boot() {},
    onSet() {},
    onRemove() {},
    registerUser() { return Promise.resolve({ ok: true, offline: true }); },
    deleteUser() {},
    postLogin() { return Promise.resolve(null); }
  };

  // 联网层通过这两个桥接方法把远端数据静默写入本机（不触发回声发布）
  if (Net) Net.bind({
    applySet(k, v) {
      Sync.applying = true;
      try { localStorage.setItem(k, JSON.stringify(v)); }
      finally { Sync.applying = false; }
    },
    applyRemove(k) {
      Sync.applying = true;
      try { localStorage.removeItem(k); }
      finally { Sync.applying = false; }
    }
  });

  /* ---------------- 账号体系 ---------------- */
  // 部门最高领导种子档案（YG-0002 起连号，统一登录密钥 666666，自动内置可登录）
  const LEADER_PWD = "666666";
  function leaderSeeds() { return (D.SEED_PROFILES || []).filter(p => p.leader); }

  const Users = {
    all() {
      let users = Store.get(LS.USERS, null);
      const boss = {
        id: "YG-0001", name: "很困", password: "123789",
        bureau: "全国灵异管控总局", createdAt: "2019-06-01"
      };
      if (!users) {
        // 初始内置最高权限账号 + 各部门领导账号
        users = [boss].concat(leaderSeeds().map(p => ({
          id: p.id, name: p.name, password: LEADER_PWD,
          bureau: p.bureau, createdAt: p.joinDate
        })));
        Store.set(LS.USERS, users);
        return users;
      }
      // 迁移：移除旧演示账号 YG-1000，确保 YG-0001 与各部门领导存在且信息/密钥正确
      let changed = false;
      const before = users.length;
      // 被最高权限账号手动删除的领导账号（结构种子）不再自动重建
      const removedIds = Store.get("ygu_removed_users", []);
      users = users.filter(u => u.id !== "YG-1000" && !removedIds.includes(u.id));
      if (users.length !== before) changed = true;
      const found = users.find(u => u.id === "YG-0001");
      if (!found) { users.unshift(boss); changed = true; }
      else if (found.password !== boss.password || found.name !== boss.name || found.bureau !== boss.bureau) { found.password = boss.password; found.name = boss.name; found.bureau = boss.bureau; changed = true; }
      // 部门领导账号补齐 / 信息校正（编号、密钥、部门以种子档案为准，不可被注册覆盖；已删除者不重建）
      leaderSeeds().forEach(p => {
        if (removedIds.includes(p.id)) return;
        const u = users.find(x => x.id === p.id);
        if (!u) {
          users.push({ id: p.id, name: p.name, password: LEADER_PWD, bureau: p.bureau, createdAt: p.joinDate });
          changed = true;
        } else if (u.password !== LEADER_PWD || u.name !== p.name || u.bureau !== p.bureau) {
          u.password = LEADER_PWD; u.name = p.name; u.bureau = p.bureau;
          changed = true;
        }
      });
      if (changed) Store.set(LS.USERS, users);
      return users;
    },
    // 生成系统随机编号（YG-XXXX，不与现有账号/种子档案/保留编号冲突）
    genId() {
      const taken = new Set(this.all().map(u => u.id));
      (window.YG_DATA.SEED_PROFILES || []).forEach(p => taken.add(p.id));
      taken.add("YG-1000"); // 旧演示编号永久保留，不再发放
      let id;
      do { id = "YG-" + String(Math.floor(1101 + Math.random() * 8899)); } while (taken.has(id));
      return id;
    },
    find(id) { return this.all().find(u => u.id === id); },
    // 返回云端结果 Promise：{ok:true} / {ok:false,err:'exists'} / null=离线（本地已先写入）
    add(u) {
      const users = this.all();
      if (!users.some(x => x.id === u.id)) { users.push(u); Store.set(LS.USERS, users); }
      return Sync.registerUser(u).then(r => {
        if (r && r.ok === false) {
          // 云端已存在同名编号（其他设备先注册）：回滚本地这条
          Store.set(LS.USERS, (r.users || Store.get(LS.USERS, [])));
        }
        return r || { ok: true, offline: true };
      });
    },
    remove(id, force) {
      if (id === "YG-0001") return false; // 最高权限账号不可删除
      // 部门领导账号默认受保护；最高权限账号可强制删除（force=true），删除后不再自动重建
      if (!force && leaderSeeds().some(p => p.id === id)) return false;
      Store.set(LS.USERS, this.all().filter(u => u.id !== id));
      if (force && leaderSeeds().some(p => p.id === id)) {
        const rm = Store.get("ygu_removed_users", []);
        if (!rm.includes(id)) { rm.push(id); Store.set("ygu_removed_users", rm); }
      }
      Sync.deleteUser(id);
      return true;
    },
    login(id, password) {
      const u = this.find(id);
      return u && u.password === password ? u : null;
    }
  };

  const Session = {
    get() { return Store.get(LS.SESSION, null); },
    set(userId) { Store.set(LS.SESSION, userId); },
    clear() { Store.remove(LS.SESSION); }
  };

  /* ---------------- 道具背包 ---------------- */
  const Inventory = {
    key(uid) { return LS.ITEMS + uid; },
    all(uid) {
      const def = { EQ013: 1, EQ014: 1 };
      return Store.get(this.key(uid), def);
    },
    count(uid, eqId) { return this.all(uid)[eqId] || 0; },
    add(uid, eqId, n = 1) {
      const all = this.all(uid);
      all[eqId] = (all[eqId] || 0) + n;
      Store.set(this.key(uid), all);
    },
    consume(uid, eqId) {
      const all = this.all(uid);
      if (!all[eqId]) return false;
      all[eqId]--;
      if (all[eqId] <= 0) delete all[eqId];
      Store.set(this.key(uid), all);
      return true;
    }
  };

  /* ---------------- 冥币（阴司通货） ---------------- */
  const Coins = {
    key(uid) { return LS.COINS + uid; },
    get(uid) { return Store.get(this.key(uid), 100); }, // 新账号初始 100 冥币
    set(uid, v) { Store.set(this.key(uid), Math.max(0, Math.round(v))); },
    add(uid, n) { this.set(uid, this.get(uid) + n); },
    spend(uid, n) {
      if (this.get(uid) < n) return false;
      this.set(uid, this.get(uid) - n);
      return true;
    }
  };

  /* ---------------- 契约鬼灵仓库 ---------------- */
  const MyGhosts = {
    key(uid) { return LS.MYGHOSTS + uid; },
    // 最高权限账号契约鬼灵固定为高等级阵容（鬼王/鬼帅/鬼将）
    BOSS_GHOSTS: ["G013", "G011", "G009"],
    all(uid) {
      // 首次访问：从种子档案迁移契约列表进仓库，此后仓库为唯一数据源
      let list = Store.get(this.key(uid), null);
      if (list === null) {
        const seed = D.SEED_PROFILES.find(p => p.id === uid);
        list = (seed ? seed.ghostIds : [])
          .filter(gid => D.GHOSTS.some(g => g.id === gid))
          .map(gid => ({
            gid,
            nick: (D.GHOSTS.find(g => g.id === gid) || {}).name || gid,
            hunger: 80, date: (seed && seed.joinDate) || today(), lastFed: today(), lastTs: Date.now()
          }));
        Store.set(this.key(uid), list);
      }
      // YG-0001：强制高等级鬼灵阵容（保留已有喂养状态）
      if (uid === "YG-0001") {
        const keep = {};
        list.forEach(g => { keep[g.gid] = g; });
        list = this.BOSS_GHOSTS.filter(gid => D.GHOSTS.some(g => g.id === gid)).map(gid =>
          keep[gid] || { gid, nick: (D.GHOSTS.find(g => g.id === gid) || {}).name || gid, hunger: 90, date: "2019-06-01", lastFed: today(), lastTs: Date.now() }
        );
        Store.set(this.key(uid), list);
      }
      let changed = false;
      const now = today();
      const nowTs = Date.now();
      let erosionDrift = 0;
      const exploring = Explore.activeGids(uid); // 探索中的鬼灵：饥饿加速
      list.forEach(g => {
        // 迁移：旧数据无 lastTs 时按 lastFed/date 的日界零点补齐
        if (!g.lastTs) g.lastTs = new Date(g.lastFed || g.date || now).getTime();
        // 按真实毫秒差连续衰减：6 点/天；探索中 4 倍加速
        const rate = exploring.has(g.gid) ? 24 : 6; // 点/天
        const loss = (nowTs - g.lastTs) * rate / 86400000;
        if (loss >= 0.1) {
          const nh = Math.max(0, Math.round((g.hunger - loss) * 10) / 10);
          if (Math.floor(nh) !== Math.floor(g.hunger)) changed = true;
          g.hunger = Math.round(nh);
          g.lastTs = nowTs;
          if (g.lastFed !== now) {
            const days = Math.floor((new Date(now) - new Date(g.lastFed || now)) / 86400000);
            if (days > 0) { erosionDrift += days * 2; g.lastFed = now; }
          }
          changed = true;
        }
      });
      if (erosionDrift > 0) Erosion.add(uid, erosionDrift);
      // 逃逸判定：饱食度归零必定逃逸；≤20 进入反噬状态，每日按 35% 概率挣脱契约
      const escaped = [];
      const kept = [];
      list.forEach(g => {
        if (g.hunger <= 0) { escaped.push(g.gid); return; }
        if (g.hunger <= 20) {
          const roll = seededRand(g.gid + "|" + now)();
          if (roll < 0.35) { escaped.push(g.gid); return; }
        }
        kept.push(g);
      });
      if (escaped.length) {
        Store.set(this.key(uid), kept);
        // 反噬伤害：按鬼怪等阶施加侵蚀度冲击
        let backlash = 0;
        escaped.forEach(gid => {
          const g = D.GHOSTS.find(x => x.id === gid);
          const order = g ? ((D.GHOST_LEVELS.find(l => l.name === g.level) || {}).order || 1) : 1;
          backlash += order * 3 + 2; // 游魂 +5 → 鬼王 +23
        });
        if (backlash > 0) Erosion.add(uid, backlash);
        return { list: kept, escaped, backlash };
      }
      if (changed) Store.set(this.key(uid), list);
      return { list, escaped: [] };
    },
    limit(uid) {
      const rank = D.RANKS[GameState.effectiveRankIdx(uid)];
      return parseInt(rank.ghostLimit) || 1;
    },
    add(uid, gid) {
      const { list } = this.all(uid);
      if (list.length >= this.limit(uid)) return false;
      if (list.some(g => g.gid === gid)) return false;
      const g = D.GHOSTS.find(x => x.id === gid);
      list.push({ gid, nick: g ? g.name : gid, hunger: 80, date: today(), lastFed: today() });
      Store.set(this.key(uid), list);
      return true;
    },
    remove(uid, gid) {
      const { list } = this.all(uid);
      Store.set(this.key(uid), list.filter(g => g.gid !== gid));
    },
    feed(uid, gid, amount) {
      const { list } = this.all(uid);
      const g = list.find(x => x.gid === gid);
      if (!g) return false;
      g.hunger = Math.min(100, g.hunger + amount);
      g.lastFed = today();
      g.lastTs = Date.now();
      Store.set(this.key(uid), list);
      return true;
    },
    rename(uid, gid, nick) {
      const { list } = this.all(uid);
      const g = list.find(x => x.gid === gid);
      if (!g) return false;
      g.nick = nick.slice(0, 10) || g.nick;
      Store.set(this.key(uid), list);
      return true;
    }
  };

  /* ---------------- 探索机缘（契约鬼灵外出探索） ---------------- */
  const Explore = {
    key(uid) { return "ygu_explore_" + uid; },
    get(uid) { return Store.get(this.key(uid), []); },
    set(uid, arr) { Store.set(this.key(uid), arr); },
    activeGids(uid) {
      const now = Date.now();
      return new Set(this.get(uid).filter(e => e.end > now).map(e => e.gid));
    },
    // 开始探索：时长秒数，结束时间，返回本次探索记录
    start(uid, gid, durSec) {
      const now = Date.now();
      const arr = this.get(uid).filter(e => e.end > now); // 清理过期
      if (arr.some(e => e.gid === gid)) return null; // 已在探索
      arr.push({ gid, start: now, end: now + durSec * 1000, dur: durSec });
      this.set(uid, arr);
      return arr[arr.length - 1];
    },
    // 结算所有已完成的探索，返回 {gid, tier, rewards} 列表
    settle(uid) {
      const now = Date.now();
      const all = this.get(uid);
      const done = all.filter(e => e.end <= now);
      const active = all.filter(e => e.end > now);
      if (done.length) this.set(uid, active);
      const results = done.map(e => {
        const tier = this.tier(e.dur);
        const r = this.rollReward(uid, tier);
        return { gid: e.gid, tier, rewards: r };
      });
      return results;
    },
    tier(dur) {
      if (dur >= 180) return 3; // 3min
      if (dur >= 120) return 2; // 2min
      if (dur >= 60) return 1;  // 1min
      return 0;                 // 30s
    },
    tierLabel(t) {
      return ["短暂 · 30秒", "深入 · 1分钟", "远遁 · 2分钟", "幽境 · 3分钟"][t] || "";
    },
    rollReward(uid, tier) {
      const rnd = seededRand(uid + "_explore_" + Date.now());
      const rewards = [];
      // 冥币
      const coins = Math.round((50 + tier * 80) * (0.8 + rnd() * 0.4));
      Coins.add(uid, coins);
      rewards.push({ type: "coin", val: coins });
      // 积分
      const pts = Math.round((10 + tier * 15) * (0.8 + rnd() * 0.4));
      const extras = GameState.extraMissions(uid);
      const mid = "EXPLORE-" + Date.now();
      extras.push({ id: mid, name: "鬼灵探索机缘", level: "D", place: "阴隙", points: pts, status: "已完成", desc: "契约鬼灵外出探索带回的阴能凝结" });
      GameState.setExtraMissions(uid, extras);
      const ts = TaskState.all(uid);
      ts[mid] = { status: "已完成", rating: "A", date: today() };
      Store.set(TaskState.key(uid), ts);
      rewards.push({ type: "pts", val: pts });
      // 概率道具：越高层级越稳
      const itemChance = [0.25, 0.45, 0.65, 0.85][tier] || 0;
      if (rnd() < itemChance) {
        const pool = ["EQ001", "EQ002", "EQ003", "EQ005", "EQ006", "EQ016"];
        const pick = pool[Math.floor(rnd() * pool.length)];
        Inventory.add(uid, pick, 1);
        rewards.push({ type: "item", id: pick });
      }
      return rewards;
    }
  };

  /* ---------------- 官职（符合条件后自行申请；满足更高职务条件可晋升改任） ---------------- */
  const Officials = {
    key(uid) { return "ygu_official_" + uid; },
    get(uid) { return Store.get(this.key(uid), null); }, // { oid, date }
    of(uid) {
      // 最高权限账号官职固定为最高（天御巡察使）
      if (uid === "YG-0001") return D.OFFICIALS.find(x => x.id === "OF6") || null;
      const o = this.get(uid);
      return o ? (D.OFFICIALS.find(x => x.id === o.oid) || null) : null;
    },
    // 已完成任务数（个人实际完成）
    missionsDone(uid) {
      const tasks = TaskState.all(uid);
      return Object.keys(tasks).filter(k => tasks[k].status === "已完成").length;
    },
    // 是否满足官职条件（有效品级/积分/任务数 + 机构层级匹配；YG-0001 豁免；OF6 天御巡察使为最高权限专属）
    qualified(uid, of) {
      if (uid === "YG-0001") return true;
      if (of.id === "OF6") return false; // 天御巡察使仅最高权限账号可任，其他人不可企及
      const pts = GameState.points(uid);
      const rankIdx = GameState.effectiveRankIdx(uid);
      if (!(rankIdx >= of.reqRankIdx && pts >= of.reqPoints && this.missionsDone(uid) >= of.reqMissions)) return false;
      return this.bureauOk(uid, of);
    },
    // 机构层级是否满足官职要求（总局直属可竞选所有下级官职）
    bureauOk(uid, of) {
      const prof = Profiles.find(uid);
      const tier = D.bureauTierOf(prof ? prof.bureau : "");
      return tier >= (of.reqTier || 0);
    },
    // 任职 / 晋升改任：一人一职；已有官职时仅允许改任「更高职务」（reqRankIdx 更高）
    grant(uid, oid) {
      const of = D.OFFICIALS.find(x => x.id === oid);
      if (!of || !this.qualified(uid, of)) return false;
      const cur = this.of(uid);
      if (cur) {
        if (cur.id === of.id) return false;
        if (of.reqRankIdx <= cur.reqRankIdx) return false; // 只允许向更高职务晋升
      }
      Store.set(this.key(uid), { oid, date: today() });
      return true;
    },
    // 档案监察权限等级：本人品级 + 官职 clearBonus（YG-0001 无限）
    clearance(uid) {
      if (uid === "YG-0001") return 99;
      const prof = Profiles.find(uid);
      const base = prof ? GameState.effectiveRankIdx(uid) : 0;
      const of = this.of(uid);
      return base + (of ? (of.clearBonus || 0) : 0);
    },
    // 是否可查看目标详细档案（含侵蚀曲线/契约鬼灵/战绩/晋升记录）
    canViewDetail(viewerId, targetId) {
      if (viewerId === targetId) return true;
      // YG-0001 最高权限账号档案仅本人可见：任何人（含品级更高者）均无法调阅
      if (targetId === "YG-0001") return viewerId === "YG-0001";
      if (viewerId === "YG-0001") return true;
      const target = Profiles.find(targetId);
      if (!target) return false;
      return this.clearance(viewerId) >= target.rankIdx;
    }
  };

  /* ---------------- 停职 / 复职 / 殉职 ---------------- */
  const Discipline = {
    // 侵蚀度 ≥70% 停职：禁止接取任务；净化后 <70% 自动复职（状态实时计算，无需人工干预）
    isSuspended(uid) {
      if (uid === "YG-0001" || seedLeader(uid)) return false; // 最高权限与部门领导豁免停职
      const prof = Profiles.find(uid);
      const val = prof ? Erosion.displayFor(prof) : Erosion.get(uid);
      return val >= 70;
    },
    // 殉职名单（侵蚀度≥90 销户后留存，管理员可在后台复活）
    deadList() { return Store.get("ygu_dead_list", []); },
    // 侵蚀度 ≥90% 殉职销户（最高权限账号与部门领导豁免）
    checkDeath(uid) {
      if (!uid || uid === "YG-0001" || seedLeader(uid)) return false;
      if (Erosion.get(uid) < 90) return false;
      const acc = Users.find(uid);
      if (acc) {
        const dead = this.deadList();
        if (!dead.some(d => d.id === uid)) {
          // 留存原密钥，复活时原样恢复，玩家无需换密码
          dead.unshift({ id: acc.id, name: acc.name, password: acc.password || "", bureau: acc.bureau || "", date: today() });
          Store.set("ygu_dead_list", dead);
        }
      }
      const users = Users.all().filter(u => u.id !== uid);
      Store.set(LS.USERS, users);
      Sync.deleteUser(uid); // 殉职销户同步到云端
      [LS.TASKS, LS.EROSION, LS.ITEMS, LS.PROMOTIONS, LS.EXTRA_MISSIONS, LS.COINS, LS.MYGHOSTS]
        .forEach(k => Store.remove(k + uid));
      Store.remove("ygu_rank_ack_" + uid);
      Store.remove("ygu_explore_" + uid);
      Store.remove(Officials.key(uid));
      if (Session.get() === uid) Session.clear();
      return true;
    },
    // 复活殉职账号：恢复登录（沿用原密钥；旧记录无密钥时回退 666666）、侵蚀度降至 50
    revive(uid) {
      const dead = this.deadList();
      const rec = dead.find(d => d.id === uid);
      if (!rec) return false;
      const list = Users.all();
      if (list.some(u => u.id === uid)) return false;
      // 必须持有同一数组引用再写回（Users.all() 每次返回新解析的数组）
      list.push({ id: rec.id, name: rec.name, password: rec.password || "666666", bureau: rec.bureau, createdAt: today() });
      Store.set(LS.USERS, list);
      Erosion.set(uid, 50);
      Store.set("ygu_dead_list", dead.filter(d => d.id !== uid));
      return true;
    }
  };

  /* ---------------- 侵蚀度（个人当前值） ---------------- */
  const Erosion = {
    key(uid) { return LS.EROSION + uid; },
    get(uid, fallbackBase) {
      const def = fallbackBase !== undefined ? fallbackBase : (uid === "YG-0001" ? 47 : 8);
      return Store.get(this.key(uid), def);
    },
    set(uid, v) { Store.set(this.key(uid), Math.max(0, Math.min(100, Math.round(v)))); },
    add(uid, delta) { this.set(uid, this.get(uid) + delta); },

    /* 档案展示用动态侵蚀度：在基准值上按日期确定性波动（每天不同），
       区间 [base-8, base+10]，并对高侵蚀者叠加缓慢恶化趋势 */
    display(uid, base) {
      const stored = Store.get(this.key(uid), null);
      const b = stored !== null ? stored : (base !== undefined ? base : 8);
      const day = today();
      const r1 = seededRand(uid + "_eroA_" + day)(); // 日内波动
      const r2 = seededRand(uid + "_eroB_" + day.slice(0, 7))(); // 月度趋势
      let v = b + (r1 - 0.5) * 16 + (r2 - 0.45) * 10;
      return Math.max(2, Math.min(96, Math.round(v)));
    },

    /* 档案展示用动态侵蚀度（按用户实体档案融合） */
    displayFor(prof) {
      const base = prof ? prof.seedErosion !== undefined ? prof.seedErosion : 8 : 8;
      return this.display(prof.id, base);
    }
  };

  /* ---------------- 游戏化状态：积分 / 晋升 / 任务生成 ---------------- */
  const GameState = {
    promoKey(uid) { return LS.PROMOTIONS + uid; },
    extraKey(uid) { return LS.EXTRA_MISSIONS + uid; },

    // 晋升记录（动态获取，初始为空）
    promotions(uid) { return Store.get(this.promoKey(uid), []); },
    addPromotion(uid, rec) {
      const arr = this.promotions(uid);
      arr.unshift(rec);
      Store.set(this.promoKey(uid), arr);
    },

    // 晋升难度配置（后台管理可调整；默认取 RANKS / PROMO_GHOST_REQ）
    rankCfgKey: "ygu_rank_cfg",
    rankCfg() { return Store.get(this.rankCfgKey, { points: {}, ghost: {} }); },
    setRankCfg(cfg) { Store.set(this.rankCfgKey, cfg); },
    // 各品级晋升所需积分（动态）
    rankReqs() {
      const cfg = this.rankCfg();
      const map = {};
      D.RANKS.forEach(r => { map[r.idx] = (cfg.points && cfg.points[r.idx] != null) ? cfg.points[r.idx] : r.points; });
      return map;
    },
    // 各品级晋升契约门槛（动态）
    ghostReqs() {
      const cfg = this.rankCfg();
      const map = Object.assign({}, D.PROMO_GHOST_REQ || {});
      if (cfg.ghost) Object.keys(cfg.ghost).forEach(k => {
        if (cfg.ghost[k]) map[k] = cfg.ghost[k]; else delete map[k];
      });
      return map;
    },

    // 当前积分（基础档案积分 + 个人任务积分汇总）
    points(uid) {
      const seed = D.SEED_PROFILES.find(p => p.id === uid);
      const base = seed ? (seed.points || 0) : 0;
      const tasks = TaskState.all(uid);
      const earned = Object.keys(tasks).reduce((s, mid) => {
        const m = D.MISSIONS.find(x => x.id === mid) || this.extraMissions(uid).find(x => x.id === mid);
        return s + (m && tasks[mid].status === "已完成" ? m.points : 0);
      }, 0);
      return base + earned;
    },

    // 根据积分计算当前等级索引（使用动态晋升门槛）
    rankIdxByPoints(pts) {
      const reqs = this.rankReqs();
      let idx = 0;
      D.RANKS.forEach(r => { if (pts >= reqs[r.idx]) idx = r.idx; });
      return idx;
    },

    // 契约门槛判定：晋升到 targetIdx 是否已满足契约鬼灵条件
    ghostGateOk(uid, targetIdx) {
      const reqName = this.ghostReqs()[targetIdx];
      if (!reqName) return true;
      const reqOrder = (D.GHOST_LEVELS.find(l => l.name === reqName) || {}).order || 99;
      const owned = MyGhosts.all(uid).list
        .map(mg => D.GHOSTS.find(g => g.id === mg.gid))
        .filter(Boolean)
        .map(g => (D.GHOST_LEVELS.find(l => l.name === g.level) || {}).order || 0);
      const maxOrder = owned.length ? Math.max.apply(null, owned) : 0;
      return maxOrder >= reqOrder;
    },

    // 有效品级：积分达标但契约门槛未满足时，停留在门槛前一品（天御难度已大幅提高，非专属但极难企及）
    effectiveRankIdx(uid) {
      if (uid === "YG-0001") return 10; // 最高权限账号直接天御
      const byPts = this.rankIdxByPoints(this.points(uid));
      const ack = Store.get("ygu_rank_ack_" + uid, null);
      const seed = D.SEED_PROFILES.find(p => p.id === uid);
      const base = ack !== null ? ack : (seed ? seed.rankIdx : 0);
      if (byPts <= base) return byPts;
      for (let i = base + 1; i <= byPts; i++) {
        if (!this.ghostGateOk(uid, i)) return i - 1;
      }
      return byPts;
    },

    // 个人扩展任务池（自动刷新用）
    extraMissions(uid) { return Store.get(this.extraKey(uid), []); },
    setExtraMissions(uid, list) { Store.set(this.extraKey(uid), list); },

    // 根据当前等级决定可接任务等级池
    allowedLevels(rankIdx) {
      const lv = [];
      if (rankIdx >= 0) lv.push("D");
      if (rankIdx >= 1) lv.push("C");
      if (rankIdx >= 2) lv.push("B");
      if (rankIdx >= 4) lv.push("A");
      if (rankIdx >= 7) lv.push("S");
      if (rankIdx >= 9) lv.push("SS");
      return lv;
    },

    // 生成新任务（基于模板，按玩家等级产出可接任务）
    generateMissions(uid, count = 3) {
      let seq = Store.get(LS.MISSION_SEQ, 100);
      const rnd = seededRand(uid + "_" + Date.now());
      const lvPool = this.allowedLevels(this.effectiveRankIdx(uid));
      const list = [];
      for (let i = 0; i < count; i++) {
        seq++;
        const lv = lvPool[Math.floor(rnd() * lvPool.length)] || "D";
        // 按等级选模板
        const tpl = D.MISSION_TEMPLATES.find(t => t.levels.includes(lv)) || D.MISSION_TEMPLATES[0];
        const name = tpl.names[Math.floor(rnd() * tpl.names.length)];
        const place = tpl.places[Math.floor(rnd() * tpl.places.length)];
        const jitter = Math.floor(rnd() * 16) - 7;
        const pts = Math.max(5, (tpl.pointsBase[lv] || 20) + jitter);
        list.push({
          id: "M" + String(seq).padStart(3, "0"),
          name, level: lv, place, points: pts, status: "待领取",
          desc: `系统检测到的${lv}级灵异事件，位于${place}，需要立即处置。`
        });
      }
      Store.set(LS.MISSION_SEQ, seq);
      return list;
    },

    // 检查并刷新任务（个人任务全部完成 / 可接任务不足时自动补货）
    refreshMissionsIfNeeded(uid) {
      const state = TaskState.all(uid);
      const mids = Object.keys(state);
      const extra = this.extraMissions(uid);
      const all = D.MISSIONS.concat(extra);
      const rankIdx = this.effectiveRankIdx(uid);
      const lvPool = this.allowedLevels(rankIdx);

      // 条件1：所有已接任务全部完成 → 补货
      const allDone = mids.length > 0 && mids.every(mid => state[mid].status === "已完成");
      // 条件2：可接任务 < 3 时补货
      const available = all.filter(m => {
        const eff = state[m.id] || { status: m.status };
        return eff.status === "待领取" && lvPool.includes(m.level);
      }).length;
      const needRestock = available < 3;

      if (!allDone && !needRestock) return null;
      // 保留已有履历中的扩展任务（防止历史记录丢失）与未领取的嘉奖令（防止管理员下发任务被补货冲掉）
      const existing = extra.filter(m => state[m.id] || m.issuer || m.rewards);
      const extras = this.generateMissions(uid, 3);
      this.setExtraMissions(uid, existing.concat(extras));
      return extras;
    },

    // 检测晋升（返回新晋升记录 / 受阻信息 / null）
    checkPromotion(uid) {
      const pts = this.points(uid);
      const byPts = this.rankIdxByPoints(pts);
      // 有效品级：积分达标但契约门槛未满足时停留在门槛前一品
      const newIdx = this.effectiveRankIdx(uid);
      // 已确认等级存于 storage；首次以种子档案等级为基准（避免 Profiles 递归）
      const key = "ygu_rank_ack_" + uid;
      let ack = Store.get(key, null);
      if (ack === null) {
        const seed = D.SEED_PROFILES.find(p => p.id === uid);
        ack = seed ? seed.rankIdx : 0;
        Store.set(key, ack);
      }
      if (newIdx <= ack) {
        // 积分已达标但被契约门槛挡住 → 返回受阻信息（不更新 ack，契约达标后可再触发）
        if (byPts > ack) {
          const gates = this.ghostReqs();
          for (let i = ack + 1; i <= byPts; i++) {
            if (!this.ghostGateOk(uid, i)) {
              return { blocked: true, need: gates[i], target: D.RANKS[i], old: D.RANKS[ack] };
            }
          }
        }
        return null;
      }
      Store.set(key, newIdx);
      const newRank = D.RANKS[newIdx];
      const oldRank = D.RANKS[ack];
      const done = Officials.missionsDone(uid);
      // 契约门槛达成说明（有门槛的品级附上最强契约鬼灵）
      let gateText = "";
      const reqName = (D.PROMO_GHOST_REQ || {})[newIdx];
      if (reqName) {
        const reqOrder = (D.GHOST_LEVELS.find(l => l.name === reqName) || {}).order || 0;
        let best = null, bestOrder = -1;
        MyGhosts.all(uid).list.forEach(mg => {
          const g = D.GHOSTS.find(x => x.id === mg.gid);
          if (!g) return;
          const o = (D.GHOST_LEVELS.find(l => l.name === g.level) || {}).order || 0;
          if (o > bestOrder) { bestOrder = o; best = g; }
        });
        gateText = best && bestOrder >= reqOrder
          ? `；契约门槛「${reqName}」已达成（契约鬼灵「${best.name}」· ${best.level}）`
          : "";
      }
      const rec = {
        date: today().slice(0, 7),
        title: `晋升${newRank.name}`,
        note: `由「${oldRank.name}」晋升「${newRank.name}」：累计积分 ${pts} 分（晋升门槛 ${newRank.points} 分），已完成任务 ${done} 起${gateText}。经指挥部审核，授${newRank.name}衔，权限范围：${newRank.scope}`,
        ts: Date.now()
      };
      this.addPromotion(uid, rec);
      return { old: oldRank, now: newRank, rec };
    },

    // 累计完成任务（档案展示）= 种子基准 + 个人实际完成
    missionsTotal(uid) {
      const prof = Profiles.find(uid);
      const base = prof ? (prof.missionsDone || 0) : 0;
      return base + Officials.missionsDone(uid);
    },

    // 总局定级（后台管理）：直接将御鬼者品级调整为目标品级
    // 自动补记/扣减积分至目标门槛、写入确认品级并留档晋升/降任记录；豁免契约门槛（敕令特批）
    setRank(uid, targetIdx) {
      const oldIdx = this.effectiveRankIdx(uid);
      const reqs = this.rankReqs();
      const targetPts = reqs[targetIdx];
      const delta = targetPts - this.points(uid);
      if (delta !== 0) {
        // 以「总局品级调整」补记任务平衡积分差额（可为负）
        const mid = "RANKADJ-" + Date.now();
        const extras = this.extraMissions(uid);
        extras.push({ id: mid, name: "总局品级调整", level: "D", place: "总局", points: delta, status: "已完成", desc: "总局敕令直接调整品级，积分差额补记" });
        this.setExtraMissions(uid, extras);
        const all = TaskState.all(uid);
        all[mid] = { status: "已完成", rating: "S", date: today() };
        Store.set(TaskState.key(uid), all);
      }
      Store.set("ygu_rank_ack_" + uid, targetIdx);
      const oldRank = D.RANKS[oldIdx], newRank = D.RANKS[targetIdx];
      this.addPromotion(uid, {
        date: today().slice(0, 7),
        title: (targetIdx >= oldIdx ? "晋升" : "降任") + newRank.name,
        note: `总局敕令：品级由「${oldRank.name}」调整为「${newRank.name}」，积分核定 ${targetPts} 分，敕令特批豁免契约门槛`,
        ts: Date.now()
      });
      return { old: oldRank, now: newRank };
    },

    // 上级链（保证品级严格递增：上级品级必须高于下级，倒挂时沿汇报链自动向上跃迁；
    // 无直属上级时按品级差最小自动匹配；链顶恒为 YG-0001——1号是所有人的最高领导）
    superiorChain(uid) {
      const chain = [];
      let cur = Profiles.find(uid);
      if (!cur || cur.id === "YG-0001") return chain;
      let minRank = cur.rankIdx;
      let nextId = cur.superiorId;
      let depth = 0;
      // 若无直属上级，自动匹配品级最接近的更高品级御鬼者
      if (!nextId) {
        const pool = Profiles.all().filter(p => p.id !== uid && p.rankIdx > minRank && p.id !== "YG-0001");
        pool.sort((a, b) => a.rankIdx - b.rankIdx);
        if (pool.length) nextId = pool[0].id;
      }
      while (nextId && depth < 10) {
        let sup = Profiles.find(nextId);
        while (sup && sup.rankIdx <= minRank && sup.superiorId && depth < 10) {
          nextId = sup.superiorId;
          sup = Profiles.find(nextId);
          depth++;
        }
        if (!sup || sup.rankIdx <= minRank) break;
        chain.push(sup);
        minRank = sup.rankIdx;
        nextId = sup.superiorId;
        depth++;
      }
      // 链顶统一收束到 YG-0001（最高权限账号为所有人的最高领导，晋升天御亦归其领导）
      if (!chain.length || chain[chain.length - 1].id !== "YG-0001") {
        const boss = Profiles.find("YG-0001");
        if (boss && boss.rankIdx > minRank) chain.push(boss);
      }
      return chain;
    }
  };

  /* ---------------- 管理员检测 / 分级权限 ---------------- */
  function seedLeader(id) { return (D.SEED_PROFILES || []).find(p => p.id === id && p.leader) || null; }
  function isTopAdmin(id) { return (id || Session.get()) === "YG-0001"; }
  function isAdmin(id) {
    const sid = id || Session.get();
    return sid === "YG-0001" || !!seedLeader(sid);
  }
  // 当前登录领导所辖机构（非领导返回 null；1号管辖全国）
  // 返回 { all, orgId, bureau }：省级领导 orgId=PROV，bureau 为其驻地（华东等），管辖全部省级分局
  function adminScope(id) {
    const sid = id || Session.get();
    if (sid === "YG-0001") return { all: true, orgId: null, bureau: null };
    const l = seedLeader(sid);
    return l ? { all: false, orgId: l.orgId, bureau: l.bureau } : null;
  }
  // 管理者能否操作目标账号（查看/增删/重置/净化/发物资/嘉奖/派任务）
  // 1号可管全国（但结构账号保护另算）；机构领导仅能管本机构成员，不能管其他领导与1号
  function canManage(managerId, targetId) {
    if (targetId === "YG-0001") return managerId === "YG-0001";
    if (managerId === "YG-0001") return true;
    const lm = seedLeader(managerId);
    if (!lm) return false;
    if (seedLeader(targetId)) return false;
    const t = Profiles.find(targetId);
    return !!t && D.orgIdOfBureau(t.bureau) === lm.orgId;
  }
  // 结构性受保护账号（1号 + 机构领导）：不可关联/删除/重置/定级
  function isProtectedId(id) { return id === "YG-0001" || !!seedLeader(id); }

  /* ---------------- 功能解锁（按有效品级；YG-0001 全解锁） ---------------- */
  const FeatureLock = {
    // 返回 null 表示已解锁；否则返回 { needIdx, needName }
    check(uid, key) {
      const needIdx = (D.FEATURE_UNLOCK || {})[key];
      if (needIdx === undefined) return null;
      if (uid === "YG-0001") return null;
      const eff = GameState.effectiveRankIdx(uid);
      if (eff >= needIdx) return null;
      return { needIdx, needName: D.RANKS[needIdx].name };
    },
    allowed(uid, key) { return this.check(uid, key) === null; },
    // 页面级守卫：未解锁则把主内容替换为锁定占位，返回 false
    guardPage(key, label) {
      const me = Profiles.current();
      if (!me) return false;
      const lock = this.check(me.id, key);
      if (!lock) return true;
      const main = document.querySelector("main.content");
      if (main) {
        main.innerHTML = `
          <div class="glass corner lock-panel">
            <div class="lock-ico">${I.lock}</div>
            <h2>「${esc(label)}」尚未解锁</h2>
            <p>当前品级 <b class="mono">${esc(D.RANKS[me.rankIdx].name)}</b> · 晋升 <b style="color:var(--gold)">${esc(lock.needName)}</b> 后开放本功能</p>
            <p class="lock-tip">完成任务积累积分与契约鬼灵，即可提升品级</p>
            <a class="btn btn-primary" href="tasks.html">前往任务大厅</a>
          </div>`;
      }
      return false;
    }
  };

  /* ---------------- 御鬼者档案（种子 + 注册用户） ---------------- */
  function buildProfileFromUser(u) {
    const erosion = Erosion.display(u.id, 8);
    const pts = GameState.points(u.id);
    const rankIdx = GameState.effectiveRankIdx(u.id);
    return {
      id: u.id, name: u.name, rankIdx, points: pts,
      bureau: u.bureau || "城南区县级御鬼者驿站",
      erosion, status: Erosion.display(u.id, 8) >= 70 ? "停职" : "正常",
      joinDate: (u.createdAt || new Date().toISOString().slice(0, 10)),
      ghostIds: [], missionsDone: 0, rating: "—", seed: false,
      seedErosion: 8,
      superiorId: u.id === "YG-0001" ? null : null, // 后续按品级自动分配上级
      promotions: GameState.promotions(u.id).concat([{
        date: (u.createdAt || "").slice(0, 7) || "新近",
        title: "天赋觉醒登记", note: "档案备案完成，入门培训进行中"
      }])
    };
  }

  const Profiles = {
    // 已删除账号清单：删除后档案直接清除出名录（不再展示）
    deletedKey: "ygu_deleted_profiles",
    deletedList() { return Store.get(this.deletedKey, []); },
    markDeleted(id) {
      const l = this.deletedList();
      if (!l.includes(id)) { l.push(id); Store.set(this.deletedKey, l); }
    },
    all() {
      const deleted = new Set(this.deletedList());
      const seeds = D.SEED_PROFILES
        .filter(p => p.status !== "叛逃" && !deleted.has(p.id)) // 叛逃/已删除档案直接清除出系统名录
        .map(p => {
        const live = Object.assign({ rating: "B" }, p);
        live.seedErosion = p.erosion; // 种子基准侵蚀度（停职判定用）
        // 种子档案融合：侵蚀度按日期动态波动；晋升记录 = 静态 + 动态
        live.erosion = Erosion.display(p.id, p.erosion);
        live.points = GameState.points(p.id);
        live.rankIdx = GameState.effectiveRankIdx(p.id);
        live.promotions = GameState.promotions(p.id).concat(p.promotions || []);
        // 停职/复职实时判定：展示值 ≥70% 停职，净化后 <70% 自动复职（与界面显示同源）
        if (live.erosion >= 70) live.status = "停职";
        else if (live.status === "停职") live.status = "正常";
        return live;
      });
      const seedIds = new Set(D.SEED_PROFILES.map(p => p.id));
      // 已叛逃的种子编号不可再关联账号
      const defectorIds = new Set(D.SEED_PROFILES.filter(p => p.status === "叛逃").map(p => p.id));
      const mine = Users.all().filter(u => !seedIds.has(u.id) && !defectorIds.has(u.id)).map(buildProfileFromUser);
      return seeds.concat(mine);
    },
    find(id) { return this.all().find(p => p.id === id); },
    current() {
      const sid = Session.get();
      if (!sid) return null;
      return this.find(sid);
    }
  };

  /* ---------------- 个人任务状态（领取/完成，按账号隔离） ---------------- */
  const TaskState = {
    key(uid) { return LS.TASKS + uid; },
    all(uid) {
      if (uid === "YG-0001" && Store.get(this.key(uid), null) === null) {
        // 最高权限账号预置履历
        const seed = {
          M001: { status: "已完成", rating: "A", date: "2026-05-02" },
          M004: { status: "已完成", rating: "B", date: "2026-05-19" }
        };
        Store.set(this.key(uid), seed);
        return seed;
      }
      return Store.get(this.key(uid), {});
    },
    get(uid, mid) { return this.all(uid)[mid] || null; },
    claim(uid, mid) {
      const all = this.all(uid);
      all[mid] = { status: "进行中", date: today() };
      Store.set(this.key(uid), all);
    },
    complete(uid, mid, rating) {
      const all = this.all(uid);
      all[mid] = { status: "已完成", rating, date: today() };
      Store.set(this.key(uid), all);
    },
    effectiveStatus(uid, mission) {
      const mine = this.get(uid, mission.id);
      return mine ? mine.status : mission.status;
    }
  };

  function today() { return new Date().toISOString().slice(0, 10); }

  /* ---------------- 权限守卫 ---------------- */
  function guard() {
    const body = document.body;
    const needAuth = body.dataset.guard === "1";
    const guestOnly = body.dataset.guest === "1";
    let sess = Session.get();
    if (needAuth && (!sess || !Users.find(sess))) {
      Session.clear();
      location.replace("index.html?err=auth");
      return false;
    }
    // 殉职检查：契约鬼灵每日反哺侵蚀，先结算漂移再判定死亡
    if (needAuth && sess) {
      MyGhosts.all(sess);
      if (Discipline.checkDeath(sess)) {
        location.replace("index.html?err=dead");
        return false;
      }
      // 侵蚀度 ≥70 高危提醒（每次会话只提示一次）
      const ero = Erosion.get(sess);
      if (ero >= 70 && !sessionStorage.getItem("ygu_ero_warned_" + sess)) {
        sessionStorage.setItem("ygu_ero_warned_" + sess, "1");
        setTimeout(() => toast({
          level: "red", icon: "alarm", force: 2600,
          title: "侵蚀度高危警告",
          text: `当前侵蚀度 ${ero}%，已达停职标准。请立即使用净化类道具降低侵蚀，≥90% 将殉职销户！`
        }), 600);
      }
    }
    if (guestOnly && sess && Users.find(sess)) {
      location.replace("dashboard.html");
      return false;
    }
    return true;
  }

  /* ---------------- 全国灾难预警（主控台与预警地图共用同一数据源） ---------------- */
  const Disaster = {
    SAFE: { level: "安全", color: "#3ddc97", plan: "常态巡逻，驿站值守，保持监测", range: "—" },
    zones() { return D.NATION_ZONES || []; },
    // 等级信息：0 安全，1-6 对应 DISASTERS
    info(lv) { return lv <= 0 ? this.SAFE : D.DISASTERS[Math.min(lv, 6) - 1]; },
    // 实时等级：以 30 秒为时间桶做确定性波动，各城市随时间变化
    // 灭灾（6级）为理论极值，平时不出现——实时波动封顶黑灾（5级）
    level(z) {
      const bucket = Math.floor(Date.now() / 30000);
      const r = seededRand("zone_" + z.id + "_" + bucket)();
      let lv = Math.round(z.base + (r - 0.5) * 2.8);
      return Math.max(0, Math.min(5, lv));
    },
    // 阴能指数：随等级与小时间桶波动
    energy(z, lv) {
      const bucket = Math.floor(Date.now() / 3600000);
      const r = seededRand("eng_" + z.id + "_" + bucket)();
      return Math.round(lv * 14 + r * 9 + 3);
    },
    // 趋势：上升 / 平稳 / 下降（与等级同一时间桶，保证页面间一致）
    trend(z, lv) {
      if (lv === 0) return "平稳";
      const bucket = Math.floor(Date.now() / 30000);
      const r = seededRand("trend_" + z.id + "_" + bucket)();
      return r > 0.55 ? "上升" : r > 0.25 ? "平稳" : "下降";
    },
    // 当前全国最高威胁 { zone, lv }
    worst() {
      let worst = null, worstLv = -1;
      this.zones().forEach(z => {
        const lv = this.level(z);
        if (lv > worstLv) { worstLv = lv; worst = z; }
      });
      return { zone: worst, lv: worstLv };
    },
    // 各等级城市计数（索引 0-6）
    counts() {
      const c = [0, 0, 0, 0, 0, 0, 0];
      this.zones().forEach(z => { c[this.level(z)]++; });
      return c;
    },
    // 灾情等级 ↔ 任务难度映射：安全0无任务，蓝1→D，黄2→C，橙3→B，红4→A，黑5→S/SS
    missionLevelsFor(lv) {
      return { 1: ["D"], 2: ["C"], 3: ["B"], 4: ["A"], 5: ["S", "SS"], 6: ["SS"] }[lv] || [];
    },
    // 城市关联鬼怪 / 任务（关键词命中 + 等级与灾情匹配）
    threats(z, lv) {
      lv = lv === undefined ? this.level(z) : lv;
      // 鬼怪等阶与灾情匹配：灾情 lv 对应鬼怪等阶 lv+1（蓝→怨鬼 ... 黑→鬼王/鬼帅）
      const ghosts = D.GHOSTS
        .filter(g => z.kw.some(k => (g.area + g.event).includes(k)))
        .filter(g => {
          const order = (D.GHOST_LEVELS.find(l => l.name === g.level) || {}).order || 1;
          return lv <= 0 ? order <= 2 : Math.abs(order - (lv + 1)) <= 1;
        })
        .slice(0, 3);
      const mLv = this.missionLevelsFor(lv);
      const missions = D.MISSIONS
        .filter(m => z.kw.some(k => (m.place + m.name + m.desc).includes(k)))
        .filter(m => mLv.includes(m.level))
        .slice(0, 3);
      return { ghosts, missions };
    }
  };

  /* ---------------- SVG 图标库 ---------------- */
  const I = {
    dashboard: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>',
    profile: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6.5 8-6.5s8 2.5 8 6.5"/></svg>',
    ghost: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M12 3a7 7 0 0 0-7 7v10l2.3-2 2.4 2 2.3-2 2.3 2 2.4-2L19 20V10a7 7 0 0 0-7-7Z"/><circle cx="9.5" cy="10.5" r="1.1" fill="currentColor"/><circle cx="14.5" cy="10.5" r="1.1" fill="currentColor"/></svg>',
    task: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M9 3h6a1 1 0 0 1 1 1v1h3v16H5V5h3V4a1 1 0 0 1 1-1Z"/><path d="m9 13 2 2 4-4.5"/></svg>',
    equip: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M12 3l7 3v5c0 4.6-3 8.5-7 10-4-1.5-7-5.4-7-10V6l7-3Z"/><path d="m9 12 2 2 4-4"/></svg>',
    org: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 21v-6h6v6"/></svg>',
    disaster: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M12 3 2 20h20L12 3Z"/><path d="M12 10v4.5"/><circle cx="12" cy="17.5" r="1" fill="currentColor"/></svg>',
    logout: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M14 4h5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-5"/><path d="M9 16l-4-4 4-4"/><path d="M5 12h12"/></svg>',
    search: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>',
    alarm: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff3b5c" stroke-width="1.8"><path d="M12 3 2 20h20L12 3Z"/><path d="M12 10v4.5"/><circle cx="12" 17.5" r="1" fill="#ff3b5c"/></svg>',
    bell: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 9a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7"/><path d="M10.5 20a2 2 0 0 0 3 0"/></svg>',
    erosion: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2ee6ff" stroke-width="1.8"><path d="M12 3s6 7 6 11a6 6 0 0 1-12 0c0-4 6-11 6-11Z"/></svg>',
    points: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8"/><path d="M12 8v8M9.5 10.5c0-1 .9-1.7 2.5-1.7s2.5.7 2.5 1.7-.9 1.5-2.5 1.8-2.5.8-2.5 1.8 1 1.7 2.5 1.7 2.5-.7 2.5-1.7"/></svg>',
    coin: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><path d="M12 3.5v2M12 18.5v2M3.5 12h2M18.5 12h2"/></svg>',
    medal: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="12" cy="9" r="5.5"/><path d="M8.5 13.5 7 21l5-2.5L17 21l-1.5-7.5"/></svg>',
    rift: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 4c6 4 10 12 16 16"/><path d="M20 4C14 8 10 16 4 20"/><circle cx="12" cy="12" r="2.2"/></svg>',
    online: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.5 3-5.5 7-5.5s7 2 7 5.5"/></svg>',
    menu: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
    lock: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15.5" r="1.2" fill="currentColor"/></svg>',
    arrow: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>',
    back: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5m6 6-6-6 6-6"/></svg>',
    check: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#3ddc97" stroke-width="2.4"><path d="m5 12 5 5L20 7"/></svg>',
    close: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    "cat-侦测类": '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4-4"/><path d="M8.5 11h5M11 8.5v5"/></svg>',
    "cat-封印收纳类": '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="4" y="7" width="16" height="13" rx="2"/><path d="M4 11h16M9 7V5h6v2"/></svg>',
    "cat-防护抗侵蚀类": '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M12 3 5 6v6c0 4.5 3 7.5 7 9 4-1.5 7-4.5 7-9V6l-7-3Z"/></svg>',
    "cat-战斗攻坚类": '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M4 20 14 10M13 4l7 7-3 3-7-7 3-3ZM14 10l3 3M6 18l-2 4 4-2"/></svg>',
    "cat-药剂耗材类": '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M9 3h6M10 3v7l-4.5 8A2 2 0 0 0 7.3 21h9.4a2 2 0 0 0 1.8-3L14 10V3"/><path d="M8 15h8"/></svg>',
    logo: '<svg width="30" height="30" viewBox="0 0 32 32" fill="none"><path d="M16 3 5 9v9c0 6 4.6 9.5 11 11 6.4-1.5 11-5 11-11V9L16 3Z" stroke="#2ee6ff" stroke-width="1.6"/><path d="M11 16.5 14.5 20l7-8" stroke="#2ee6ff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    logoSm: '<svg width="22" height="22" viewBox="0 0 32 32" fill="none"><path d="M16 3 5 9v9c0 6 4.6 9.5 11 11 6.4-1.5 11-5 11-11V9L16 3Z" stroke="#2ee6ff" stroke-width="1.8"/><path d="M11 16.5 14.5 20l7-8" stroke="#2ee6ff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };

  /* ---------------- 布局注入 ---------------- */
  const NAV = [
    { key: "dashboard", icon: "dashboard", label: "主控台", href: "dashboard.html" },
    { key: "profiles", icon: "profile", label: "御鬼者档案", href: "profiles.html" },
    { key: "ghosts", icon: "ghost", label: "鬼怪图鉴", href: "ghosts.html" },
    { key: "tasks", icon: "task", label: "任务大厅", href: "tasks.html" },
    { key: "inventory", icon: "equip", label: "我的背包", href: "inventory.html" },
    { key: "ghostsMine", icon: "ghost", label: "鬼灵仓库", href: "ghosts-mine.html" },
    { key: "shop", icon: "coin", label: "冥府商城", href: "shop.html" },
    { key: "officials", icon: "medal", label: "官职竞选", href: "officials.html" },
    { key: "organization", icon: "org", label: "组织架构", href: "organization.html" },
    { key: "disaster", icon: "disaster", label: "灾难预警", href: "disaster.html" }
  ];
  if (isAdmin()) {
    NAV.push({ key: "admin", icon: "dashboard", label: "后台管理", href: "admin.html" });
  }

  function renderLayout() {
    const page = document.body.dataset.page || "";
    const me = Profiles.current();
    const side = document.getElementById("sidebar");
    const top = document.getElementById("topbar");
    if (!side || !top || !me) return;

    // 品级界面主题：见习/九品·八品/七·六/五·四/三·二·一/天御 分档
    const tier = me.rankIdx >= 10 ? "supreme" : me.rankIdx >= 7 ? "high" : me.rankIdx >= 4 ? "mid" : me.rankIdx >= 1 ? "low" : "trainee";
    document.body.dataset.rankTier = tier;

    const rankName = D.RANKS[me.rankIdx].name;
    side.innerHTML = `
      <div class="sidebar-brand">
        <div class="mark">${I.logoSm}</div>
        <div><b>御鬼者管控</b><small>N.G.C.A SYSTEM</small></div>
      </div>
      <div class="rank-banner tier-${tier}">
        <small>当前品级</small>
        <b>${esc(rankName)}</b>
      </div>
      <nav class="nav">
        ${NAV.map(n => {
          const lock = FeatureLock.check(me.id, n.key);
          if (lock) {
            return `<a href="#" class="nav-locked" data-lock-name="${esc(n.label)}" data-lock-need="${esc(lock.needName)}" title="晋升${esc(lock.needName)}后解锁">${I.lock}<span>${n.label}</span><em class="lock-tag">${esc(lock.needName)}</em></a>`;
          }
          return `<a href="${n.href}" class="${n.key === page ? "active" : ""}">${I[n.icon]}<span>${n.label}</span></a>`;
        }).join("")}
      </nav>
      <div class="nav-logout-box">
        <a href="#" class="nav-logout" id="navLogout">${I.logout}<span>退出登录</span></a>
      </div>
      <div class="sidebar-foot"><span class="blink-dot"></span>SECURE LINK · 加密链路</div>
    `;

    // 锁定菜单点击提示
    side.querySelectorAll(".nav-locked").forEach(a => {
      a.addEventListener("click", e => {
        e.preventDefault();
        toast({ title: "功能未解锁", text: `晋升「${a.dataset.lockNeed}」后开放${a.dataset.lockName}`, level: "amber", icon: "lock" });
      });
    });

    top.innerHTML = `
      <button class="mobile-menu-btn" id="menuBtn" aria-label="菜单">${I.menu}</button>
      <div class="topbar-clock"><small>系统时间</small><span id="clock">--</span></div>
      <div class="topbar-right">
        <a class="topbar-link" href="shop.html" title="冥府商城" style="display:inline-flex;align-items:center;gap:6px;color:var(--gold)">${I.coin}<span class="mono">${Coins.get(me.id)}</span> 冥币</a>
        <a class="topbar-link" href="my-tasks.html">我的任务记录</a>
        <div class="user-chip" id="userChip" title="查看我的档案">
          <div class="avatar">${esc(me.name.slice(0, 1))}</div>
          <div><b>${esc(me.name)}</b><small>${esc(me.id)} · ${rankName}${(function(){ const of = Officials.of(me.id); return of ? " · " + esc(of.name) : ""; })()}</small></div>
        </div>
      </div>
    `;

    document.getElementById("navLogout").addEventListener("click", e => {
      e.preventDefault();
      Session.clear();
      location.href = "index.html";
    });
    document.getElementById("userChip").addEventListener("click", () => {
      location.href = "profile-detail.html?id=" + encodeURIComponent(me.id);
    });
    const menuBtn = document.getElementById("menuBtn");

    // 移动端侧边栏遮罩：注入一次，点击遮罩或导航链接后自动收起
    let mask = document.getElementById("sideMask");
    if (!mask) {
      mask = document.createElement("div");
      mask.id = "sideMask";
      mask.className = "side-mask";
      document.body.appendChild(mask);
      mask.addEventListener("click", () => {
        side.classList.remove("open");
        mask.classList.remove("show");
      });
    }
    menuBtn.addEventListener("click", () => {
      const open = side.classList.toggle("open");
      mask.classList.toggle("show", open);
    });
    side.querySelectorAll(".nav a[href]").forEach(a => {
      a.addEventListener("click", () => {
        side.classList.remove("open");
        mask.classList.remove("show");
      });
    });

    startClock(document.getElementById("clock"));
  }

  function startClock(el) {
    const week = ["日", "一", "二", "三", "四", "五", "六"];
    function tick() {
      const d = new Date();
      const p = n => String(n).padStart(2, "0");
      el.textContent = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())} 星期${week[d.getDay()]}`;
    }
    tick();
    setInterval(tick, 1000);
  }

  function renderTicker() {
    const el = document.getElementById("ticker");
    if (!el) return;
    const items = D.BROADCASTS.concat(D.BROADCASTS).map(t => `<span>${t}</span>`).join("");
    el.innerHTML = `<div class="ticker-tag">${I.bell}实时广播</div><div class="ticker-track">${items}</div>`;
  }

  /* ---------------- Toast 预警弹窗 ---------------- */
  function toast(opt) {
    let stack = document.querySelector(".toast-stack");
    if (!stack) {
      stack = document.createElement("div");
      stack.className = "toast-stack";
      document.body.appendChild(stack);
    }
    const el = document.createElement("div");
    el.className = `glass toast level-${opt.level || "cyan"}`;
    const forced = opt.force || 0;
    el.innerHTML = `
      <div class="t-ico">${I[opt.icon] || I.bell}</div>
      <div><b>${esc(opt.title)}</b><p>${esc(opt.text)}</p></div>
      ${forced ? "" : `<button class="t-close" aria-label="关闭">${I.close}</button>`}
      ${forced ? '<div class="countdown"></div>' : ""}
    `;
    stack.appendChild(el);

    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      el.classList.add("leaving");
      setTimeout(() => el.remove(), 360);
    };
    el.querySelector(".t-close")?.addEventListener("click", close);
    setTimeout(close, forced + 4600);
    return close;
  }

  /* ---------------- 模态弹窗 ---------------- */
  function modal(html) {
    const mask = document.createElement("div");
    mask.className = "modal-mask";
    mask.innerHTML = `<div class="glass modal">${html}</div>`;
    document.body.appendChild(mask);
    return () => mask.remove();
  }

  /* ---------------- 数字滚动 ---------------- */
  function countUp(el, target, opts = {}) {
    const dur = opts.duration || 1200;
    const start = performance.now();
    const from = 0;
    function frame(now) {
      const p = Math.min((now - start) / dur, 1);
      const ease = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(from + (target - from) * ease) + (opts.suffix || "");
      if (p < 1) requestAnimationFrame(frame);
      else if (opts.after) opts.after();
    }
    requestAnimationFrame(frame);
  }

  /* ---------------- 工具 ---------------- */
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, c =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  function qs(name) {
    return new URLSearchParams(location.search).get(name);
  }
  function ghostLevelCls(level) {
    const f = D.GHOST_LEVELS.find(g => g.name === level);
    return f ? f.cls : "";
  }
  function rankCls(idx) {
    if (idx >= 10) return "lv-wang";
    if (idx >= 9) return "lv-shuai";
    if (idx >= 7) return "lv-jiang";
    if (idx >= 5) return "lv-sha";
    if (idx >= 3) return "lv-li";
    if (idx >= 1) return "lv-yuan";
    return "lv-you";
  }
  function missionCls(level) { return "m-" + level; }
  function statusCls(s) { return "st-" + s; }
  function badge(cls, text, dot = true) {
    return `<span class="badge ${cls}">${dot ? '<span class="dot"></span>' : ""}${esc(text)}</span>`;
  }

  // 确定性伪随机（侵蚀度曲线等）
  function seededRand(seed) {
    let h = 0;
    for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
    return function () {
      h = (h * 1664525 + 1013904223) >>> 0;
      return h / 4294967296;
    };
  }

  /* ---------------- 启动（defer 阶段 body 已解析，立即执行守卫尽早跳转） ---------------- */
  if (guard() && document.body.dataset.guard === "1") {
    document.addEventListener("DOMContentLoaded", () => {
      renderLayout();
      renderTicker();
      // 图片容错：原图失败 → 重试原图（网络抖动）→ 通用提示词 → 符文占位块
      document.addEventListener("error", e => {
        const t = e.target;
        if (!(t instanceof HTMLImageElement)) return;
        if (!t.classList.contains("ghost-img") && !t.classList.contains("ghost-detail-img")) return;
        const n = parseInt(t.dataset.retry || "0", 10);
        if (n === 0) {
          // 第一次失败：重试原 URL（加时间戳绕过可能的截断缓存）
          t.dataset.retry = "1";
          t.src = t.src.split("&_t=")[0] + "&_t=" + Date.now();
        } else if (n === 1) {
          // 第二次失败：换通用提示词
          t.dataset.retry = "2";
          t.src = "https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=" +
            encodeURIComponent("dark mysterious ghostly silhouette in fog, eerie blue glow, horror atmosphere, digital illustration, no people, no text") +
            "&image_size=portrait_4_3&_t=" + Date.now();
        } else {
          // 最终失败：替换为符文占位块，保持卡片美观
          t.onerror = null;
          const ph = document.createElement("div");
          ph.className = t.className + " img-fallback";
          ph.textContent = (t.alt || "灵").slice(0, 1);
          t.replaceWith(ph);
        }
      }, true);

      // 全局快捷键：Esc 关闭最上层弹窗 / 手机端收起侧栏
      document.addEventListener("keydown", e => {
        if (e.key !== "Escape") return;
        const top = document.querySelectorAll(".modal-mask");
        if (top.length) {
          top[top.length - 1].remove();
          e.preventDefault();
          return;
        }
        const side = document.getElementById("sidebar");
        const mask = document.getElementById("sideMask");
        if (side && side.classList.contains("open")) {
          side.classList.remove("open");
          if (mask) mask.classList.remove("show");
          e.preventDefault();
        }
      });

      // 看门狗：部分请求挂起不触发 error，超时后强制重试
      [9000, 20000].forEach(delay => setTimeout(() => {
        document.querySelectorAll("img.ghost-img, img.ghost-detail-img").forEach(t => {
          if (t.complete && t.naturalWidth > 0) return; // 已加载
          const n = parseInt(t.dataset.retry || "0", 10);
          if (n >= 2) return; // 已进入最终兜底流程
          t.dataset.retry = String(n + 1);
          t.src = t.src.split("&_t=")[0] + "&_t=" + Date.now();
        });
      }, delay));
    });
  }

  /* ---------------- 导出 ---------------- */
  window.YG = {
    Store, Users, Session, Profiles, TaskState, Sync,
    Inventory, Erosion, GameState, Coins, MyGhosts, Officials, Discipline, isAdmin, FeatureLock, Disaster,
    Explore,
    isTopAdmin, adminScope, canManage, isProtectedId, seedLeader,
    I, icon: k => I[k] || "",
    toast, modal, countUp, esc, qs,
    ghostLevelCls, rankCls, missionCls, statusCls, badge, seededRand,
    today
  };
})();

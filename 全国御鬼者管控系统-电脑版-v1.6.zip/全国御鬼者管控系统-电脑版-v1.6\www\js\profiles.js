/* 御鬼者档案列表 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { esc, rankCls, statusCls, badge, Profiles, GameState, seedLeader } = window.YG;

  const tbody = document.getElementById("tbody");
  const search = document.getElementById("searchInput");
  const rankSel = document.getElementById("rankFilter");
  const statusSel = document.getElementById("statusFilter");

  rankSel.innerHTML = `<option value="全部">全部等级</option>` +
    D.RANKS.map(r => `<option value="${r.idx}">${r.name}</option>`).join("");

  function erosionMini(v) {
    const cls = v > 80 ? "danger" : v >= 60 ? "warn" : "";
    const color = v > 80 ? "var(--red)" : v >= 60 ? "var(--amber)" : "var(--cyan)";
    return `
      <div style="display:flex;align:center;gap:9px;min-width:120px">
        <div class="bar ${cls}" style="flex:1;height:7px"><i style="width:${v}%;background:${color};box-shadow:0 0 8px ${color}"></i></div>
        <span class="mono" style="font-size:12px;color:${color};width:38px;text-align:right">${v}%</span>
      </div>`;
  }

  function rowHTML(p) {
    const rank = D.RANKS[p.rankIdx];
    let sub = "";
    if (p.id === "YG-0001") sub = '<div class="sub" style="color:var(--gold)">最高权限 · 总署长（国家级最高领导）</div>';
    else if (p.leader || seedLeader(p.id)) {
      const l = seedLeader(p.id) || {};
      sub = `<div class="sub" style="color:var(--gold)">${esc(l.leaderTitle || "所属机构最高领导")}</div>`;
    }
    return `
      <tr data-id="${p.id}">
        <td class="mono">${p.id}</td>
        <td><b style="color:var(--text-bright)">${esc(p.name)}</b>${sub}</td>
        <td>${badge(rankCls(p.rankIdx), rank.name)}</td>
        <td style="color:var(--muted)">${esc(p.bureau)}</td>
        <td>${erosionMini(p.erosion)}</td>
        <td class="mono">${GameState.missionsTotal(p.id)}</td>
        <td>${badge(statusCls(p.status), p.status)}</td>
        <td><span class="row-arrow inline-flex">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>
        </span></td>
      </tr>`;
  }

  // 编号从小到大排列（领导按序号排在最前）
  const idNum = p => parseInt(String(p.id).replace(/\D/g, ""), 10) || 999999;

  function render() {
    const kw = search.value.trim().toUpperCase();
    const rv = rankSel.value;
    const sv = statusSel.value;
    const list = Profiles.all().filter(p =>
      (!kw || p.id.toUpperCase().includes(kw) || p.name.includes(kw)) &&
      (rv === "全部" || p.rankIdx === Number(rv)) &&
      (sv === "全部" || p.status === sv)
    ).sort((a, b) => idNum(a) - idNum(b));

    tbody.innerHTML = list.length
      ? list.map(rowHTML).join("")
      : `<tr><td colspan="8" class="empty" style="display:block">未检索到匹配的御鬼者档案</td></tr>`;
  }

  search.addEventListener("input", render);
  rankSel.addEventListener("change", render);
  statusSel.addEventListener("change", render);
  tbody.addEventListener("click", e => {
    const tr = e.target.closest("tr[data-id]");
    if (tr) location.href = "profile-detail.html?id=" + encodeURIComponent(tr.dataset.id);
  });

  render();
})();

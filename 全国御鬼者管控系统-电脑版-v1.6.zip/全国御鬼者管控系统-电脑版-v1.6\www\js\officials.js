/* 官职竞选 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { esc, badge, rankCls, icon, Profiles, GameState, Officials, FeatureLock, toast, modal } = window.YG;

  const me = Profiles.current();
  if (!me) return;
  if (!FeatureLock.guardPage("officials", "官职竞选")) return;
  const grid = document.getElementById("ofGrid");
  const statusEl = document.getElementById("myStatus");

  function renderStatus() {
    const pts = GameState.points(me.id);
    const rank = D.RANKS[GameState.effectiveRankIdx(me.id)];
    const done = Officials.missionsDone(me.id);
    const cur = Officials.of(me.id);
    const held = Officials.get(me.id);
    const tierName = (D.BUREAU_TIERS[D.bureauTierOf(me.bureau)] || {}).name || "县级驿站";
    statusEl.innerHTML = `
      <div style="display:flex;gap:24px;flex-wrap:wrap;align-items:center">
        <div><small style="color:var(--muted)">当前官职</small><div style="font-size:18px;font-weight:700;color:${cur ? "var(--gold)" : "var(--faint)"};margin-top:4px">
          ${cur ? esc(cur.name) + ` <small style="font-size:12px;color:var(--muted)">${held ? "任职于 " + held.date : "最高权限 · 天命所归"}</small>` : "白身 · 尚未任职"}</div>
          ${cur ? `<div style="font-size:12px;color:var(--cyan);margin-top:4px">职权：${esc(cur.perm || "")}</div>` : ""}</div>
        <div><small style="color:var(--muted)">所属机构</small><div style="margin-top:4px;font-size:13.5px">${esc(me.bureau)}<br><small style="color:var(--cyan)">${tierName}序列</small></div></div>
        <div><small style="color:var(--muted)">品级</small><div class="mono" style="margin-top:4px">${esc(rank.name)}</div></div>
        <div><small style="color:var(--muted)">积分</small><div class="mono" style="margin-top:4px;color:var(--amber)">${pts}</div></div>
        <div><small style="color:var(--muted)">已完成任务</small><div class="mono" style="margin-top:4px;color:var(--cyan)">${done} 起</div></div>
        <div><small style="color:var(--muted)">档案监察权限</small><div class="mono" style="margin-top:4px;color:var(--gold)">${Officials.clearance(me.id)} 级</div></div>
        ${cur ? `<div style="margin-left:auto;color:var(--green);font-size:13px">任务冥币结算 +${cur.coinBonus} / 次</div>` : ""}
      </div>`;
  }

  function render() {
    renderStatus();
    const cur = Officials.of(me.id);
    grid.innerHTML = D.OFFICIALS.map((of, i) => {
      const ok = Officials.qualified(me.id, of);
      const isCur = cur && cur.id === of.id;
      const reqRank = D.RANKS[of.reqRankIdx].name;
      const pts = GameState.points(me.id);
      const rankIdx = GameState.effectiveRankIdx(me.id);
      const done = Officials.missionsDone(me.id);
      const reqs = [
        { lbl: "品级", need: reqRank, pass: rankIdx >= of.reqRankIdx },
        { lbl: "积分", need: "≥ " + of.reqPoints, pass: pts >= of.reqPoints },
        { lbl: "任务", need: "≥ " + of.reqMissions + " 起", pass: done >= of.reqMissions },
        { lbl: "机构", need: of.tierName || "县级驿站", pass: Officials.bureauOk(me.id, of) }
      ];
      const isHigher = cur && of.reqRankIdx > cur.reqRankIdx;
      const bossOnly = of.id === "OF6" && me.id !== "YG-0001";
      return `
        <div class="glass corner equip-card card-hover" style="animation:fadeUp .4s both;animation-delay:${i * 55}ms;${isCur ? "border-color:rgba(232,195,106,.55);box-shadow:0 0 22px rgba(232,195,106,.18)" : ""}">
          <div class="top">
            <div class="equip-ico" style="color:var(--gold)">${icon("medal")}</div>
            <div>
              <h3>${esc(of.name)} ${isCur ? '<span class="badge st-已完成" style="font-size:10.5px"><span class="dot"></span>现任</span>' : ""} ${bossOnly ? '<span class="badge st-专项任务" style="font-size:10.5px"><span class="dot"></span>统帅专属</span>' : ""}</h3>
              <div class="code">${of.id} · OFFICIAL POST</div>
            </div>
          </div>
          <p>${esc(of.desc)}</p>
          <p style="margin-top:8px;font-size:12.5px;color:var(--gold)">俸禄：任务冥币 +${of.coinBonus} / 次</p>
          <p style="margin-top:6px;font-size:12.5px;color:var(--cyan)">职权：${esc(of.perm || "—")} · 档案监察 +${of.clearBonus || 0}</p>
          <div class="tags" style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">
            ${reqs.map(r => `<span class="badge ${r.pass ? "st-已完成" : "st-叛逃"}" style="font-size:10.5px"><span class="dot"></span>${r.lbl} ${r.need}</span>`).join("")}
          </div>
          <div style="margin-top:14px">
            ${isCur
              ? `<button class="btn btn-ghost btn-sm btn-block" disabled>已在任</button>`
              : bossOnly
                ? `<button class="btn btn-sm btn-block" disabled style="opacity:.45;cursor:not-allowed" title="天御巡察使仅授全国最高统帅">统帅专属 · 不可申请</button>`
                : cur && !isHigher
                  ? `<button class="btn btn-sm btn-block" disabled style="opacity:.45;cursor:not-allowed">低于现任职务</button>`
                  : ok
                    ? `<button class="btn btn-primary btn-sm btn-block" data-apply="${of.id}">${cur ? "申请晋升改任" : "申请任职"}</button>`
                    : `<button class="btn btn-sm btn-block" disabled style="opacity:.45;cursor:not-allowed">条件未达成</button>`}
          </div>
        </div>`;
    }).join("");
  }

  grid.addEventListener("click", e => {
    const btn = e.target.closest("[data-apply]");
    if (!btn) return;
    const of = D.OFFICIALS.find(x => x.id === btn.dataset.apply);
    const cur = Officials.of(me.id);
    const isPromo = !!cur;
    const close = modal(`
      <h3 style="letter-spacing:2px;color:var(--gold)">${isPromo ? "晋升改任申请" : "任职申请"}</h3>
      <p style="margin-top:14px;font-size:13.5px;line-height:1.9">
        ${isPromo
          ? `申请由 <b style="color:var(--muted)">${esc(cur.name)}</b> 晋升改任 <b style="color:var(--gold)">${esc(of.name)}</b>？<br>
             <span style="color:var(--muted);font-size:12.5px">改任后原官职自动卸任，俸禄与职权即刻按新职务生效</span>`
          : `申请任职 <b style="color:var(--gold)">${esc(of.name)}</b>？<br>
             <span style="color:var(--muted);font-size:12.5px">任职后任务结算冥币 +${of.coinBonus} / 次，并获得对应职权；满足更高职务条件后可申请晋升改任</span>`}
      </p>
      <p style="margin-top:10px;font-size:12.5px;color:var(--cyan);line-height:1.8">职权：${esc(of.perm || "—")}<br>档案监察权限 +${of.clearBonus || 0}</p>
      <div style="display:flex;gap:10px;margin-top:20px">
        <button class="btn btn-primary btn-block" id="ofOk">确认申请</button>
        <button class="btn btn-ghost btn-block" id="ofNo">再想想</button>
      </div>
    `);
    document.getElementById("ofNo").addEventListener("click", close);
    document.getElementById("ofOk").addEventListener("click", () => {
      if (Officials.grant(me.id, of.id)) {
        close();
        toast({
          level: "green", icon: "check",
          title: isPromo ? "晋升改任成功" : "任职成功",
          text: isPromo ? `已卸任「${cur.name}」，就任「${of.name}」，新职权即刻生效` : `恭喜就任「${of.name}」，俸禄与职权即刻生效`
        });
        render();
      } else {
        close();
        toast({ level: "red", icon: "alarm", title: "申请失败", text: "未满足该职务的任职条件" });
      }
    });
  });

  render();
})();

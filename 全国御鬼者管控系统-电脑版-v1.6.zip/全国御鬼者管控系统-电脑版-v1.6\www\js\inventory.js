/* 我的背包 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { esc, icon, Inventory, Erosion, Profiles, toast } = window.YG;

  const me = Profiles.current();
  if (!me) return;
  const grid = document.getElementById("invGrid");

  function render() {
    const inv = Inventory.all(me.id);
    const entries = Object.keys(inv).map(eqId => {
      const eq = D.EQUIPMENTS.find(e => e.id === eqId);
      return eq ? { eq, cnt: inv[eqId] } : null;
    }).filter(Boolean);

    if (!entries.length) {
      grid.innerHTML = `<div class="glass empty" style="border-radius:14px;padding:60px 20px">
        背包空空如也<br><br>
        <span style="font-size:13px;color:var(--muted)">完成任务有概率掉落物资 · 也可前往<a href="shop.html" class="text-cyan" style="margin:0 4px">冥府商城</a>兑换</span>
      </div>`;
      return;
    }

    grid.innerHTML = entries.map(({ eq, cnt }, i) => {
      const eff = D.ITEM_EFFECTS[eq.id];
      const usable = !!eff && eff.type === "consume";
      const feedOnly = !!eff && eff.type === "feed";
      return `
        <div class="glass corner equip-card card-hover" style="animation:fadeUp .4s both;animation-delay:${i * 60}ms">
          <div class="top">
            <div class="equip-ico">${icon("cat-" + eq.category)}</div>
            <div class="equip-info">
              <h3>${esc(eq.name)}</h3>
              <div class="code">${eq.id} · ${esc(eq.category)}</div>
            </div>
            <span class="equip-cnt">×${cnt}</span>
          </div>
          <p>${eff ? esc(eff.desc) : esc(eq.func)}</p>
          <div class="equip-foot">
            <span class="badge lv-you">${esc(eq.rank)}</span>
            ${usable ? `<button class="btn btn-primary btn-sm" data-use="${eq.id}">使用</button>` : ""}
            ${feedOnly ? `<a class="btn btn-ghost btn-sm" href="ghosts-mine.html">前往喂养</a>` : ""}
          </div>
        </div>`;
    }).join("");
  }

  grid.addEventListener("click", e => {
    const btn = e.target.closest("[data-use]");
    if (!btn) return;
    const eqId = btn.dataset.use;
    const eff = D.ITEM_EFFECTS[eqId];
    const eq = D.EQUIPMENTS.find(x => x.id === eqId);
    if (!eff || !eq) return;

    const isPoints = typeof eff.points === "number";
    const before = Erosion.get(me.id);
    if (!isPoints && before <= 0) {
      toast({ level: "cyan", icon: "erosion", title: "状态良好", text: "当前侵蚀度为 0%，无需使用药剂" });
      return;
    }

    // 直接使用，不弹确认窗
    if (!Inventory.consume(me.id, eqId)) {
      toast({ level: "red", icon: "alarm", title: "使用失败", text: "道具数量不足" });
      return;
    }
    if (isPoints) {
      // 注入积分：以「功勋注入」任务记录形式写入扩展任务池
      const beforePts = window.YG.GameState.points(me.id);
      const key = "ITEM-" + Date.now();
      const extras = window.YG.GameState.extraMissions(me.id);
      extras.push({ id: key, name: eq.name + "记功", level: "D", place: "总局", points: eff.points, status: "已完成", desc: "高价值装备兑换功勋" });
      window.YG.GameState.setExtraMissions(me.id, extras);
      const all = window.YG.TaskState.all(me.id);
      all[key] = { status: "已完成", rating: "S", date: window.YG.today() };
      window.YG.Store.set(window.YG.TaskState.key(me.id), all);
      const afterPts = window.YG.GameState.points(me.id);
      const rank = D.RANKS[window.YG.GameState.effectiveRankIdx(me.id)];
      toast({
        level: "green", icon: "check",
        title: "记功成功",
        text: `${eq.name} 生效：积分 ${beforePts} → ${afterPts}（当前品级：${rank.name}）`
      });
    } else {
      Erosion.add(me.id, eff.erosion);
      const after = Erosion.get(me.id);
      toast({
        level: "green", icon: "check",
        title: "使用成功",
        text: `${eq.name} 生效：侵蚀度 ${before}% → ${after}%`
      });
    }
    render();
  });

  render();
})();

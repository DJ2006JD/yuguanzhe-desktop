/* 契约鬼灵仓库 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { esc, badge, ghostLevelCls, statusCls, icon, Profiles, MyGhosts, Inventory, Coins, FeatureLock, toast, modal, Explore } = window.YG;

  const me = Profiles.current();
  if (!me) return;
  if (!FeatureLock.guardPage("ghostsMine", "鬼灵仓库")) return;
  const grid = document.getElementById("myGhostGrid");
  const titleEl = document.getElementById("vaultTitle");

  /* 探索中的鬼灵集合 */
  let exploringSet = Explore.activeGids(me.id);
  let exploreTimer = null;

  function hungerBar(h) {
    const color = h <= 20 ? "var(--red)" : h <= 50 ? "var(--amber)" : "var(--green)";
    return `
      <div style="display:flex;align-items:center;gap:9px;margin-top:4px">
        <div class="bar" style="flex:1;height:7px"><i style="width:${h}%;background:${color};box-shadow:0 0 8px ${color}"></i></div>
        <span class="mono" style="font-size:12px;color:${color};width:38px;text-align:right">${h}</span>
      </div>`;
  }

  function cardHTML(mg, i) {
    const g = D.GHOSTS.find(x => x.id === mg.gid);
    if (!g) return "";
    const cls = ghostLevelCls(g.level);
    const hungry = mg.hunger <= 20;
    const foodCnt = Inventory.count(me.id, "EQ016");
    const coinCnt = Coins.get(me.id);
    const isExp = exploringSet.has(g.id);
    const expInfo = isExp ? Explore.get(me.id).find(e => e.gid === g.id && e.end > Date.now()) : null;
    const expLeft = expInfo ? Math.ceil((expInfo.end - Date.now()) / 1000) : 0;
    const canExp = !isExp && mg.hunger > 5;
    return `
      <div class="glass corner ghost-card card-hover ${cls}" style="animation-delay:${i * 60}ms;cursor:default" id="gc-${g.id}">
        <img class="ghost-img" src="${g.img}" alt="${esc(g.name)}" loading="lazy">
        <div class="top">
          <div class="ghost-rune">${esc(g.rune)}</div>
          <div>
            <h3>${esc(mg.nick)}${mg.nick !== g.name ? ` <small style="color:var(--faint);font-size:12px">(${esc(g.name)})</small>` : ""}</h3>
            <div class="code">${g.id} · 契约于 ${mg.date}</div>
          </div>
        </div>
        <div>
          <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--muted)">
            <span>饱食度${hungry ? ' <b style="color:var(--red)">饥饿 · 有逃逸风险</b>' : isExp ? ' <b style="color:var(--cyan)">探索中 · 消耗加速</b>' : ""}</span>
          </div>
          ${hungerBar(mg.hunger)}
        </div>
        <div class="foot" style="border-top:none;padding-top:0">
          <span>${badge(cls, g.level)}</span>
          ${badge(statusCls(g.status), g.status)}
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-primary btn-sm" data-act="feed-food" data-gid="${g.id}" style="flex:1"
            ${foodCnt > 0 ? "" : "disabled"}>口粮×1 ${foodCnt > 0 ? `(${foodCnt})` : ""}</button>
          <button class="btn btn-ghost btn-sm" data-act="feed-coin" data-gid="${g.id}" style="flex:1"
            ${coinCnt >= 30 ? "" : "disabled"}>供祭30币</button>
          <button class="btn btn-ghost btn-sm" data-act="rename" data-gid="${g.id}">改名</button>
          <button class="btn btn-danger btn-sm" data-act="release" data-gid="${g.id}">解约</button>
        </div>
        <div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--line)">
          ${isExp
            ? `<div style="font-size:12px;color:var(--cyan);letter-spacing:1px">探索中 · 剩余 <span class="mono exp-timer" data-gid="${g.id}" data-end="${expInfo.end}">${expLeft}</span> 秒</div>`
            : `<div style="display:flex;gap:6px;flex-wrap:wrap">
                <button class="btn btn-ghost btn-sm" data-act="explore" data-gid="${g.id}" data-dur="30" ${canExp ? "" : "disabled"}>短暂·30秒</button>
                <button class="btn btn-ghost btn-sm" data-act="explore" data-gid="${g.id}" data-dur="60" ${canExp ? "" : "disabled"}>深入·1分</button>
                <button class="btn btn-ghost btn-sm" data-act="explore" data-gid="${g.id}" data-dur="120" ${canExp ? "" : "disabled"}>远遁·2分</button>
                <button class="btn btn-ghost btn-sm" data-act="explore" data-gid="${g.id}" data-dur="180" ${canExp ? "" : "disabled"}>幽境·3分</button>
                ${!canExp ? `<span style="font-size:11px;color:var(--red);align-self:center">饥饿过低，无法探索</span>` : ""}
               </div>`}
        </div>
      </div>`;
  }

  /* 结算所有已到期的探索，弹出奖励提示 */
  function settleExplores() {
    const results = Explore.settle(me.id);
    if (!results.length) return;
    results.forEach(r => {
      const g = D.GHOSTS.find(x => x.id === r.gid);
      const parts = r.rewards.map(w => {
        if (w.type === "coin") return `冥币 +${w.val}`;
        if (w.type === "pts") return `积分 +${w.val}`;
        const it = D.EQUIPS.find(x => x.id === w.id);
        return `获得道具「${it ? it.name : w.id}」×1`;
      });
      toast({
        level: "gold", icon: "ghost", title: `「${g ? g.name : r.gid}」探索归来`,
        text: `${Explore.tierLabel(r.tier)} · ${parts.join("；")}`
      });
    });
  }

  /* 刷新探索中的鬼灵集合 + 定时更新倒计时 */
  function refreshExploring() {
    exploringSet = Explore.activeGids(me.id);
  }

  function startTimer() {
    if (exploreTimer) clearInterval(exploreTimer);
    exploreTimer = setInterval(() => {
      refreshExploring();
      // 更新倒计时显示
      document.querySelectorAll(".exp-timer").forEach(el => {
        const end = parseInt(el.dataset.end || "0", 10);
        const left = Math.max(0, Math.ceil((end - Date.now()) / 1000));
        el.textContent = left;
      });
      // 检查是否有探索完成
      const done = Explore.get(me.id).some(e => e.end <= Date.now());
      if (done) {
        settleExplores();
        render();
      }
    }, 1000);
  }

  function render() {
    const { list, escaped, backlash } = MyGhosts.all(me.id);
    const limit = MyGhosts.limit(me.id);
    titleEl.innerHTML = `我的契约鬼灵 <span style="font-size:12px;color:var(--muted);letter-spacing:1px;margin-left:10px">容量 ${list.length} / ${limit} · 饱食度随时间持续消耗（6点/天，探索中4倍） · 饥饿(≤20)每日 35% 概率反噬逃逸</span>`;

    escaped.forEach(gid => {
      const g = D.GHOSTS.find(x => x.id === gid);
      toast({ level: "red", icon: "alarm", title: "鬼灵反噬逃逸", text: `「${g ? g.name : gid}」长期饥饿，已挣脱契约逃离仓库` });
    });
    if (backlash > 0) {
      toast({ level: "red", icon: "erosion", title: "契约反噬", text: `鬼灵逃逸反噬心神，侵蚀度 +${backlash}%（当前 ${window.YG.Erosion.get(me.id)}%）` });
    }

    if (!list.length) {
      grid.innerHTML = `<div class="glass empty" style="border-radius:14px;padding:60px 20px">
        仓库空空如也<br><br>
        <span style="font-size:13px;color:var(--muted)">完成任务时有概率触发「机缘 · 鬼怪现身」，可契约鬼灵入住仓库</span><br><br>
        <a href="tasks.html" class="btn btn-primary btn-sm">前往任务大厅</a>
      </div>`;
      return;
    }
    refreshExploring();
    grid.innerHTML = list.map(cardHTML).join("");
  }

  grid.addEventListener("click", e => {
    const btn = e.target.closest("[data-act]");
    if (!btn) return;
    const gid = btn.dataset.gid;
    const g = D.GHOSTS.find(x => x.id === gid);
    const mg = MyGhosts.all(me.id).list.find(x => x.gid === gid);
    if (!g || !mg) return;

    /* ---------- 喂养（直接执行，不弹窗） ---------- */
    if (btn.dataset.act === "feed-food" || btn.dataset.act === "feed-coin") {
      if (btn.disabled) return;
      if (btn.dataset.act === "feed-food") {
        if (!Inventory.consume(me.id, "EQ016")) {
          toast({ level: "red", icon: "alarm", title: "口粮不足", text: "背包内没有阴灵口粮，可去冥府商城兑换" });
          return;
        }
        MyGhosts.feed(me.id, gid, 40);
        toast({ level: "green", icon: "ghost", title: "喂养成功", text: `「${mg.nick}」饱食度 +40，契约更加稳固` });
      } else {
        if (!Coins.spend(me.id, 30)) {
          toast({ level: "red", icon: "alarm", title: "冥币不足", text: "供祭需要 30 冥币，请前往任务大厅赚取" });
          return;
        }
        MyGhosts.feed(me.id, gid, 25);
        toast({ level: "green", icon: "ghost", title: "供祭完成", text: `「${mg.nick}」饱食度 +25，冥币 -30` });
      }
      render();
      return;
    }

    /* ---------- 改名 ---------- */
    if (btn.dataset.act === "rename") {
      const close = modal(`
        <h3 style="letter-spacing:2px">契约鬼灵改名</h3>
        <p style="margin-top:14px;font-size:13px;color:var(--muted)">为「${esc(g.name)}」取一个专属称谓</p>
        <input class="input" id="nickInput" maxlength="10" value="${esc(mg.nick)}" style="margin-top:12px">
        <div style="display:flex;gap:10px;margin-top:20px">
          <button class="btn btn-primary btn-block" id="nickOk">确认</button>
          <button class="btn btn-ghost btn-block" id="nickNo">取消</button>
        </div>
      `);
      document.getElementById("nickNo").addEventListener("click", close);
      document.getElementById("nickOk").addEventListener("click", () => {
        MyGhosts.rename(me.id, gid, document.getElementById("nickInput").value.trim());
        close(); render();
      });
      return;
    }

    /* ---------- 解约 ---------- */
    if (btn.dataset.act === "release") {
      const close = modal(`
        <h3 style="color:var(--red);letter-spacing:2px">解除契约确认</h3>
        <p style="margin-top:14px;font-size:13.5px;line-height:1.9">
          将与 <b class="text-cyan">${esc(mg.nick)}（${esc(g.name)}）</b> 解除契约，鬼灵将放归阴隙。<br>
          <b style="color:var(--red)">解约后无法找回，确认执行？</b>
        </p>
        <div style="display:flex;gap:10px;margin-top:20px">
          <button class="btn btn-danger btn-block" id="relOk">确认解约</button>
          <button class="btn btn-ghost btn-block" id="relNo">取消</button>
        </div>
      `);
      document.getElementById("relNo").addEventListener("click", close);
      document.getElementById("relOk").addEventListener("click", () => {
        MyGhosts.remove(me.id, gid);
        close();
        toast({ level: "amber", icon: "ghost", title: "契约已解除", text: `「${mg.nick}」已放归阴隙，契约容量已释放` });
        render();
      });
    }

    /* ---------- 探索机缘 ---------- */
    if (btn.dataset.act === "explore") {
      if (btn.disabled) return;
      const dur = parseInt(btn.dataset.dur || "30", 10);
      if (Explore.start(me.id, gid, dur)) {
        toast({ level: "cyan", icon: "ghost", title: `「${mg.nick}」已出发探索`, text: `预计 ${dur} 秒后归来，探索期间饱食度加速消耗` });
        render();
      } else {
        toast({ level: "red", icon: "alarm", title: "探索失败", text: "该鬼灵正在探索中" });
      }
    }
  });

  settleExplores();
  render();
  startTimer();
})();

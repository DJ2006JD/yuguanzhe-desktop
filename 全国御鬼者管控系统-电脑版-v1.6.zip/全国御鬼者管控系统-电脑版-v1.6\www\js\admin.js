/* 后台管理（分级权限）
   - YG-0001 总署长：全国账号、品级敕令、晋升难度等全部功能
   - YG-0002 起各部门最高领导（密钥 666666）：仅管理本部门账号（创建/关联/删除/重置/净化/发物资/嘉奖/派任务），
     看不到其他部门，也没有品级定级、晋升难度等总署权限 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const {
    esc, badge, rankCls, Users, Profiles, Inventory, Erosion, GameState, Store,
    isAdmin, isTopAdmin, adminScope, canManage, isProtectedId, seedLeader,
    toast, modal, Discipline, me: _me
  } = Object.assign({ me: null }, window.YG);

  if (!isAdmin()) {
    location.replace("dashboard.html");
    return;
  }
  const boot = (window.YG.Sync ? window.YG.Sync.ready : Promise.resolve());
  boot.then(() => {
  const me = Profiles.current();
  if (!me) return;

  const top = isTopAdmin(me.id);
  const scope = adminScope(me.id); // {all:true} 或 {all:false,bureau}

  // 部门领导：隐藏总署专属区块（品级定级敕令、晋升难度全局配置）
  if (!top) {
    document.querySelectorAll("[data-toponly]").forEach(el => { el.style.display = "none"; });
    const head = document.querySelector(".page-head h1");
    const sub = document.querySelector(".page-head p");
    if (head) head.textContent = "机构后台管理";
    if (sub) sub.textContent = "AGENCY ADMIN · 仅限本机构账号管理";
  }

  const tbody = document.querySelector("#adminTable tbody");

  function rowHTML(p) {
    const pts = GameState.points(p.id);
    const ero = p.erosion; // 档案动态侵蚀度（Profiles 已融合日期波动）
    const linked = !!Users.find(p.id); // 是否已有登录账号
    const isBoss = p.id === "YG-0001";
    const lead = seedLeader(p.id);
    let tag = "";
    if (isBoss) tag = '<div style="font-size:11px;color:var(--gold);margin-top:2px">最高权限 · 总署长</div>';
    else if (lead) tag = `<div style="font-size:11px;color:var(--gold);margin-top:2px">${esc(lead.leaderTitle || "所属机构 · 最高领导")}</div>`;
    else if (!linked) tag = '<div style="font-size:11px;color:var(--faint);margin-top:2px">备案在册 · 未开账号</div>';
    // 最高权限账号（总署长）可管理任何账号（含各机构领导），仅不能操作自己；机构领导维持本机构范围且不可动其他领导
    const manageable = top
      ? (p.id !== me.id && p.id !== "YG-0001")
      : (canManage(me.id, p.id) && p.id !== me.id && !isProtectedId(p.id));
    return `
      <tr>
        <td class="mono">${p.id}</td>
        <td><b style="color:var(--text-bright)">${esc(p.name)}</b>${tag}</td>
        <td>${badge(rankCls(p.rankIdx), D.RANKS[p.rankIdx].name)}</td>
        <td class="mono" style="color:var(--amber)">${pts}</td>
        <td class="mono" style="color:${ero > 80 ? "var(--red)" : ero >= 60 ? "var(--amber)" : "var(--cyan)"}">${ero}%</td>
        <td>${linked
          ? '<span class="badge st-已完成" style="font-size:10.5px"><span class="dot"></span>已关联</span>'
          : '<span class="badge st-通缉" style="font-size:10.5px"><span class="dot"></span>未关联</span>'}</td>
        <td>
          ${!linked && manageable ? `<button class="btn btn-sm btn-primary" data-act="link" data-id="${p.id}" title="为该档案创建登录账号">关联账号</button>` : ""}
          ${(top || canManage(me.id, p.id) || p.id === me.id) ? `<button class="btn btn-sm btn-ghost" data-act="clearEro" data-id="${p.id}" title="侵蚀度清零">净化</button>` : ""}
          ${manageable ? `<button class="btn btn-sm btn-ghost" data-act="resetUser" data-id="${p.id}" title="清空该用户游戏数据">重置</button>` : ""}
          ${manageable ? `<button class="btn btn-sm btn-danger" data-act="delUser" data-id="${p.id}" title="删除该账号，档案从名录中彻底清除">删除</button>` : ""}
        </td>
      </tr>`;
  }

  // 管理列表：总署看全国；机构领导只看本机构下辖全部单位（如省级领导统管四省分局），按编号升序
  // 注意：1号编制虽挂镇狱司，但属国家级账号，不出现在任何机构领导视图中
  function managedProfiles() {
    const all = Profiles.all();
    const idNum = p => parseInt(String(p.id).replace(/\D/g, ""), 10) || 999999;
    return (top ? all : all.filter(p =>
      D.orgIdOfBureau(p.bureau) === scope.orgId && (p.id === me.id || !isProtectedId(p.id))
    )).sort((a, b) => idNum(a) - idNum(b));
  }
  // 该领导可派驻的具体机构（省级领导下辖多个分局，其余机构仅一个）
  function ownBureaus() {
    return D.BUREAUS.filter(b => D.orgIdOfBureau(b) === scope.orgId);
  }
  // 可选目标池：总署 = 全国所有账号（含各机构领导、含自己）；机构领导 = 本机构（不含其他领导/1号/自己）
  function targetProfiles() {
    return top
      ? managedProfiles()
      : managedProfiles().filter(p => p.id !== me.id && !isProtectedId(p.id));
  }

  /* ---- 目标 picker：输入编号/姓名，弹出信息卡，取值用 picker.id() ---- */
  function bindTarget(inputId, getList) {
    const input = document.getElementById(inputId);
    const card = document.getElementById(inputId + "Card");
    let sel = null;
    function find(q) {
      q = q.trim().toUpperCase();
      if (!q) return null;
      const list = getList();
      return list.find(p => p.id.toUpperCase() === q)
          || list.find(p => p.name === q.trim())
          || list.find(p => p.id.toUpperCase().includes(q) || p.name.includes(q.trim()))
          || null;
    }
    function render() {
      const q = (input.value || "").trim();
      if (!q) { card.style.display = "none"; sel = null; return; }
      sel = find(q);
      card.style.display = "block";
      if (!sel) {
        card.className = "target-card miss";
        card.textContent = "未找到匹配账号（仅限你可管理的范围）";
        return;
      }
      card.className = "target-card";
      const pts = GameState.points(sel.id);
      card.innerHTML = `<b>${esc(sel.name)}</b> <span class="mono">${sel.id}</span> · ${esc(D.RANKS[sel.rankIdx].name)} · 积分 <span class="mono">${pts}</span> · 侵蚀 <span class="mono">${sel.erosion}%</span>${sel.id === me.id ? ' <span style="color:var(--gold)">（本人）</span>' : ""}`;
    }
    input.addEventListener("input", render);
    input.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); render(); } });
    return {
      id() { render(); if (!sel) toast({ level: "red", icon: "alarm", title: "未选定目标", text: "请输入有效编号或姓名" }); return sel ? sel.id : null; },
      clear() { input.value = ""; card.style.display = "none"; sel = null; }
    };
  }
  const grantPicker = bindTarget("grantTarget", targetProfiles);
  const ptsPicker = bindTarget("ptsTarget", targetProfiles);
  const pubPicker = bindTarget("pubTarget", targetProfiles);
  // 品级敕令（仅总署可见）：1号可给任何人含自己定级
  const rankPicker = bindTarget("rankTarget", () => managedProfiles());
  function refreshTargets() { /* picker 实时解析，无需预填 */ }

  function renderTable() {
    const q = (document.getElementById("adminSearch").value || "").trim().toUpperCase();
    let list = managedProfiles();
    const titleEl = document.getElementById("adminCount");
    if (q) {
      // 搜索时：全量匹配（编号 / 姓名）
      list = list.filter(p => p.id.toUpperCase().includes(q) || p.name.includes(q));
    } else {
      // 默认折叠：只显示管理账号（1号 + 各机构领导）与最新备案且已开通登录账号的 10 个账号；
      // 未关联（未开账号）的档案默认不显示，搜索编号/姓名才出现
      const adminIds = new Set(["YG-0001"].concat(
        (D.SEED_PROFILES || []).filter(p => p.leader).map(p => p.id)));
      const idNum = p => parseInt(String(p.id).replace(/\D/g, ""), 10) || 999999;
      const newest = list.filter(p => !adminIds.has(p.id) && Users.find(p.id))
        .sort((a, b) => (b.joinDate || "").localeCompare(a.joinDate || "") || idNum(b) - idNum(a))
        .slice(0, 10);
      list = list.filter(p => adminIds.has(p.id) || newest.includes(p));
    }
    tbody.innerHTML = list.length
      ? list.map(rowHTML).join("")
      : `<tr><td colspan="7" style="text-align:center;color:var(--muted);padding:20px">无匹配账号</td></tr>`;
    if (titleEl) {
      titleEl.textContent = q
        ? `（搜索结果 ${list.length} 人）`
        : `（默认显示管理账号与最新账号 ${list.length} 人 · 搜索编号/姓名查看全部）`;
    }
  }
  document.getElementById("adminSearch").addEventListener("input", renderTable);

  /* ---- 殉职名单：复活 ---- */
  function renderDead() {
    const dead = Discipline.deadList();
    const dtb = document.querySelector("#deadTable tbody");
    const empty = document.getElementById("deadEmpty");
    if (!dtb) return;
    dtb.innerHTML = dead.map(d => `
      <tr>
        <td class="mono">${d.id}</td>
        <td><b style="color:var(--text-bright)">${esc(d.name)}</b></td>
        <td style="color:var(--muted)">${esc(d.bureau || "—")}</td>
        <td class="mono" style="color:var(--red)">${esc(d.date || "—")}</td>
        <td><button class="btn btn-sm btn-primary" data-revive="${d.id}">复活</button></td>
      </tr>`).join("");
    if (empty) empty.style.display = dead.length ? "none" : "block";
    const tbl = document.getElementById("deadTable");
    if (tbl) tbl.style.display = dead.length ? "" : "none";
  }
  document.getElementById("deadWrap").addEventListener("click", e => {
    const btn = e.target.closest("[data-revive]");
    if (!btn) return;
    const uid = btn.dataset.revive;
    if (Discipline.revive(uid)) {
      const restored = Users.find(uid);
      toast({ level: "green", icon: "check", title: "复活成功", text: `账号 ${uid} 已恢复登录，原密钥不变，侵蚀度降至 50%` });
      renderDead();
      renderTable();
    } else {
      toast({ level: "red", icon: "alarm", title: "复活失败", text: "该编号已存在或不在殉职名单中" });
    }
  });

  // 生成 6 位随机初始密钥
  function genPwd() { return String(Math.floor(100000 + Math.random() * 900000)); }

  // 添加账号（机构领导只能往本机构下辖单位添加；下辖多个分局时可下拉选择）
  document.getElementById("addUserBtn")?.addEventListener("click", () => {
    let bureauField;
    if (top) {
      bureauField = `<div class="form-field">
           <label>所属机构</label>
           <select class="input" id="newBureau">
             ${D.BUREAUS.map(b => `<option value="${esc(b)}">${esc(b)}</option>`).join("")}
           </select>
         </div>`;
    } else {
      const bs = ownBureaus();
      bureauField = bs.length > 1
        ? `<div class="form-field">
             <label>所属机构</label>
             <select class="input" id="newBureau">
               ${bs.map(b => `<option value="${esc(b)}">${esc(b)}</option>`).join("")}
             </select>
           </div>`
        : `<div class="form-field">
             <label>所属机构</label>
             <input class="input" id="newBureau" value="${esc(bs[0] || scope.bureau)}" disabled>
           </div>`;
    }
    const close = modal(`
      <h3 style="letter-spacing:2px">${top ? "添加御鬼者账号" : "添加本机构账号"}</h3>
      <div style="display:flex;flex-direction:column;gap:12px;margin-top:18px">
        <div class="form-field">
          <label>编号 <small style="color:var(--muted)">留空则系统随机分配</small></label>
          <input class="input" id="newId" maxlength="10" placeholder="如 YG-2026" style="font-family:var(--mono)">
        </div>
        <div class="form-field">
          <label>姓名 <span style="color:var(--red)">*</span></label>
          <input class="input" id="newName" maxlength="10" placeholder="御鬼者姓名">
        </div>
        <div class="form-field">
          <label>初始密钥 <small style="color:var(--muted)">留空则系统随机分配</small></label>
          <input class="input" id="newPwd" maxlength="20" placeholder="登录密码">
        </div>
        ${bureauField}
      </div>
      <div style="display:flex;gap:10px;margin-top:24px">
        <button class="btn btn-primary btn-block" id="newOk">创建</button>
        <button class="btn btn-ghost btn-block" id="newNo">取消</button>
      </div>
    `);
    document.getElementById("newNo").addEventListener("click", close);
    document.getElementById("newOk").addEventListener("click", async () => {
      const name = (document.getElementById("newName").value || "").trim();
      if (!name) { toast({ level: "red", icon: "alarm", title: "信息不全", text: "请填写御鬼者姓名" }); return; }
      let id = (document.getElementById("newId").value || "").trim().toUpperCase();
      if (id && !/^YG-\d+$/.test(id)) { toast({ level: "red", icon: "alarm", title: "编号格式错误", text: "编号须以 YG- 开头并接数字" }); return; }
      if (id && (Users.find(id) || D.SEED_PROFILES.some(s => s.id === id))) { toast({ level: "red", icon: "alarm", title: "编号冲突", text: `编号 ${id} 已存在` }); return; }
      let pwd = (document.getElementById("newPwd").value || "").trim();
      if (!id) { id = Users.genId(); }
      if (!pwd) { pwd = genPwd(); }
      const bureauEl = document.getElementById("newBureau");
      const bureau = top || ownBureaus().length > 1 ? bureauEl.value : (bureauEl.value || scope.bureau);
      if (!top && D.orgIdOfBureau(bureau) !== scope.orgId) { toast({ level: "red", icon: "alarm", title: "越权操作", text: "只能向本机构下辖单位添加账号" }); return; }
      const r = await Users.add({ id, name, password: pwd, bureau, createdAt: new Date().toISOString().slice(0, 10) });
      if (r && r.ok === false) { toast({ level: "red", icon: "alarm", title: "编号冲突", text: `编号 ${id} 已存在，请换一个编号` }); return; }
      toast({ level: "green", icon: "check", title: "创建成功", text: `已添加 ${name}（${id}），初始密钥：${pwd}` });
      close();
      renderTable();
      refreshTargets();
    });
  });

  // 发放物资
  const grantItem = document.getElementById("grantItem");
  const grantNum = document.getElementById("grantNum");
  grantItem.innerHTML = D.EQUIPMENTS.filter(e => e.category === "药剂耗材类")
    .map(e => `<option value="${e.id}">${esc(e.name)}</option>`).join("");

  document.getElementById("grantBtn").addEventListener("click", () => {
    const uid = grantPicker.id();
    if (!uid) return;
    if (!canManage(me.id, uid)) { toast({ level: "red", icon: "alarm", title: "越权操作", text: "只能向本机构成员发放物资" }); return; }
    const eqId = grantItem.value;
    const n = Math.max(1, Math.min(99, parseInt(grantNum.value) || 1));
    Inventory.add(uid, eqId, n);
    const eq = D.EQUIPMENTS.find(e => e.id === eqId);
    const u = Profiles.find(uid);
    toast({ level: "green", icon: "check", title: "发放成功", text: `已向 ${u.name} 发放「${eq.name}」×${n}` });
    renderTable();
  });

  // 品级定级（仅总署，可给任何人含自己）
  const rankLevel = document.getElementById("rankLevel");
  if (top) {
    rankLevel.innerHTML = D.RANKS.map(r => `<option value="${r.idx}">${r.name}</option>`).join("");
    document.getElementById("rankBtn").addEventListener("click", () => {
      const uid = rankPicker.id();
      if (!uid) return;
      if (!canManage(me.id, uid) && uid !== me.id) { toast({ level: "red", icon: "alarm", title: "越权操作", text: "无权调整该账号品级" }); return; }
      const prof = Profiles.find(uid);
      if (!prof) return;
      const targetIdx = parseInt(rankLevel.value);
      const r = GameState.setRank(uid, targetIdx);
      toast({ level: "green", icon: "check", title: "定级敕令已颁布", text: `${prof.name} 品级由「${r.old.name}」调整为「${r.now.name}」` });
      renderTable();
    });
  }

  // 积分调整（注入嘉奖记录）
  const ptsNum = document.getElementById("ptsNum");
  document.getElementById("ptsBtn").addEventListener("click", () => {
    const uid = ptsPicker.id();
    if (!uid) return;
    if (!canManage(me.id, uid)) { toast({ level: "red", icon: "alarm", title: "越权操作", text: "只能嘉奖本机构成员" }); return; }
    const delta = parseInt(ptsNum.value) || 0;
    if (!delta) return;
    const u = Profiles.find(uid);
    if (delta > 0) {
      const key = "ADMIN-" + Date.now();
      const all = window.YG.TaskState.all(uid);
      all[key] = { status: "已完成", rating: "S", date: window.YG.today() };
      const extras = GameState.extraMissions(uid);
      extras.push({ id: key, name: "系统嘉奖积分", level: "D", place: top ? "总局" : "本机构", points: delta, status: "已完成", desc: "管理员手动发放的积分嘉奖" });
      GameState.setExtraMissions(uid, extras);
      window.YG.Store.set(window.YG.TaskState.key(uid), all);
    } else {
      toast({ level: "amber", icon: "alarm", title: "暂不支持扣分", text: "请联系监察部门走扣分流程" });
      return;
    }
    toast({ level: "green", icon: "check", title: "调整成功", text: `${u.name} 积分 +${delta}` });
    renderTable();
  });

  // 表格操作
  tbody.addEventListener("click", e => {
    const btn = e.target.closest("[data-act]");
    if (!btn) return;
    const uid = btn.dataset.id;
    const p = Profiles.find(uid);
    const act = btn.dataset.act;
    if (!p) return;

    if (act === "link") {
      if (!canManage(me.id, uid)) { toast({ level: "red", icon: "alarm", title: "越权操作", text: "只能为本机构成员开通账号" }); return; }
      if (Users.find(uid)) { renderTable(); return; }
      const pwd = genPwd();
      Users.add({ id: uid, name: p.name, password: pwd, bureau: p.bureau || (top ? null : ownBureaus()[0]) || scope.bureau, createdAt: new Date().toISOString().slice(0, 10) }).then(r => {
        if (r && r.ok === false) { toast({ level: "red", icon: "alarm", title: "关联失败", text: "该编号已被占用" }); return; }
        toast({ level: "green", icon: "check", title: "关联成功", text: `已为 ${p.name} 创建登录账号，初始密钥：${pwd}` });
      });
      renderTable();
      refreshTargets();
      return;
    }

    if (act === "clearEro") {
      if (!(top || canManage(me.id, uid) || uid === me.id)) { toast({ level: "red", icon: "alarm", title: "越权操作", text: "只能净化本机构成员" }); return; }
      Erosion.set(uid, 0);
      toast({ level: "green", icon: "check", title: "净化完成", text: `${p.name} 侵蚀度已清零` });
      renderTable();
    } else if (act === "delUser") {
      if (uid === "YG-0001" || uid === me.id || !canManage(me.id, uid) || (!top && isProtectedId(uid))) {
        toast({ level: "red", icon: "alarm", title: "不可删除", text: "无权删除该账号（最高权限账号与本人账号不可删除）" }); return;
      }
      const close = modal(`
        <h3 style="color:var(--red)">删除账号确认</h3>
        <p style="margin-top:14px;font-size:13.5px;line-height:1.9">
          将删除 <b class="text-cyan">${esc(p.name)}（${p.id}）</b> 的登录账号、档案及其全部游戏数据。<br>
          <span style="color:var(--muted);font-size:12.5px">删除后该账号直接从系统名录中清除，不再展示</span><br><br>
          <b style="color:var(--red)">此操作不可撤销，确认执行？</b>
        </p>
        <div style="display:flex;gap:10px;margin-top:20px">
          <button class="btn btn-danger btn-block" id="delOk">确认删除</button>
          <button class="btn btn-ghost btn-block" id="delNo">取消</button>
        </div>
      `);
      document.getElementById("delNo").addEventListener("click", close);
      document.getElementById("delOk").addEventListener("click", () => {
        if (Users.remove(uid, top)) {
          ["ygu_tasks_", "ygu_items_", "ygu_promos_", "ygu_extra_missions_", "ygu_erosion_", "ygu_rank_ack_", "ygu_coins_", "ygu_ghosts_", "ygu_official_", "ygu_explore_"]
            .forEach(k => Store.remove(k + uid));
          Profiles.markDeleted(uid); // 档案直接清除出名录
          toast({ level: "green", icon: "check", title: "已删除", text: `${p.name} 的账号与档案已彻底清除` });
        } else {
          toast({ level: "red", icon: "alarm", title: "删除失败", text: "最高权限账号不可删除" });
        }
        close();
        renderTable();
        refreshTargets();
      });
    } else if (act === "resetUser") {
      if (uid === "YG-0001" || uid === me.id || !canManage(me.id, uid) || (!top && isProtectedId(uid))) {
        toast({ level: "red", icon: "alarm", title: "不可重置", text: "无权重置该账号" }); return;
      }
      const close = modal(`
        <h3 style="color:var(--red)">危险操作确认</h3>
        <p style="margin-top:14px;font-size:13.5px;line-height:1.9">
          将清空 <b class="text-cyan">${esc(p.name)}（${p.id}）</b> 的：<br>
          任务记录、道具背包、晋升记录、侵蚀度<br><br>
          <b style="color:var(--red)">此操作不可撤销，确认执行？</b>
        </p>
        <div style="display:flex;gap:10px;margin-top:20px">
          <button class="btn btn-danger btn-block" id="resetOk">确认重置</button>
          <button class="btn btn-ghost btn-block" id="resetNo">取消</button>
        </div>
      `);
      document.getElementById("resetNo").addEventListener("click", close);
      document.getElementById("resetOk").addEventListener("click", () => {
        ["ygu_tasks_", "ygu_items_", "ygu_promos_", "ygu_extra_missions_", "ygu_erosion_", "ygu_rank_ack_", "ygu_coins_", "ygu_ghosts_", "ygu_explore_"]
          .forEach(k => Store.remove(k + uid));
        close();
        toast({ level: "green", icon: "check", title: "重置完成", text: `${p.name} 的游戏数据已清空` });
        renderTable();
      });
    }
  });

  // 重置当前账号
  document.getElementById("resetBtn").addEventListener("click", () => {
    const close = modal(`
      <h3 style="color:var(--red)">重置当前账号</h3>
      <p style="margin-top:14px;font-size:13.5px;line-height:1.9">
        将清空 <b>${esc(me.name)}（${me.id}）</b> 的全部游戏数据，包括任务、背包、晋升记录。<br>
        <b style="color:var(--red)">确认执行？</b>
      </p>
      <div style="display:flex;gap:10px;margin-top:20px">
        <button class="btn btn-danger btn-block" id="selfResetOk">确认重置</button>
        <button class="btn btn-ghost btn-block" id="selfResetNo">取消</button>
      </div>
    `);
    document.getElementById("selfResetNo").addEventListener("click", close);
    document.getElementById("selfResetOk").addEventListener("click", () => {
      ["ygu_tasks_", "ygu_items_", "ygu_promos_", "ygu_extra_missions_", "ygu_erosion_", "ygu_rank_ack_", "ygu_coins_", "ygu_ghosts_", "ygu_explore_"]
        .forEach(k => Store.remove(k + me.id));
      close();
      toast({ level: "green", icon: "check", title: "重置完成", text: "当前账号数据已恢复初始状态，即将刷新" });
      setTimeout(() => location.reload(), 1200);
    });
  });

  // ================= 发布任务 · 嘉奖令（总署可发全国，部门领导仅发本部门） =================
  const pubItem = document.getElementById("pubItem");
  const pubGhost = document.getElementById("pubGhost");
  const pubReqRank = document.getElementById("pubReqRank");
  pubReqRank.innerHTML = `<option value="">按任务等级默认</option>` +
    D.RANKS.map(r => `<option value="${r.idx}">需 ${r.name}</option>`).join("");
  pubItem.innerHTML = `<option value="">— 无 —</option>` +
    D.EQUIPMENTS.map(e => `<option value="${e.id}">${esc(e.name)}</option>`).join("");
  pubGhost.innerHTML = `<option value="">— 无 —</option>` +
    D.GHOSTS.map(g => `<option value="${g.id}">${esc(g.name)}（${g.level}）</option>`).join("");

  document.getElementById("pubBtn").addEventListener("click", () => {
    const uid = pubPicker.id();
    if (!uid) return;
    if (!canManage(me.id, uid)) { toast({ level: "red", icon: "alarm", title: "越权操作", text: "只能向本机构成员下达任务" }); return; }
    const name = (document.getElementById("pubName").value || "").trim();
    if (!name) { toast({ level: "red", icon: "alarm", title: "信息不全", text: "请填写任务名称" }); return; }
    const level = document.getElementById("pubLevel").value;
    const place = (document.getElementById("pubPlace").value || "").trim() || (top ? "总局指派" : "本机构指派");
    const points = Math.max(10, Math.min(5000, parseInt(document.getElementById("pubPoints").value) || 100));
    const coins = Math.max(0, Math.min(9999, parseInt(document.getElementById("pubCoins").value) || 0));
    const eqId = pubItem.value;
    const eqNum = Math.max(1, Math.min(10, parseInt(document.getElementById("pubItemNum").value) || 1));
    const ghostId = pubGhost.value;
    const desc = (document.getElementById("pubDesc").value || "").trim() || (top ? "总局直接下达的嘉奖任务，完成后额外奖励即刻到账" : "本机构直接下达的嘉奖任务，完成后额外奖励即刻到账");

    const rewards = {};
    if (coins > 0) rewards.coins = coins;
    if (eqId) rewards.items = [{ id: eqId, n: eqNum }];
    if (ghostId) rewards.ghostId = ghostId;

    const mid = "ADM-" + Date.now();
    const extras = GameState.extraMissions(uid);
    const m = { id: mid, name, level, place, points, status: "待领取", desc, rewards: Object.keys(rewards).length ? rewards : undefined, issuer: me.id };
    if (pubReqRank.value !== "") m.reqRankIdx = parseInt(pubReqRank.value);
    extras.push(m);
    GameState.setExtraMissions(uid, extras);

    const u = Profiles.find(uid);
    toast({ level: "green", icon: "check", title: "嘉奖令已下达", text: `「${name}」（${level}级）已下发至 ${u.name} 的任务大厅` });
    document.getElementById("pubName").value = "";
    document.getElementById("pubDesc").value = "";
  });

  // ================= 晋升难度管理（仅总署） =================
  if (top) {
    const GHOST_GATE_OPTS = ['<option value="">— 无 —</option>']
      .concat(D.GHOST_LEVELS.map(l => `<option value="${l.name}">${l.name}</option>`)).join("");

    function renderRankCfg() {
      const reqs = GameState.rankReqs();
      const gates = GameState.ghostReqs();
      const tbodyCfg = document.querySelector("#rankCfgTable tbody");
      tbodyCfg.innerHTML = D.RANKS.filter(r => r.idx > 0).map(r => `
        <tr>
          <td>${badge(rankCls(r.idx), r.name)}</td>
          <td><input type="number" class="input" style="width:120px;font-family:var(--mono)" data-cfg-pts="${r.idx}"
               value="${reqs[r.idx]}" min="1" step="50"></td>
          <td><select class="input" style="width:130px" data-cfg-ghost="${r.idx}">
            ${GHOST_GATE_OPTS.replace(`value="${gates[r.idx] || ""}"`, `value="${gates[r.idx] || ""}" selected`)}
          </select></td>
        </tr>`).join("");
    }

    document.getElementById("rankCfgSave").addEventListener("click", () => {
      const cfg = { points: {}, ghost: {} };
      document.querySelectorAll("[data-cfg-pts]").forEach(inp => {
        const idx = inp.dataset.cfgPts;
        const v = parseInt(inp.value);
        const def = D.RANKS.find(r => r.idx === Number(idx)).points;
        if (v > 0 && v !== def) cfg.points[idx] = v;
      });
      document.querySelectorAll("[data-cfg-ghost]").forEach(sel => {
        const idx = sel.dataset.cfgGhost;
        const def = (D.PROMO_GHOST_REQ || {})[idx] || "";
        if (sel.value !== def) cfg.ghost[idx] = sel.value;
      });
      GameState.setRankCfg(cfg);
      toast({ level: "green", icon: "check", title: "已保存", text: "晋升难度配置已生效，全系统即时应用" });
    });

    document.getElementById("rankCfgReset").addEventListener("click", () => {
      GameState.setRankCfg({ points: {}, ghost: {} });
      renderRankCfg();
      toast({ level: "cyan", icon: "check", title: "已恢复默认", text: "晋升难度已重置为系统默认值" });
    });

    renderRankCfg();
  }

  renderTable();
  renderDead();
  refreshTargets();

  // 联网版：其他设备注册账号或资料变更时，名录实时刷新（单机版无此事件，监听空转）
  let netTimer = null;
  window.addEventListener("yg-net-update", () => {
    if (netTimer) clearTimeout(netTimer);
    netTimer = setTimeout(() => { try { renderTable(); renderDead(); } catch (e) {} }, 300);
  });
  window.addEventListener("yg-net-ready", () => { try { renderTable(); renderDead(); } catch (e) {} });
  }); // boot.ready
})();

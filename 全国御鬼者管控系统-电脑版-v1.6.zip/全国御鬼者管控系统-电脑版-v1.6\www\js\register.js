/* 注册页交互 */
(function () {
  "use strict";
  const { Users, icon, esc, modal } = window.YG;
  const D = window.YG_DATA;

  document.getElementById("authLogo").innerHTML = icon("logo");

  /* ---------- 所属机构下拉（与组织架构 7 个机构一致） ---------- */
  const bureauSel = document.getElementById("regBureau");
  bureauSel.innerHTML = D.REGISTER_ORGS.map(o =>
    `<option value="${esc(o.name)}">${esc(o.name)}（${esc(o.type)}）</option>`).join("");

  const form = document.getElementById("regForm");
  const btn = document.getElementById("regBtn");
  const fields = {
    id: document.getElementById("regId"),
    name: document.getElementById("regName"),
    pw: document.getElementById("regPw"),
    pw2: document.getElementById("regPw2")
  };
  const errs = {
    id: document.getElementById("errId"),
    name: document.getElementById("errName"),
    pw: document.getElementById("errPw"),
    pw2: document.getElementById("errPw2")
  };

  function setField(key, state, msg) {
    fields[key].classList.toggle("ok", state === "ok");
    fields[key].classList.toggle("err", state === "err");
    errs[key].textContent = msg || "";
  }

  /* ---------- 随机编号 ---------- */
  function rollId() {
    fields.id.value = Users.genId();
    setField("id", "ok");
  }
  rollId();
  // 联机模式：等云端账号库拉取完成后重新生成一次编号，避免与其他设备已注册编号冲突
  if (window.YG.Sync) window.YG.Sync.ready.then(() => { if (window.YG.Sync.online) rollId(); });
  document.getElementById("rerollId").addEventListener("click", rollId);

  /* ---------- 随机姓名 ---------- */
  const NAME_SURNAME = ["林","沈","陈","江","顾","陆","叶","温","秦","霍","苏","白","裴","萧","纪","韩","司","傅","许","盛","宋","唐","孟","罗","蓝","闵","邬","岳","季","柯","祁"];
  const NAME_GIVEN = ["辰","澈","风","寒","烬","凛","雾","渊","砚","珩","箫","曜","玄","旻","烨","庭","煜","琛","禹","曜","泽","初","屿","远","逸","洵","朗","歌","乔","黎","燃","野","岚","皓","霖","默","笙","弋","尧","珣","念","凉","晚","星","月","絮","薇","宁","安","檀","柳","霜","琼","洛","离","吟","浅","青","颜","汐","晴","玦","仪","珂","羽","晴","灵","兮","泫"];
  function rollName() {
    const s = NAME_SURNAME[Math.floor(Math.random() * NAME_SURNAME.length)];
    const n = Math.random() < 0.4 ? 2 : 1;
    let g = "";
    for (let i = 0; i < n; i++) g += NAME_GIVEN[Math.floor(Math.random() * NAME_GIVEN.length)];
    fields.name.value = s + g;
    setField("name", "ok");
  }
  document.getElementById("rerollName").addEventListener("click", rollName);

  /* ---------- 实时校验 ---------- */
  fields.name.addEventListener("input", () => {
    setField("name", fields.name.value.trim() ? "ok" : "err", fields.name.value.trim() ? "" : "姓名不能为空");
  });
  fields.pw.addEventListener("input", () => {
    const v = fields.pw.value;
    if (!v) setField("pw", "err", "请设置登录密钥");
    else if (v.length < 6) setField("pw", "err", "密钥长度至少 6 位");
    else setField("pw", "ok");
    if (fields.pw2.value) fields.pw2.dispatchEvent(new Event("input"));
  });
  fields.pw2.addEventListener("input", () => {
    if (!fields.pw2.value) setField("pw2", "err", "请再次输入密钥");
    else if (fields.pw2.value !== fields.pw.value) setField("pw2", "err", "两次输入的密钥不一致");
    else setField("pw2", "ok");
  });

  /* ---------- 提交 ---------- */
  form.addEventListener("submit", e => {
    e.preventDefault();
    const id = fields.id.value.trim().toUpperCase();
    const name = fields.name.value.trim();

    // 逐字段触发一次校验
    Object.keys(fields).forEach(k => fields[k].dispatchEvent(new Event("input")));

    let hasError = !id || !name || fields.pw.value.length < 6 || fields.pw2.value !== fields.pw.value;
    if (Users.find(id)) { errs.id.textContent = "该编号已备案，请直接登录或更换编号"; hasError = true; }
    if (hasError) {
      form.classList.remove("shake");
      void form.offsetWidth;
      form.classList.add("shake");
      return;
    }

    btn.disabled = true;
    const closeLoading = modal(`
      <div class="big-spinner"></div>
      <h3>档案录入中</h3>
      <p>正在写入本机御鬼者备案库…</p>
    `);

    (async () => {
      await (window.YG.Sync ? window.YG.Sync.ready : Promise.resolve());
      const r = await Users.add({
        id, name,
        password: fields.pw.value,
        bureau: bureauSel.value,
        createdAt: new Date().toISOString().slice(0, 10)
      });
      closeLoading();
      if (r && r.ok === false) {
        errs.id.textContent = "该编号刚被其他设备注册，请点「换一组」重新生成";
        btn.disabled = false;
        form.classList.remove("shake");
        void form.offsetWidth;
        form.classList.add("shake");
        return;
      }
      const closeOk = modal(`
        <div class="ok-ico">${icon("check")}</div>
        <h3>备案成功</h3>
        <p>编号 <b class="text-cyan mono">${esc(id)}</b> 已录入全国档案库，2 秒后返回登录</p>
      `);
      setTimeout(() => { closeOk(); location.href = "index.html"; }, 2000);
    })();
  });
})();

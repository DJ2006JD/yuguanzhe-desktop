/* 任务大厅 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { esc, badge, missionCls, statusCls, rankCls, TaskState, Profiles, GameState, toast } = window.YG;

  const me = Profiles.current();
  if (!me) return; // 守卫将触发跳转
  const listEl = document.getElementById("taskList");
  const chipsBox = document.getElementById("levelChips");
  let activeLevel = "全部";

  // 合并内置任务 + 个人扩展任务（自动刷新生成）
  function allMissions() {
    return D.MISSIONS.concat(GameState.extraMissions(me.id));
  }

  // 进入大厅时检查补货（可接任务不足/全部完成时自动生成），静默补货不提醒
  GameState.refreshMissionsIfNeeded(me.id);

  const LEVELS = ["全部", "D", "C", "B", "A", "S", "SS"];
  chipsBox.innerHTML = LEVELS.map(l =>
    `<button class="chip ${l === "全部" ? "active" : ""}" data-level="${l}">${l === "全部" ? l : l + "级"}</button>`
  ).join("");
  chipsBox.addEventListener("click", e => {
    const btn = e.target.closest(".chip");
    if (!btn) return;
    chipsBox.querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
    btn.classList.add("active");
    activeLevel = btn.dataset.level;
    render();
  });

  // 等级门槛：返回 null 表示可接，否则返回所需等级名（嘉奖令可由发布者指定品级门槛覆盖默认映射）
  function lockReason(m) {
    const need = m.reqRankIdx != null ? m.reqRankIdx : (D.MISSION_RANK_REQ[m.level] || 0);
    if (me.rankIdx < need) return D.RANKS[need].name;
    return null;
  }

  function actionArea(m, status) {
    if (status === "待领取") {
      const lock = lockReason(m);
      if (lock) {
        return `<button class="btn btn-sm" disabled style="opacity:.45;cursor:not-allowed"
                  title="需 ${lock} 及以上">需 ${lock}</button>`;
      }
      if (window.YG.Discipline.isSuspended(me.id)) {
        return `<button class="btn btn-sm" disabled style="opacity:.45;cursor:not-allowed"
                  title="侵蚀度 ≥70%，已停职整顿">停职中 · 禁止接取</button>`;
      }
      return `<button class="btn btn-primary btn-sm" data-act="claim" data-id="${m.id}">立即领取</button>`;
    }
    if (status === "进行中" || status === "执行中") {
      return `<button class="btn btn-sm" disabled data-id="${m.id}">
        ${status === "执行中" ? "执行中 · 多人协同" : "已领取 · 进行中"}</button>`;
    }
    if (status === "已完成") {
      return `<button class="btn btn-ghost btn-sm" disabled>已完成归档</button>`;
    }
    return `<button class="btn btn-danger btn-sm" disabled>${esc(status)}</button>`;
  }

  // 任务奖励文本：积分 + 冥币 + 管理附加奖励（装备/鬼怪）
  function rewardText(m) {
    const parts = [`积分 ${m.points}`, `冥币 ${(D.MISSION_COIN_REWARD[m.level] || 20)}±10`];
    if (m.rewards) {
      if (m.rewards.coins) parts[1] = `冥币 ${(D.MISSION_COIN_REWARD[m.level] || 20)}+${m.rewards.coins}`;
      (m.rewards.items || []).forEach(it => {
        const eq = D.EQUIPMENTS.find(e => e.id === it.id);
        if (eq) parts.push(`${eq.name}×${it.n || 1}`);
      });
      if (m.rewards.ghostId) {
        const g = D.GHOSTS.find(x => x.id === m.rewards.ghostId);
        if (g) parts.push(`契约「${g.name}」`);
      }
    }
    return parts.join(" · ");
  }

  function cardHTML(m, i) {
    const status = TaskState.effectiveStatus(me.id, m);
    const cls = missionCls(m.level);
    const hot = m.level === "S" || m.level === "SS";
    const lock = status === "待领取" ? lockReason(m) : null;
    return `
      <div class="glass corner task-card card-hover ${cls} ${hot ? "hot" : ""}"
           data-id="${m.id}" style="animation-delay:${i * 45}ms">
        <div class="task-rank">${m.level}</div>
        <div>
          <h3>${esc(m.name)}
            ${hot ? '<span class="badge m-SS" style="font-size:11px"><span class="dot"></span>高危</span>' : ""}
            ${lock ? `<span class="badge ${rankCls(me.rankIdx)}" style="font-size:11px">需 ${lock}</span>` : ""}
            ${m.rewards ? '<span class="badge st-已完成" style="font-size:11px"><span class="dot"></span>嘉奖令</span>' : ""}
          </h3>
          <div class="task-meta">
            <span class="mono">${m.id}</span>
            <span>地点 <b>${esc(m.place)}</b></span>
            <span>状态 ${badge(statusCls(status), status)}</span>
          </div>
          <div class="task-desc">${esc(m.desc)}</div>
          <div style="margin-top:8px;font-size:12px;color:var(--gold);letter-spacing:.5px">奖励：${esc(rewardText(m))}</div>
        </div>
        <div class="task-side">
          <div class="task-points">${m.points}<small> 积分</small></div>
          ${actionArea(m, status)}
        </div>
      </div>`;
  }

  function render() {
    // 任务大厅只展示「待领取」任务：一旦接取（进行中）或完成，立即从大厅消失
    const list = allMissions()
      .filter(m => TaskState.effectiveStatus(me.id, m) === "待领取")
      .filter(m => activeLevel === "全部" || m.level === activeLevel);
    listEl.innerHTML = list.length
      ? list.map(cardHTML).join("")
      : `<div class="glass empty" style="border-radius:14px;padding:60px 20px">
          当前等级可接的任务已全部接取<br><br>
          <span style="font-size:13px;color:var(--muted)">完成「我的任务记录」中的任务后，指挥部会自动下达新事件</span><br><br>
          <a href="my-tasks.html" class="btn btn-primary btn-sm">前往我的任务</a>
        </div>`;
  }

  listEl.addEventListener("click", e => {
    const claimBtn = e.target.closest('[data-act="claim"]');
    const card = e.target.closest(".task-card");
    if (!card) return;
    const m = allMissions().find(x => x.id === card.dataset.id);

    if (claimBtn) {
      e.stopPropagation();
      const lock = lockReason(m);
      if (lock) {
        toast({ level: "amber", icon: "alarm", title: "权限不足", text: `接取 ${m.level} 级任务需达到「${lock}」` });
        return;
      }
      if (window.YG.Discipline.isSuspended(me.id)) {
        const eroVal = window.YG.Erosion.displayFor(window.YG.Profiles.find(me.id));
        toast({ level: "red", icon: "alarm", title: "停职整顿中", text: `侵蚀度已达 ${eroVal}%（≥70%），禁止接取任务。请使用净化剂降低侵蚀度` });
        return;
      }
      TaskState.claim(me.id, m.id);
      // 静默接取：无弹窗、无消息提醒，任务直接从大厅消失（已在 render 中过滤）
      render();
      return;
    }

    // 点击任务卡片其他区域：不弹窗、不提醒

  });

  render();
})();

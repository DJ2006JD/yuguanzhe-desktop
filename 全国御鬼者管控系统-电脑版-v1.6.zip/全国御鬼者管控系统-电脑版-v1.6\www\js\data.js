/* ============================================================
   全国御鬼者管控系统 · 核心静态数据全集
   ============================================================ */
window.YG_DATA = (function () {

  /* ---------- 鬼怪等级（7级，等级越高威胁越大） ---------- */
  const GHOST_LEVELS = [
    { name: "游魂", cls: "lv-you", order: 1, color: "#46c8ff" },
    { name: "怨鬼", cls: "lv-yuan", order: 2, color: "#4ade80" },
    { name: "厉鬼", cls: "lv-li", order: 3, color: "#ffd23e" },
    { name: "鬼煞", cls: "lv-sha", order: 4, color: "#ff9442" },
    { name: "鬼将", cls: "lv-jiang", order: 5, color: "#ff5a6e" },
    { name: "鬼帅", cls: "lv-shuai", order: 6, color: "#c78bff" },
    { name: "鬼王", cls: "lv-wang", order: 7, color: "#ff1d4e" }
  ];

  /* ---------- 鬼怪图鉴 ---------- */
  const IMG = p => "https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=" + encodeURIComponent(p) + "&image_size=portrait_4_3";
  const GHOSTS = [
    {
      id: "G001", name: "巷尾游魂", level: "游魂", rune: "魂",
      img: IMG("faint translucent wandering ghost in a dark old Chinese alley at night, pale blue glow, drifting mist, horror atmosphere, dark fantasy digital art"),
      ability: "轻微阴冷感、制造小范围低温",
      weakness: "阳气充足场所、镇魂符",
      area: "老旧楼道、废弃小巷", status: "游荡",
      event: "2026-03-12 城南旧巷多名居民反映夜间骤冷，巡逻组现场侦测到游魂级阴能反应。",
      advice: "以镇魂符贴覆游魂活动核心，引导至阳气充足处即可驱散；见习御鬼者可单独处置，事后用探阴镜复核阴能残留。"
    },
    {
      id: "G002", name: "灯下影", level: "游魂", rune: "影",
      img: IMG("creepy living shadow figure under a flickering street lamp at night, pitch black silhouette with faint eyes, dark urban horror, cinematic lighting"),
      ability: "依附阴影移动、短暂遮挡光线",
      weakness: "强光直射",
      area: "路灯死角、地下通道", status: "游荡",
      event: "2026-04-02 滨江西路地下通道连续三晚路灯闪烁，监控捕捉到异常阴影位移。",
      advice: "携带强光照明设备直射逼退，再以封鬼袋收容；处置时避免背对阴影死角，防止其绕身附着。"
    },
    {
      id: "G003", name: "哭墙怨女", level: "怨鬼", rune: "怨",
      img: IMG("pale female ghost in white dress weeping against an old cracked wall, long black hair covering face, eerie green light, Chinese horror, dark fantasy art"),
      ability: "制造幻觉、精神干扰、诱发负面情绪",
      weakness: "桃木、安神药剂",
      area: "旧宅墙体、医院走廊", status: "通缉",
      event: "2026-02-18 第三人民医院住院部夜班护士集体出现幻听，墙体渗出含盐液体，已列入通缉名录。",
      advice: "行动前全员服用安神药剂，以桃木钉封死墙体出入通道；优先击破其幻觉核心，禁止单独追击入墙。"
    },
    {
      id: "G004", name: "校车怨灵", level: "怨鬼", rune: "校",
      img: IMG("abandoned rusty school bus at night on a deserted road, faint ghostly singing echo, thick fog, glowing windows, supernatural horror atmosphere, no people, cinematic"),
      ability: "重复死亡场景、困住活人",
      weakness: "破阴弩、阳光",
      area: "废弃校车、事故路段", status: "封印中",
      event: "2025-11-05 东郊事故路段废弃校车夜间传出孩童诵读声，两名拾荒者被困车内四小时后获救。",
      advice: "正午阳气最盛时行动，破阴弩打断其幻境循环后拖出车体暴晒；现封印于市级装备库三号阵位，定期巡检。"
    },
    {
      id: "G006", name: "无面护士", level: "厉鬼", rune: "护",
      img: IMG("faceless nurse ghost in pale uniform standing in an abandoned hospital morgue corridor, smooth blank face, cold green light, eerie horror, cinematic"),
      ability: "篡改记忆、制造医疗幻觉",
      weakness: "镇魂玉盒、精神净化",
      area: "废弃医院太平间", status: "封印中",
      event: "2026-01-23 西郊职工医院旧址探险者集体失去两小时记忆，太平间冷藏柜无故全开。",
      advice: "进入前互相确认记忆锚点，以镇魂玉盒压制鬼力后由七品以上御鬼者执行收容；事后全员接受精神净化。"
    },
    {
      id: "G007", name: "腐臭鬼煞", level: "鬼煞", rune: "煞",
      img: IMG("toxic ghost demon emitting poisonous green mist over a landfill wasteland, bloated corrupted body, glowing toxic fumes, dark fantasy horror"),
      ability: "大范围阴毒雾气、污染环境",
      weakness: "阴能引燃药剂、隔离面罩",
      area: "垃圾填埋场、下水道", status: "A级预警",
      event: "2026-05-21 南郊填埋场阴毒雾气扩散至邻近两村，已有十一人出现呼吸道侵蚀症状。",
      advice: "启动橙灾响应，外围三公里布设隔离带；投置阴能引燃药剂引爆雾团后近身封印，接触人员须全程隔离面罩。"
    },
    {
      id: "G009", name: "红衣鬼将", level: "鬼将", rune: "将",
      img: IMG("ghost general in crimson ancient Chinese armor commanding a ghost army, ancient battlefield ruins at night, terrifying crimson aura, epic dark fantasy"),
      ability: "自带小型鬼域、统领低级鬼群",
      weakness: "镇狱刀、高阶封印阵",
      area: "古战场遗址、凶宅楼王", status: "S级通缉",
      event: "2026-04-30 北邙山遗址夜游团闯入其鬼域，十五人失联，周边游魂怨鬼出现统一调度迹象。",
      advice: "S级响应，三品以上御鬼者持镇狱刀主攻，封裂营同步展开高阶封印阵；先清剿外围鬼群再切入鬼域核心。"
    },
    {
      id: "G010", name: "水患鬼将", level: "鬼将", rune: "水",
      img: IMG("drowned ghost general in ancient armor rising from a dark reservoir, water vortex swirling around, misty lake at night, horror fantasy art"),
      ability: "操控水体、制造溺水幻境",
      weakness: "封裂营专属水阵",
      area: "水库、沉船、地下暗河", status: "镇压中",
      event: "2026-05-15 青岭水库水位异常上涨，巡查员在岸边陷入溺水幻境，水阵灵脉出现松动。",
      advice: "由封裂营维护专属水阵七处阵眼，三品以上战力轮值镇守；严禁下水追击，以岸基符文炮压制其苏醒进度。"
    },
    {
      id: "G011", name: "白骨鬼帅", level: "鬼帅", rune: "帅",
      img: IMG("colossal skeleton ghost marshal in bone armor summoning an army of bone soldiers, ancient burial battlefield, purple ghost flames, epic dark fantasy horror"),
      ability: "撕开小型阴隙、召唤骨鬼军团",
      weakness: "天御级战力、国家级封印",
      area: "乱葬岗、古战场核心区", status: "沉睡",
      event: "2026-05-30 北邙山核心区地面骨化扩散三百米，小型阴隙短暂开启十七秒，省级警戒已启动。",
      advice: "启动红灾预备预案，国家级封印组进驻监测；一旦苏醒须天御级战力正面牵制，同步以国家级封印重新镇压。"
    },
    {
      id: "G012", name: "烛龙鬼帅", level: "鬼帅", rune: "焰",
      img: IMG("candle dragon ghost marshal, serpentine dragon body wreathed in dark green ghost fire, volcanic ruins, burning embers, epic dark fantasy"),
      ability: "火焰阴能、大范围焚烧",
      weakness: "封界大阵、省级响应",
      area: "火山遗迹、废弃油库", status: "沉睡",
      event: "2025-09-14 西北火山遗迹监测到周期性阴能焰潮，最近一次喷发烧毁半座废弃油库。",
      advice: "以封界大阵覆盖遗迹核心区隔绝阴焰，省级消防与封裂营联合值守；唤醒迹象出现时立即疏散周边十公里。"
    },
    {
      id: "G013", name: "幽都鬼王", level: "鬼王", rune: "王",
      img: IMG("netherworld ghost king on a dark throne above a city consumed by a ghost domain, massive void rifts opening in the sky, apocalyptic horror, epic scale dark fantasy"),
      ability: "城市级鬼域扩张、阴隙大规模开启",
      weakness: "全国动员、天御联手",
      area: "未明", status: "封印状态",
      event: "2026-06-01 滨江市多处阴隙同步开启，检测到幽都鬼王气息自城市地下泄露，黑灾预案启动。",
      advice: "灭灾级处置对象。全国动员、天御级战力联手，优先封堵阴隙群阻止鬼域扩张，封印坐标列入最高机密。"
    },
    {
      id: "G014", name: "千面鬼王", level: "鬼王", rune: "千",
      img: IMG("thousand-faced ghost king in human disguise, face shifting into many overlapping faces, dark city street, unsettling horror, cinematic dark fantasy"),
      ability: "伪装人形、渗透人类社会",
      weakness: "天御级探察、刑幽署专项追捕",
      area: "不明", status: "在逃",
      event: "2026-03-28 多起御鬼者情报泄露事件指向同一人形目标，刑幽署确认千面鬼王已渗透人类社会。",
      advice: "刑幽署专项任务最高密级。任何接触人员须通过天御级探察核实身份，发现线索立即单线上报，禁止公开追查。"
    },
    {
      id: "G015", name: "烛影书生", level: "游魂", rune: "书",
      img: IMG("ghostly ancient Chinese scholar reading by a dim candle in an abandoned library, translucent figure, floating pages, melancholic atmosphere, dark fantasy art"),
      ability: "翻动书页制造低语、扰乱烛火",
      weakness: "收走其执念书卷",
      area: "废弃书院、老图书馆", status: "游荡",
      event: "2026-06-14 城南旧书院夜间传出诵读声，值守人员发现书卷无风自动翻页。",
      advice: "找到其生前未写完的书卷焚化即可超度；见习可处置，注意不要应答其问句。"
    },
    {
      id: "G016", name: "戏台花旦", level: "怨鬼", rune: "戏",
      img: IMG("ghostly Chinese opera actress in elaborate costume on a ruined theater stage, painted face, water sleeves, eerie blue stage light, dark fantasy horror"),
      ability: "夜半唱段摄人心神、诱使观众滞留",
      weakness: "打断唱腔、破其妆镜",
      area: "废弃戏楼、老剧院", status: "游荡",
      event: "2026-07-02 老城区废戏楼连续五夜传出唱腔，两名夜探者被发现呆坐台下至天明。",
      advice: "入场后立即击碎台侧妆镜破其执念，再以镇魂符封口；全程佩戴耳塞阻断唱段。"
    },
    {
      id: "G017", name: "井中娘子", level: "怨鬼", rune: "井",
      img: IMG("pale woman ghost in red dress rising from an old stone well at night, wet long black hair, water dripping, moonlight, Chinese horror, dark fantasy"),
      ability: "拉拽靠近井口者、制造落水幻听",
      weakness: "封井盖以泰山石镇压",
      area: "荒村古井、老宅后院", status: "通缉",
      event: "2026-05-19 西郊荒村一名驴友坠井失踪，救援绳被不明力量割断，井壁检出高浓度阴能。",
      advice: "禁止单人靠近井口三米内；以泰山石压盖井口后贴封条，七日内超度法事化解怨气。"
    },
    {
      id: "G018", name: "铁链狱卒", level: "厉鬼", rune: "狱",
      img: IMG("ghostly jailer dragging heavy iron chains in a dark ancient dungeon, tattered uniform, glowing eyes, sparks from chains, horror dark fantasy art"),
      ability: "铁链束缚活魂、封闭出口",
      weakness: "斩断链节核心符文",
      area: "古监狱遗址、地下牢房", status: "封印中",
      event: "2026-04-11 北郊古监狱遗址施工队三人被无形铁链拖入地牢，救回后双腿留有黑色链痕。",
      advice: "以镇幽短刃斩断其链节符文后正面压制；B级双人编组，注意脚下阴影缠绕。"
    },
    {
      id: "G019", name: "画皮商贾", level: "厉鬼", rune: "画",
      img: IMG("ghostly merchant peeling off a painted human skin mask, revealing hollow dark face, old market street at night, lanterns, horror dark fantasy"),
      ability: "披人皮混入夜市、吞食阳气",
      weakness: "烈酒泼面使其皮相剥落",
      area: "夜市、旧商业街", status: "通缉",
      event: "2026-06-28 滨江市夜市多名摊主阳气亏损昏迷，监控拍到同一面孔在不同摊位同时出现。",
      advice: "辨认其腕部青色勒痕，烈酒泼面破皮相后以封鬼袋收容；禁止与其讨价还价。"
    },
    {
      id: "G020", name: "山魈鬼煞", level: "鬼煞", rune: "魈",
      img: IMG("massive mountain demon ape with ghostly aura in a misty pine forest, glowing green eyes, twisted claws, dark fantasy horror, epic scale"),
      ability: "山雾迷途、巨力撕裂",
      weakness: "铜锣巨响震散山雾",
      area: "深山老林、废弃矿道", status: "A级预警",
      event: "2026-07-15 青岭后山三名采药人迷路失踪，搜救队发现直径半米的非人足印与抓痕。",
      advice: "A级四人编组携铜锣入山，遇雾即鸣锣；锁定本体后以移动封印阵盘围困待援。"
    },
    {
      id: "G021", name: "钟馗叛将", level: "鬼将", rune: "叛",
      img: IMG("fallen ghost-queller general in dark armor with broken demon banner, red eyes, holding a cursed sword, ruined temple, epic dark fantasy horror"),
      ability: "反转镇魂术法、统御叛逃鬼众",
      weakness: "其生前佩剑穗为执念之物",
      area: "古庙遗址、乱军葬坑", status: "S级通缉",
      event: "2026-06-05 西南乱军葬坑出土战旗后，周边三县镇魂阵集体失效，多名御鬼者术法反噬受伤。",
      advice: "S级响应。找到其佩剑残穗可短暂唤醒神智制造破绽，三品以上持镇狱刀主攻。"
    },
    {
      id: "G022", name: "忘川孟婆", level: "鬼帅", rune: "孟",
      img: IMG("ancient crone ghost by a dark river of souls holding a steaming bowl, bridge of oblivion, floating lanterns, mythical Chinese underworld, epic dark fantasy"),
      ability: "忘川水抹去生人记忆、开启魂渡之门",
      weakness: "拒饮汤水、持镇魂玉护神",
      area: "阴隙渡口、地下暗河尽头", status: "沉睡",
      event: "2026-07-30 青岭暗河深处监测到魂渡之门开启征兆，三名探查员归队后集体失忆。",
      advice: "鬼帅级监测对象。任何人不得饮用渡口汤水，全员佩戴镇魂玉佩；苏醒迹象即报总局。"
    },
    {
      id: "G023", name: "更夫游魂", level: "游魂", rune: "更",
      img: IMG("ghostly night watchman holding a lantern and wooden clapper on an empty old street at midnight, translucent, fog, dark fantasy art"),
      ability: "夜半打更声扰人清梦、引路入歧巷",
      weakness: "不应其更声、绕行而过",
      area: "老街巷弄、古镇", status: "游荡",
      event: "2026-08-03 古镇景区多名游客深夜听到不存在的打更声，循声迷路至废弃巷弄。",
      advice: "游魂无恶意，循旧例巡街而已。以镇魂符贴于巷口引导其归于城隍庙即可。"
    },
    {
      id: "G024", name: "伞下女鬼", level: "怨鬼", rune: "伞",
      img: IMG("woman ghost in white holding a red oil-paper umbrella in the rain at night, face hidden, wet stone street, Chinese horror, dark fantasy"),
      ability: "雨夜借伞同行、缠人索命",
      weakness: "拒接其伞、桃木剑断伞骨",
      area: "雨夜巷口、渡船码头", status: "通缉",
      event: "2026-07-22 梅雨季滨江路三名夜行者与撑伞女子同行后高烧不退，阳气亏损。",
      advice: "雨夜出行勿接陌生人伞。遭遇时以桃木剑斩断伞骨破其凭依，再行收容。"
    },
    {
      id: "G025", name: "灶膛火鬼", level: "怨鬼", rune: "灶",
      img: IMG("fire ghost dwelling inside an old kitchen stove, ember face in the flames, dark rural kitchen, sparks, horror dark fantasy"),
      ability: "引燃灶火焚屋、烫伤靠近者",
      weakness: "糯米浆泼灶、封灶符",
      area: "老式民居厨房、柴房", status: "游荡",
      event: "2026-08-11 城南老宅连续两起灶膛自燃事故，住户称火光中见人脸。",
      advice: "糯米浆泼入灶膛熄其阴火，贴封灶符三日；处置时穿戴抗侵蚀面罩防灼伤。"
    },
    {
      id: "G026", name: "水鬼伥", level: "厉鬼", rune: "伥",
      img: IMG("drowned water ghost lurking under dark river surface near a wooden pier, pale hand reaching out of water, moonlight, horror dark fantasy"),
      ability: "拖人入水为伥、伪装呼救声",
      weakness: "不在夜间近水、雄黄洒岸",
      area: "河道码头、水库浅滩", status: "通缉",
      event: "2026-08-19 青岭水库下游两名夜泳者失踪，岸边监控录到清晰呼救声但水面无人。",
      advice: "夜间禁近水岸。以雄黄洒岸逼其现形，破阴弩远程击伤后封鬼袋收容。"
    },
    {
      id: "G027", name: "棺材铺掌柜", level: "厉鬼", rune: "棺",
      img: IMG("ghostly coffin shop keeper in an old workshop full of coffins, dim oil lamp, measuring an invisible customer, horror dark fantasy"),
      ability: "为活人量身定做棺木、咒其暴毙",
      weakness: "烧毁其量人尺",
      area: "老街棺材铺、殡葬巷", status: "封印中",
      event: "2026-05-30 殡葬巷棺材铺夜间亮灯，三名被'量身'的居民一周内接连重病。",
      advice: "找到并烧毁其量人尺断其咒术，再以封鬼阵收押；禁止让其报出你的生辰。"
    },
    {
      id: "G028", name: "纸人抬棺", level: "鬼煞", rune: "纸",
      img: IMG("four paper effigy bearers carrying a black coffin through foggy night street, painted faces, eerie procession, Chinese horror dark fantasy"),
      ability: "纸人夜行收魂、棺中困活人",
      weakness: "朱砂点其眼、火焚纸身",
      area: "丧葬队伍夜路、荒郊坟道", status: "A级预警",
      event: "2026-08-27 郊县夜间出现无人的送葬队伍，尾随者被发现昏睡于黑棺之内。",
      advice: "A级编组处置。以朱砂点纸人双目定身，火符焚其身；开棺前必先以探阴镜确认。"
    },
    {
      id: "G029", name: "疫鬼婆婆", level: "鬼煞", rune: "疫",
      img: IMG("old crone plague ghost spreading green miasma in a deserted village, holding a basket of withered herbs, horror dark fantasy"),
      ability: "散布疫气、令人疫病缠身",
      weakness: "艾草烟熏、隔离净宅",
      area: "荒废村落、疫区旧址", status: "封锁中",
      event: "2026-09-02 西南荒村整村暴发不明疫病，患者皆梦一挎篮老妪门前徘徊。",
      advice: "封锁全村，艾草混合符水烟熏净宅；处置人员全程隔离面罩，事后隔离观察七日。"
    },
    {
      id: "G030", name: "雷殛鬼将", level: "鬼将", rune: "雷",
      img: IMG("ghost general struck by lightning, charred armor crackling with dark electric arcs, stormy battlefield, epic dark fantasy"),
      ability: "驭阴雷轰击、麻痹生灵",
      weakness: "引雷入地符阵、绝缘法器",
      area: "雷暴高发山地、古战场", status: "S级通缉",
      event: "2026-09-10 北邙山雷暴夜，巡查队遭阴雷袭击三人重伤，仪器记录到非自然雷击。",
      advice: "S级响应。布引雷入地符阵卸其阴雷，三品以上战力近身破甲；雷暴天气严禁接战。"
    },
    {
      id: "G031", name: "镜中鬼帅", level: "鬼帅", rune: "镜",
      img: IMG("ghost marshal emerging from an ancient bronze mirror, half body in mirror world, dark room lit by candle, horror dark fantasy epic"),
      ability: "镜中世界囚魂、以镜瞬移",
      weakness: "碎其本命古镜",
      area: "古宅镜厅、博物馆铜镜库", status: "沉睡",
      event: "2026-09-18 省博物馆汉代铜镜夜间异动，监控中镜内影像与现实不符，两名保安失联。",
      advice: "鬼帅级监测对象。封存铜镜库并以符布遮面；其本命古镜藏于镜世界，非天御级不可入镜。"
    },
    {
      id: "G032", name: "泰山府君", level: "鬼王", rune: "泰",
      img: IMG("mighty ghost king seated on a dark mountain throne, ancient Chinese underworld deity, ghost officials kneeling, epic scale dark fantasy"),
      ability: "执掌一方阴司、调动万鬼",
      weakness: "未明，泰山封禅大阵或可压制",
      area: "泰山阴域", status: "封印状态",
      event: "2026-09-25 泰山区域阴能指数持续异常，封禅大阵出现三道裂纹，总局一级戒备。",
      advice: "灭灾级处置对象。封禅大阵日夜加固监测，任何异动直达总局；严禁任何形式的试探接触。"
    }
  ];

  /* ---------- 装备分类 ---------- */
  const EQUIP_CATEGORIES = [
    { name: "侦测类", icon: "scan" },
    { name: "封印收纳类", icon: "box" },
    { name: "防护抗侵蚀类", icon: "shield" },
    { name: "战斗攻坚类", icon: "blade" },
    { name: "药剂耗材类", icon: "vial" }
  ];

  /* ---------- 装备工具 ---------- */
  const EQUIPMENTS = [
    { id: "EQ001", name: "探阴镜", category: "侦测类", rank: "见习及以上", premium: false,
      func: "观测肉眼不可见鬼物、阴气流、阴隙裂口，初步判断鬼怪等级",
      limit: "无法看穿鬼域；高级鬼煞可伪装气息",
      rule: "基础制式装备，自动备案" },
    { id: "EQ002", name: "侵蚀检测手环", category: "侦测类", rank: "见习及以上", premium: false,
      func: "实时监测身体侵蚀度，数据同步系统，超标自动告警",
      limit: "仅检测本人；鬼域环境下读数漂移",
      rule: "强制配发，一人一编号" },
    { id: "EQ003", name: "阴能探测棒", category: "侦测类", rank: "九品及以上", premium: false,
      func: "扫描区域阴能浓度，定位鬼物藏身位置",
      limit: "只能定位方位，易被大量怨气干扰",
      rule: "普通装备，驿站申领" },
    { id: "EQ004", name: "封鬼袋", category: "封印收纳类", rank: "见习及以上", premium: false,
      func: "收纳游魂、怨鬼，内置镇魂法阵压制鬼力",
      limit: "单袋仅容1只；厉鬼可撕裂袋子",
      rule: "消耗品，按需申领" },
    { id: "EQ005", name: "镇幽玉盒", category: "封印收纳类", rank: "六品及以上", premium: true,
      func: "收容厉鬼、鬼煞，大幅降低侵蚀速度",
      limit: "需定期注入阳气维持法阵",
      rule: "高阶装备，等级审批" },
    { id: "EQ006", name: "移动封印阵盘", category: "封印收纳类", rank: "四品及以上", premium: true,
      func: "展开临时结界困住鬼怪，等待支援",
      limit: "持续消耗灵石能源，无法长时间束缚鬼将",
      rule: "管制装备，任务专用" },
    { id: "EQ007", name: "制式御鬼制服", category: "防护抗侵蚀类", rank: "见习及以上", premium: false,
      func: "内嵌抗阴能纤维，隔绝少量怨气，抵挡低级鬼术",
      limit: "对鬼煞以上侵蚀防护有限",
      rule: "统一配发" },
    { id: "EQ008", name: "镇魂玉佩", category: "防护抗侵蚀类", rank: "九品及以上", premium: false,
      func: "持续散发镇魂气息，缓慢降低侵蚀度，抵御幻觉",
      limit: "碎裂后效果立即消失",
      rule: "个人保管，遗失报备" },
    { id: "EQ009", name: "抗侵蚀面罩", category: "防护抗侵蚀类", rank: "七品及以上", premium: false,
      func: "过滤阴毒雾气、怨气粉尘，防止呼吸道侵蚀",
      limit: "无法抵挡直接精神侵蚀",
      rule: "任务防护装备" },
    { id: "EQ010", name: "镇幽短刃", category: "战斗攻坚类", rank: "八品及以上", premium: false,
      func: "刀身刻破阴法阵，物理攻击附带净化效果，可斩伤鬼体",
      limit: "对无实体幽灵效果减半",
      rule: "制式武器，登记备案" },
    { id: "EQ011", name: "破阴弩", category: "战斗攻坚类", rank: "五品及以上", premium: true,
      func: "远程符文箭，远距离偷袭、打断鬼术释放",
      limit: "符文箭一次性，装填慢",
      rule: "远程管制武器" },
    { id: "EQ012", name: "镇狱刀", category: "战斗攻坚类", rank: "三品及以上", premium: true,
      func: "自带镇魂场，可斩碎鬼域屏障",
      limit: "需自身鬼力驱动，加速侵蚀上涨",
      rule: "镇狱司专属，最高管制" },
    { id: "EQ013", name: "短效净化剂", category: "药剂耗材类", rank: "见习及以上", premium: false,
      func: "立即降低部分侵蚀度，应急使用",
      limit: "频繁使用削弱自身鬼力",
      rule: "限量兑换" },
    { id: "EQ014", name: "安神药剂", category: "药剂耗材类", rank: "见习及以上", premium: false,
      func: "抵抗精神幻术、梦魇，稳定心神",
      limit: "过量会产生嗜睡副作用",
      rule: "常备耗材" },
    { id: "EQ015", name: "契约稳固药剂", category: "药剂耗材类", rank: "六品及以上", premium: true,
      func: "签订契约时使用，提升契约稳定度",
      limit: "对镇压契约效果减半",
      rule: "高阶耗材，审批使用" },
    { id: "EQ016", name: "阴灵口粮", category: "药剂耗材类", rank: "见习及以上", premium: false,
      func: "喂养契约鬼灵的特制供品，恢复鬼灵饱食度 40 点",
      limit: "仅对契约鬼灵有效；请在鬼灵仓库中使用",
      rule: "常备耗材，商城有售" }
  ];

  /* ---------- 任务大厅 ---------- */
  const MISSIONS = [
    { id: "M001", name: "老城区游魂清扫", level: "D", place: "城南旧巷", points: 10, status: "待领取",
      desc: "日常巡逻清扫3处游魂聚集点" },
    { id: "M002", name: "小区楼道异响排查", level: "D", place: "阳光小区", points: 15, status: "待领取",
      desc: "排查居民反馈的楼道阴冷异响现象" },
    { id: "M003", name: "中学厕所怨鬼处理", level: "C", place: "第三中学", points: 50, status: "待领取",
      desc: "收服厕所怨鬼，消除学生幻觉影响" },
    { id: "M004", name: "废弃仓库怨气清除", level: "C", place: "东郊仓库", points: 60, status: "待领取",
      desc: "清除仓库积压怨气，处理残留低阶鬼物" },
    { id: "M005", name: "废弃医院厉鬼镇压", level: "B", place: "西郊职工医院", points: 200, status: "待领取",
      desc: "镇压无面护士，回收现场残留阴能" },
    { id: "M006", name: "监狱遗址铁链清理", level: "B", place: "北郊古监狱遗址", points: 240, status: "待领取",
      desc: "封印铁链狱卒，解救被困施工人员" },
    { id: "M007", name: "垃圾场鬼煞封锁", level: "A", place: "南郊填埋场", points: 800, status: "待领取",
      desc: "封锁腐臭鬼煞扩散范围，清理阴毒雾气" },
    { id: "M008", name: "油库阴焰巡查", level: "A", place: "西北废弃油库", points: 900, status: "待领取",
      desc: "监测烛龙鬼帅阴能焰潮，加固封界大阵" },
    { id: "M009", name: "水库鬼将苏醒预警", level: "S", place: "青岭水库", points: 3000, status: "待领取",
      desc: "监测水患鬼将动向，布置镇压阵法" },
    { id: "M010", name: "古战场鬼帅异动", level: "S", place: "北邙山遗址", points: 3500, status: "待领取",
      desc: "白骨鬼帅异动，启动省级警戒" },
    { id: "M011", name: "城市阴隙大规模开启", level: "SS", place: "滨江市", points: 10000, status: "待领取",
      desc: "幽都鬼王气息泄露，全城启动黑灾预案" },
    { id: "M012", name: "千面鬼王渗透追查", level: "SS", place: "全国范围", points: 12000, status: "待领取",
      desc: "刑幽署牵头，追查千面鬼王人形身份" },
    { id: "M013", name: "老旧小区夜半哭声", level: "D", place: "永安里小区", points: 12, status: "待领取",
      desc: "排查老旧小区夜半女子哭声源头，初步判断为游魂徘徊" },
    { id: "M014", name: "学校晚自习灯光异常", level: "D", place: "第一中学", points: 14, status: "待领取",
      desc: "晚自习教室灯光频闪，伴随低阶阴气残留" },
    { id: "M015", name: "写字楼电梯厉鬼排查", level: "C", place: "金融城写字楼", points: 55, status: "待领取",
      desc: "电梯频繁停靠空楼层，疑似厉鬼滞留" },
    { id: "M016", name: "地铁末班车怨魂", level: "C", place: "青河地铁一号线", points: 58, status: "待领取",
      desc: "末班车乘客集体听见耳畔低语，封印三节车厢阴气" },
    { id: "M017", name: "烂尾楼工地厉鬼", level: "B", place: "滨江南岸烂尾工地", points: 210, status: "待领取",
      desc: "工人连续失踪，镇压在塔吊徘徊的血衣厉鬼" },
    { id: "M018", name: "商场试衣间怨气清除", level: "B", place: "中央商场", points: 230, status: "待领取",
      desc: "试衣间镜面映出无面人影，封锁区域净化怨气" },
    { id: "M019", name: "公路连环车祸阴源", level: "B", place: "沪青高速157km段", points: 250, status: "待领取",
      desc: "同一路段30天内发生7起车祸，追踪幕后厉鬼" },
    { id: "M020", name: "殡仪馆鬼煞聚变", level: "A", place: "市第二殡仪馆", points: 820, status: "待领取",
      desc: "焚烧间怨气聚变出鬼煞雏形，需立即压制" },
    { id: "M021", name: "古城墙下封印松动", level: "A", place: "旧城根遗址", points: 880, status: "待领取",
      desc: "明代城墙下古老封印松动，阴气渗出影响周边居民" },
    { id: "M022", name: "剧院午夜回声", level: "A", place: "老剧院", points: 920, status: "待领取",
      desc: "深夜传出戏腔，鬼戏班子重现舞台，需全团封印" },
    { id: "M023", name: "海底隧道阴潮", level: "S", place: "滨江东海底隧道", points: 3100, status: "待领取",
      desc: "海底隧道内阴潮涌动，疑似水鬼将集结，封裂营支援" },
    { id: "M024", name: "古镇阴兵借道", level: "S", place: "临水古镇", points: 3300, status: "待领取",
      desc: "午夜古镇街道现阴兵队列，需三品以上御鬼者镇守" },
    { id: "M025", name: "边境鬼域扩张", level: "S", place: "西南边境线", points: 3600, status: "待领取",
      desc: "边境无人区鬼域向外扩张3公里，封裂营联合封裂" },
    { id: "M026", name: "孤岛灯塔鬼王苏醒", level: "SS", place: "外海孤岛灯塔", points: 11000, status: "待领取",
      desc: "百年灯塔内鬼王苏醒，引发海域黑灾，天御专属任务" },
    { id: "M027", name: "雪山冰层鬼影", level: "SS", place: "昆仑雪山", points: 13000, status: "待领取",
      desc: "科考队在冰层下发现封印的远古鬼王，需最高战力处置" }
  ];

  /* ---------- 御鬼者等级体系（points = 晋升所需累计积分） ---------- */
  const RANKS = [
    { name: "见习御鬼者", idx: 0, points: 0,    ghostLimit: "1只", scope: "D级任务、基础装备申领", cond: "天赋觉醒、完成入门培训" },
    { name: "九品御鬼者", idx: 1, points: 100,  ghostLimit: "2只", scope: "C级任务、基础武器", cond: "封印3只怨鬼、侵蚀度稳定" },
    { name: "八品御鬼者", idx: 2, points: 300,  ghostLimit: "2只", scope: "B级以下任务、镇幽短刃", cond: "独立完成2次B级任务" },
    { name: "七品御鬼者", idx: 3, points: 600,  ghostLimit: "2只", scope: "B级任务、防护装备申领", cond: "累计封印10只厉鬼以下" },
    { name: "六品御鬼者", idx: 4, points: 1000, ghostLimit: "3只", scope: "A级以下任务、镇幽玉盒", cond: "参与1次A级任务、积分达标" },
    { name: "五品御鬼者", idx: 5, points: 1500, ghostLimit: "3只", scope: "A级任务、破阴弩申领", cond: "独立完成3次B级任务" },
    { name: "四品御鬼者", idx: 6, points: 2200, ghostLimit: "3只", scope: "A级主力、封印阵盘使用", cond: "参与封印1只鬼煞" },
    { name: "三品御鬼者", idx: 7, points: 3000, ghostLimit: "4只", scope: "S级任务、镇狱刀权限", cond: "独立镇压1只鬼煞" },
    { name: "二品御鬼者", idx: 8, points: 4000, ghostLimit: "4只", scope: "S级主力、省级任务指挥", cond: "参与镇压1只鬼将" },
    { name: "一品御鬼者", idx: 9, points: 5200, ghostLimit: "4只", scope: "SS级列席、区域镇守", cond: "独立镇压1只鬼将" },
    { name: "天御",       idx: 10, points: 30000, ghostLimit: "5只", scope: "全国任务、国家级战力、S级以上任务接取权", cond: "契约鬼王、战功卓绝、全国遴选" }
  ];

  /* ---------- 灵异灾难等级 ---------- */
  const DISASTERS = [
    { level: "蓝灾", color: "#4da6ff", power: "游魂、零散怨鬼", range: "单个地点", plan: "县级驿站处置", swatch: "#4da6ff" },
    { level: "黄灾", color: "#ffd23e", power: "多只怨鬼、单只厉鬼", range: "片区/单栋建筑", plan: "市级治安队出动", swatch: "#ffd23e" },
    { level: "橙灾", color: "#ff9442", power: "厉鬼成群、单只鬼煞", range: "街道/多栋建筑", plan: "市级全员响应、省级支援", swatch: "#ff9442" },
    { level: "红灾", color: "#ff4d5e", power: "鬼煞现世、小型鬼域", range: "区县范围", plan: "省级分局主导、周边支援", swatch: "#ff4d5e" },
    { level: "黑灾", color: "#b06bff", power: "鬼将级、阴隙扩张", range: "城市级", plan: "全省动员、总局督导", swatch: "#b06bff" },
    { level: "灭灾", color: "#ff1d4e", power: "鬼王苏醒、大规模阴隙", range: "省级/全国", plan: "国家级最高警戒、天御出动", swatch: "#ff1d4e", doom: true }
  ];

  /* ---------- 组织机构 ---------- */
  const ORGS = [
    { id: "HQ", name: "全国灵异管控总局", type: "国家级", func: "制定规则、全国评级、最高灾难处置、天御管理", units: "镇狱司、封裂营、刑幽署", top: true },
    { id: "PROV", name: "省级灵异管控分局", type: "省级", func: "省内裂口管理、御鬼者考核、A级以上任务指挥", units: "各市治安队、省级装备库" },
    { id: "CITY", name: "市级灵异治安队", type: "市级", func: "日常巡逻、低级鬼怪清除、市民求助、事件上报", units: "各区县驿站" },
    { id: "STATION", name: "县区御鬼者驿站", type: "基层", func: "新手驻扎、任务领取、物资补给、侵蚀度检测", units: "巡逻组、后勤组" },
    { id: "ZYS", name: "镇狱司", type: "总局直属", func: "镇压A级以上恶鬼、高阶封印执行", units: "各省级镇狱分队", direct: true },
    { id: "FLY", name: "封裂营", type: "总局直属", func: "空间裂口封锁、鬼域隔离、大型阵法布置", units: "工程队、阵法组", direct: true },
    { id: "XYS", name: "刑幽署", type: "总局直属", func: "抓捕叛逃御鬼者、鬼化人员、违规黑市交易", units: "追缉组、内审组", direct: true }
  ];

  /* ---------- 注册可选机构（与组织架构同步；总局直属/国家级不开放注册，仅后台任命） ---------- */
  const BUREAUS = [
    "镇狱司 · 总局直属",
    "封裂营 · 总局直属",
    "刑幽署 · 总局直属",
    "华东省级灵异管控分局",
    "华北省级灵异管控分局",
    "华南省级灵异管控分局",
    "西南省级灵异管控分局",
    "滨江市灵异治安队",
    "城南区县级御鬼者驿站"
  ];
  // 后台添加账号可选的具体单位（9 个下辖单位）
  const REGISTER_BUREAUS = BUREAUS;
  // 注册页机构选项：与组织架构 7 个机构一一对应（顺序同组织架构图）
  const REGISTER_ORGS = ["HQ", "PROV", "ZYS", "FLY", "XYS", "CITY", "STATION"]
    .map(id => ORGS.find(o => o.id === id));

  /* ---------- 种子御鬼者档案（全国备案数据） ---------- */
  const SEED_PROFILES = [
    { id: "YG-0001", name: "很困", rankIdx: 10, bureau: "全国灵异管控总局", erosion: 47, status: "正常",
      joinDate: "2019-06-01", ghostIds: ["G013", "G011", "G009"],
      missionsDone: 63, rating: "S", seed: true, points: 32600, superiorId: null,
      promotions: [
        { date: "2019-09", title: "晋升九品御鬼者", note: "入门培训全优结业" },
        { date: "2021-01", title: "晋升五品御鬼者", note: "独立封印无面护士 G006" },
        { date: "2023-11", title: "晋升三品御鬼者", note: "独立镇压腐臭鬼煞 G007，获镇狱刀权限" }
      ] },
    { id: "YG-0002", name: "曹玉魂", rankIdx: 9, bureau: "华东省级灵异管控分局", erosion: 22, status: "正常",
      joinDate: "2019-02-07", ghostIds: ["G011","G009","G007","G003"],
      missionsDone: 194, rating: "S", seed: true, leader: true, orgId: "PROV", leaderTitle: "省级分局 · 最高领导", points: 5300, superiorId: "YG-0001",
      promotions: [
        { date: "2020-03", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-12", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2022-05", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2024-10", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2024-07", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2027-02", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" },
        { date: "2029-01", title: "晋升三品御鬼者", note: "独立镇压鬼煞1只" },
        { date: "2027-10", title: "晋升二品御鬼者", note: "参与镇压1只鬼将" },
        { date: "2026-08", title: "晋升一品御鬼者", note: "独立镇压1只鬼将" }
      ] },
    { id: "YG-0003", name: "朱寒明", rankIdx: 8, bureau: "镇狱司 · 总局直属", erosion: 26, status: "正常",
      joinDate: "2019-05-18", ghostIds: ["G012","G010","G020","G007"],
      missionsDone: 178, rating: "S", seed: true, leader: true, orgId: "ZYS", leaderTitle: "镇狱司 · 最高领导", points: 4100, superiorId: "YG-0001",
      promotions: [
        { date: "2020-03", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-09", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2022-11", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2025-01", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2024-05", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2026-05", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" },
        { date: "2025-03", title: "晋升三品御鬼者", note: "独立镇压鬼煞1只" },
        { date: "2026-01", title: "晋升二品御鬼者", note: "参与镇压1只鬼将" }
      ] },
    { id: "YG-0004", name: "窦无斩", rankIdx: 8, bureau: "封裂营 · 总局直属", erosion: 31, status: "正常",
      joinDate: "2019-09-02", ghostIds: ["G028","G029","G009","G021"],
      missionsDone: 166, rating: "S", seed: true, leader: true, orgId: "FLY", leaderTitle: "封裂营 · 最高领导", points: 4050, superiorId: "YG-0001",
      promotions: [
        { date: "2020-09", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2022-01", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2022-09", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2025-05", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2025-02", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2027-03", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" },
        { date: "2025-07", title: "晋升三品御鬼者", note: "独立镇压鬼煞1只" },
        { date: "2030-05", title: "晋升二品御鬼者", note: "参与镇压1只鬼将" }
      ] },
    { id: "YG-0005", name: "贺敏平", rankIdx: 7, bureau: "刑幽署 · 总局直属", erosion: 19, status: "正常",
      joinDate: "2020-03-11", ghostIds: ["G021","G018","G019","G006"],
      missionsDone: 173, rating: "S", seed: true, leader: true, orgId: "XYS", leaderTitle: "刑幽署 · 最高领导", points: 3150, superiorId: "YG-0001",
      promotions: [
        { date: "2021-05", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2022-03", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2024-06", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2025-11", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2026-11", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2028-03", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" },
        { date: "2026-01", title: "晋升三品御鬼者", note: "独立镇压鬼煞1只" }
      ] },
    { id: "YG-0006", name: "曹涵照", rankIdx: 7, bureau: "滨江市灵异治安队", erosion: 28, status: "正常",
      joinDate: "2020-07-25", ghostIds: ["G020","G010","G016"],
      missionsDone: 169, rating: "S", seed: true, leader: true, orgId: "CITY", leaderTitle: "市级治安队 · 最高领导", points: 3080, superiorId: "YG-0001",
      promotions: [
        { date: "2021-09", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2022-05", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2024-07", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2025-11", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2025-12", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2028-07", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" },
        { date: "2029-11", title: "晋升三品御鬼者", note: "独立镇压鬼煞1只" }
      ] },
    { id: "YG-0007", name: "韦明勇", rankIdx: 7, bureau: "城南区县级御鬼者驿站", erosion: 35, status: "正常",
      joinDate: "2020-11-30", ghostIds: ["G029","G017","G026"],
      missionsDone: 156, rating: "S", seed: true, leader: true, orgId: "STATION", leaderTitle: "县区驿站 · 最高领导", points: 3210, superiorId: "YG-0001",
      promotions: [
        { date: "2022-04", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2022-07", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2023-11", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2025-07", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2027-12", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2026-11", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" },
        { date: "2029-08", title: "晋升三品御鬼者", note: "独立镇压鬼煞1只" }
      ] },
    { id: "YG-0008", name: "赵止归", rankIdx: 5, bureau: "华东省级灵异管控分局", erosion: 55, status: "正常",
      joinDate: "2019-05-22", ghostIds: ["G004","G029"],
      missionsDone: 52, rating: "B", seed: true, points: 1966, superiorId: "YG-0002",
      promotions: [
        { date: "2020-01", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-05", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2022-11", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2023-01", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2025-08", title: "晋升五品御鬼者", note: "独立完成3次B级任务" }
      ] },
    { id: "YG-0009", name: "卜乾", rankIdx: 4, bureau: "华东省级灵异管控分局", erosion: 14, status: "正常",
      joinDate: "2016-10-17", ghostIds: ["G016","G002"],
      missionsDone: 52, rating: "A", seed: true, points: 1261, superiorId: "YG-0002",
      promotions: [
        { date: "2017-12", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2017-12", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2019-04", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2019-06", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0010", name: "路魄", rankIdx: 4, bureau: "华东省级灵异管控分局", erosion: 25, status: "正常",
      joinDate: "2017-09-20", ghostIds: ["G019","G015","G028"],
      missionsDone: 53, rating: "A", seed: true, points: 1144, superiorId: "YG-0002",
      promotions: [
        { date: "2018-12", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2019-01", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2019-09", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2021-01", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0011", name: "巴魂彻", rankIdx: 4, bureau: "华东省级灵异管控分局", erosion: 47, status: "正常",
      joinDate: "2024-02-10", ghostIds: ["G027","G001","G023"],
      missionsDone: 50, rating: "A", seed: true, points: 1346, superiorId: "YG-0002",
      promotions: [
        { date: "2025-04", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2025-12", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2026-08", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2029-02", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0012", name: "郎邪远", rankIdx: 2, bureau: "华东省级灵异管控分局", erosion: 4, status: "正常",
      joinDate: "2016-10-15", ghostIds: ["G016","G027","G017"],
      missionsDone: 24, rating: "B", seed: true, points: 382, superiorId: "YG-0002",
      promotions: [
        { date: "2017-09", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2018-10", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0013", name: "崔琛英", rankIdx: 5, bureau: "华东省级灵异管控分局", erosion: 55, status: "正常",
      joinDate: "2022-08-30", ghostIds: ["G030","G003","G026"],
      missionsDone: 55, rating: "A", seed: true, points: 1666, superiorId: "YG-0002",
      promotions: [
        { date: "2023-08", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2025-02", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2025-02", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2026-12", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2027-03", title: "晋升五品御鬼者", note: "独立完成3次B级任务" }
      ] },
    { id: "YG-0014", name: "俞七", rankIdx: 6, bureau: "华东省级灵异管控分局", erosion: 28, status: "正常",
      joinDate: "2020-06-24", ghostIds: ["G020","G023","G007"],
      missionsDone: 71, rating: "S", seed: true, points: 2901, superiorId: "YG-0002",
      promotions: [
        { date: "2021-01", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-08", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2022-09", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2022-10", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2025-01", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2023-12", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" }
      ] },
    { id: "YG-0015", name: "陈玄艳", rankIdx: 4, bureau: "华东省级灵异管控分局", erosion: 32, status: "正常",
      joinDate: "2022-08-17", ghostIds: ["G020"],
      missionsDone: 48, rating: "C", seed: true, points: 1429, superiorId: "YG-0002",
      promotions: [
        { date: "2023-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2023-10", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2025-08", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2024-12", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0016", name: "蓟寒", rankIdx: 2, bureau: "华东省级灵异管控分局", erosion: 55, status: "正常",
      joinDate: "2023-11-02", ghostIds: ["G016","G001","G026"],
      missionsDone: 25, rating: "B", seed: true, points: 384, superiorId: "YG-0002",
      promotions: [
        { date: "2024-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2026-01", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0017", name: "项罡", rankIdx: 3, bureau: "华东省级灵异管控分局", erosion: 37, status: "正常",
      joinDate: "2020-06-16", ghostIds: ["G023","G028"],
      missionsDone: 36, rating: "B", seed: true, points: 713, superiorId: "YG-0002",
      promotions: [
        { date: "2021-06", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-10", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2023-12", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0018", name: "曹魄", rankIdx: 2, bureau: "华东省级灵异管控分局", erosion: 22, status: "正常",
      joinDate: "2022-12-21", ghostIds: ["G015"],
      missionsDone: 30, rating: "B", seed: true, points: 348, superiorId: "YG-0002",
      promotions: [
        { date: "2023-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2024-10", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0019", name: "莫破", rankIdx: 4, bureau: "华东省级灵异管控分局", erosion: 28, status: "正常",
      joinDate: "2021-11-12", ghostIds: ["G020","G007"],
      missionsDone: 43, rating: "B", seed: true, points: 1311, superiorId: "YG-0002",
      promotions: [
        { date: "2022-10", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2024-03", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2025-02", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2025-11", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0020", name: "左照魂", rankIdx: 1, bureau: "华东省级灵异管控分局", erosion: 40, status: "正常",
      joinDate: "2016-02-08", ghostIds: ["G026"],
      missionsDone: 23, rating: "B", seed: true, points: 235, superiorId: "YG-0002",
      promotions: [
        { date: "2017-03", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0021", name: "徐瑾琪", rankIdx: 5, bureau: "华北省级灵异管控分局", erosion: 34, status: "正常",
      joinDate: "2018-03-09", ghostIds: ["G024","G016"],
      missionsDone: 65, rating: "A", seed: true, points: 1591, superiorId: "YG-0002",
      promotions: [
        { date: "2019-03", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2020-07", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2021-03", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2022-07", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2024-06", title: "晋升五品御鬼者", note: "独立完成3次B级任务" }
      ] },
    { id: "YG-0022", name: "富竹舟", rankIdx: 0, bureau: "华北省级灵异管控分局", erosion: 27, status: "正常",
      joinDate: "2017-10-28", ghostIds: [],
      missionsDone: 3, rating: "C", seed: true, points: 56, superiorId: "YG-0002",
      promotions: [
        { date: "2018-01", title: "天赋觉醒登记", note: "档案备案完成，入门培训进行中" }
      ] },
    { id: "YG-0023", name: "薄阴", rankIdx: 2, bureau: "华北省级灵异管控分局", erosion: 56, status: "正常",
      joinDate: "2019-08-07", ghostIds: ["G018","G017","G006"],
      missionsDone: 32, rating: "B", seed: true, points: 396, superiorId: "YG-0002",
      promotions: [
        { date: "2020-08", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-10", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0024", name: "宋朴", rankIdx: 2, bureau: "华北省级灵异管控分局", erosion: 67, status: "正常",
      joinDate: "2023-10-12", ghostIds: ["G024"],
      missionsDone: 34, rating: "C", seed: true, points: 566, superiorId: "YG-0002",
      promotions: [
        { date: "2024-09", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2025-08", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0025", name: "仲雪彻", rankIdx: 5, bureau: "华北省级灵异管控分局", erosion: 47, status: "正常",
      joinDate: "2022-10-27", ghostIds: ["G020","G028"],
      missionsDone: 53, rating: "S", seed: true, points: 1658, superiorId: "YG-0002",
      promotions: [
        { date: "2023-08", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2024-08", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2026-07", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2027-02", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2028-08", title: "晋升五品御鬼者", note: "独立完成3次B级任务" }
      ] },
    { id: "YG-0026", name: "褚扶", rankIdx: 4, bureau: "华北省级灵异管控分局", erosion: 68, status: "正常",
      joinDate: "2017-10-02", ghostIds: ["G004"],
      missionsDone: 45, rating: "A", seed: true, points: 1093, superiorId: "YG-0002",
      promotions: [
        { date: "2018-11", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2019-10", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2019-10", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2021-10", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0027", name: "支瑜松", rankIdx: 3, bureau: "华北省级灵异管控分局", erosion: 63, status: "正常",
      joinDate: "2016-01-11", ghostIds: ["G026","G007","G027"],
      missionsDone: 46, rating: "A", seed: true, points: 711, superiorId: "YG-0002",
      promotions: [
        { date: "2016-11", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2017-11", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2018-07", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0028", name: "花魂", rankIdx: 2, bureau: "华北省级灵异管控分局", erosion: 54, status: "正常",
      joinDate: "2016-10-24", ghostIds: ["G016"],
      missionsDone: 31, rating: "C", seed: true, points: 490, superiorId: "YG-0002",
      promotions: [
        { date: "2017-08", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2018-04", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0029", name: "闵丽", rankIdx: 6, bureau: "华北省级灵异管控分局", erosion: 32, status: "正常",
      joinDate: "2025-02-23", ghostIds: ["G018","G001"],
      missionsDone: 73, rating: "A", seed: true, points: 2511, superiorId: "YG-0002",
      promotions: [
        { date: "2025-09", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2026-06", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2027-08", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2028-02", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2028-11", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2032-08", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" }
      ] },
    { id: "YG-0030", name: "孙天舟", rankIdx: 3, bureau: "华北省级灵异管控分局", erosion: 34, status: "正常",
      joinDate: "2018-01-13", ghostIds: ["G019"],
      missionsDone: 42, rating: "B", seed: true, points: 848, superiorId: "YG-0002",
      promotions: [
        { date: "2018-09", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2020-03", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2020-01", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0031", name: "田天然", rankIdx: 2, bureau: "华北省级灵异管控分局", erosion: 84, status: "正常",
      joinDate: "2021-07-10", ghostIds: ["G025"],
      missionsDone: 33, rating: "C", seed: true, points: 572, superiorId: "YG-0002",
      promotions: [
        { date: "2022-04", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2022-11", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0032", name: "程乾", rankIdx: 3, bureau: "华北省级灵异管控分局", erosion: 36, status: "正常",
      joinDate: "2020-01-06", ghostIds: ["G007","G016"],
      missionsDone: 43, rating: "A", seed: true, points: 773, superiorId: "YG-0002",
      promotions: [
        { date: "2020-09", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-07", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2022-04", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0033", name: "滑琳然", rankIdx: 2, bureau: "华南省级灵异管控分局", erosion: 25, status: "正常",
      joinDate: "2019-09-26", ghostIds: ["G024"],
      missionsDone: 34, rating: "A", seed: true, points: 466, superiorId: "YG-0002",
      promotions: [
        { date: "2020-04", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-03", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0034", name: "曲瑾", rankIdx: 3, bureau: "华南省级灵异管控分局", erosion: 23, status: "正常",
      joinDate: "2016-07-13", ghostIds: ["G017","G020"],
      missionsDone: 35, rating: "A", seed: true, points: 704, superiorId: "YG-0002",
      promotions: [
        { date: "2017-04", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2017-09", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2019-01", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0035", name: "贝昂止", rankIdx: 1, bureau: "华南省级灵异管控分局", erosion: 11, status: "正常",
      joinDate: "2022-06-04", ghostIds: ["G016"],
      missionsDone: 20, rating: "B", seed: true, points: 226, superiorId: "YG-0002",
      promotions: [
        { date: "2023-08", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0036", name: "张霆川", rankIdx: 4, bureau: "华南省级灵异管控分局", erosion: 80, status: "正常",
      joinDate: "2022-11-06", ghostIds: ["G017"],
      missionsDone: 52, rating: "C", seed: true, points: 1237, superiorId: "YG-0002",
      promotions: [
        { date: "2023-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2025-01", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2025-08", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2026-03", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0037", name: "曲瑞", rankIdx: 3, bureau: "华南省级灵异管控分局", erosion: 56, status: "正常",
      joinDate: "2024-12-03", ghostIds: ["G001","G017","G027"],
      missionsDone: 43, rating: "C", seed: true, points: 713, superiorId: "YG-0002",
      promotions: [
        { date: "2025-10", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2026-02", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2026-12", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0038", name: "花涵", rankIdx: 1, bureau: "华南省级灵异管控分局", erosion: 14, status: "正常",
      joinDate: "2017-03-25", ghostIds: ["G024","G006"],
      missionsDone: 18, rating: "B", seed: true, points: 163, superiorId: "YG-0002",
      promotions: [
        { date: "2017-11", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0039", name: "童照彻", rankIdx: 1, bureau: "华南省级灵异管控分局", erosion: 72, status: "正常",
      joinDate: "2020-10-29", ghostIds: ["G027","G025"],
      missionsDone: 15, rating: "C", seed: true, points: 194, superiorId: "YG-0002",
      promotions: [
        { date: "2021-12", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0040", name: "支墟", rankIdx: 2, bureau: "华南省级灵异管控分局", erosion: 3, status: "正常",
      joinDate: "2016-12-17", ghostIds: ["G018","G023"],
      missionsDone: 27, rating: "B", seed: true, points: 428, superiorId: "YG-0002",
      promotions: [
        { date: "2017-10", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2018-06", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0041", name: "曹霆", rankIdx: 2, bureau: "华南省级灵异管控分局", erosion: 31, status: "正常",
      joinDate: "2020-06-05", ghostIds: ["G001","G019","G018"],
      missionsDone: 27, rating: "B", seed: true, points: 570, superiorId: "YG-0002",
      promotions: [
        { date: "2021-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2022-04", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0042", name: "仲明英", rankIdx: 5, bureau: "华南省级灵异管控分局", erosion: 57, status: "正常",
      joinDate: "2023-05-03", ghostIds: ["G021","G002","G023"],
      missionsDone: 52, rating: "A", seed: true, points: 1998, superiorId: "YG-0002",
      promotions: [
        { date: "2024-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2025-09", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2026-08", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2026-05", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2026-09", title: "晋升五品御鬼者", note: "独立完成3次B级任务" }
      ] },
    { id: "YG-0043", name: "郁朴行", rankIdx: 4, bureau: "华南省级灵异管控分局", erosion: 64, status: "正常",
      joinDate: "2021-05-25", ghostIds: ["G004","G017"],
      missionsDone: 50, rating: "C", seed: true, points: 1115, superiorId: "YG-0002",
      promotions: [
        { date: "2022-02", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2023-05", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2023-08", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2025-09", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0044", name: "宁止墨", rankIdx: 1, bureau: "西南省级灵异管控分局", erosion: 55, status: "正常",
      joinDate: "2021-12-27", ghostIds: ["G025","G004"],
      missionsDone: 21, rating: "B", seed: true, points: 192, superiorId: "YG-0002",
      promotions: [
        { date: "2023-02", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0045", name: "周邪寒", rankIdx: 4, bureau: "西南省级灵异管控分局", erosion: 23, status: "正常",
      joinDate: "2016-05-10", ghostIds: ["G027","G004"],
      missionsDone: 53, rating: "A", seed: true, points: 1066, superiorId: "YG-0002",
      promotions: [
        { date: "2017-03", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2017-09", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2019-05", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2021-05", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0046", name: "穆魂", rankIdx: 6, bureau: "西南省级灵异管控分局", erosion: 34, status: "正常",
      joinDate: "2018-11-25", ghostIds: ["G002","G020","G029"],
      missionsDone: 65, rating: "S", seed: true, points: 2778, superiorId: "YG-0002",
      promotions: [
        { date: "2019-12", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2020-11", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2021-05", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2021-11", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2023-01", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2026-05", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" }
      ] },
    { id: "YG-0047", name: "鲁罡艳", rankIdx: 4, bureau: "西南省级灵异管控分局", erosion: 10, status: "正常",
      joinDate: "2021-08-13", ghostIds: ["G020"],
      missionsDone: 49, rating: "C", seed: true, points: 1186, superiorId: "YG-0002",
      promotions: [
        { date: "2022-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2023-04", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2025-05", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2025-12", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0048", name: "明长明", rankIdx: 3, bureau: "西南省级灵异管控分局", erosion: 54, status: "正常",
      joinDate: "2019-01-07", ghostIds: ["G015","G001","G023"],
      missionsDone: 39, rating: "B", seed: true, points: 962, superiorId: "YG-0002",
      promotions: [
        { date: "2020-04", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-05", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2020-10", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0049", name: "丁玉行", rankIdx: 6, bureau: "西南省级灵异管控分局", erosion: 39, status: "正常",
      joinDate: "2021-11-26", ghostIds: ["G006"],
      missionsDone: 68, rating: "A", seed: true, points: 2316, superiorId: "YG-0002",
      promotions: [
        { date: "2022-08", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2024-03", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2024-05", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2026-03", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2025-08", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2028-05", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" }
      ] },
    { id: "YG-0050", name: "任机", rankIdx: 2, bureau: "西南省级灵异管控分局", erosion: 39, status: "正常",
      joinDate: "2021-07-25", ghostIds: ["G026"],
      missionsDone: 25, rating: "A", seed: true, points: 338, superiorId: "YG-0002",
      promotions: [
        { date: "2022-02", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2022-09", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0051", name: "丁琅", rankIdx: 0, bureau: "西南省级灵异管控分局", erosion: 31, status: "正常",
      joinDate: "2018-04-09", ghostIds: ["G027"],
      missionsDone: 5, rating: "B", seed: true, points: 35, superiorId: "YG-0002",
      promotions: [
        { date: "2018-05", title: "天赋觉醒登记", note: "档案备案完成，入门培训进行中" }
      ] },
    { id: "YG-0052", name: "仇乾归", rankIdx: 4, bureau: "西南省级灵异管控分局", erosion: 7, status: "正常",
      joinDate: "2018-01-15", ghostIds: ["G029","G001","G024"],
      missionsDone: 51, rating: "C", seed: true, points: 1237, superiorId: "YG-0002",
      promotions: [
        { date: "2018-10", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2019-07", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2021-04", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2021-09", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0053", name: "家照魂", rankIdx: 6, bureau: "西南省级灵异管控分局", erosion: 65, status: "正常",
      joinDate: "2025-07-17", ghostIds: ["G002","G018"],
      missionsDone: 68, rating: "A", seed: true, points: 2856, superiorId: "YG-0002",
      promotions: [
        { date: "2026-05", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2027-07", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2028-10", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2028-11", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2030-02", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2030-07", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" }
      ] },
    { id: "YG-0054", name: "狄墨镇", rankIdx: 3, bureau: "镇狱司 · 总局直属", erosion: 25, status: "正常",
      joinDate: "2023-08-15", ghostIds: ["G016"],
      missionsDone: 43, rating: "C", seed: true, points: 781, superiorId: "YG-0003",
      promotions: [
        { date: "2024-08", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2025-08", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2026-11", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0055", name: "翁坤知", rankIdx: 1, bureau: "镇狱司 · 总局直属", erosion: 15, status: "正常",
      joinDate: "2020-02-28", ghostIds: ["G024","G006"],
      missionsDone: 26, rating: "C", seed: true, points: 188, superiorId: "YG-0003",
      promotions: [
        { date: "2021-01", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0056", name: "程乾川", rankIdx: 3, bureau: "镇狱司 · 总局直属", erosion: 40, status: "正常",
      joinDate: "2016-08-18", ghostIds: ["G029","G027"],
      missionsDone: 37, rating: "C", seed: true, points: 790, superiorId: "YG-0003",
      promotions: [
        { date: "2017-06", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2018-10", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2018-08", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0057", name: "司昂朗", rankIdx: 6, bureau: "镇狱司 · 总局直属", erosion: 61, status: "正常",
      joinDate: "2024-10-18", ghostIds: ["G010"],
      missionsDone: 66, rating: "S", seed: true, points: 2666, superiorId: "YG-0003",
      promotions: [
        { date: "2025-08", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2026-10", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2028-07", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2029-06", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2030-08", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2031-10", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" }
      ] },
    { id: "YG-0058", name: "林七", rankIdx: 3, bureau: "镇狱司 · 总局直属", erosion: 20, status: "正常",
      joinDate: "2019-07-13", ghostIds: ["G003","G006"],
      missionsDone: 36, rating: "B", seed: true, points: 791, superiorId: "YG-0003",
      promotions: [
        { date: "2020-04", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2020-11", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2022-04", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0059", name: "徐斩", rankIdx: 2, bureau: "镇狱司 · 总局直属", erosion: 13, status: "正常",
      joinDate: "2023-05-23", ghostIds: ["G006","G019"],
      missionsDone: 27, rating: "B", seed: true, points: 559, superiorId: "YG-0003",
      promotions: [
        { date: "2024-06", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2025-05", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0060", name: "詹扶彻", rankIdx: 4, bureau: "镇狱司 · 总局直属", erosion: 67, status: "正常",
      joinDate: "2022-07-17", ghostIds: ["G006","G020"],
      missionsDone: 46, rating: "B", seed: true, points: 1321, superiorId: "YG-0003",
      promotions: [
        { date: "2023-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2024-03", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2026-04", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2027-03", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0061", name: "禹七然", rankIdx: 1, bureau: "镇狱司 · 总局直属", erosion: 5, status: "正常",
      joinDate: "2023-12-21", ghostIds: ["G003","G019"],
      missionsDone: 14, rating: "B", seed: true, points: 169, superiorId: "YG-0003",
      promotions: [
        { date: "2024-10", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0062", name: "严光", rankIdx: 2, bureau: "镇狱司 · 总局直属", erosion: 13, status: "正常",
      joinDate: "2016-03-22", ghostIds: ["G006","G015"],
      missionsDone: 27, rating: "C", seed: true, points: 549, superiorId: "YG-0003",
      promotions: [
        { date: "2017-03", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2018-05", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0063", name: "马破", rankIdx: 1, bureau: "镇狱司 · 总局直属", erosion: 22, status: "正常",
      joinDate: "2016-09-27", ghostIds: ["G018","G004"],
      missionsDone: 21, rating: "C", seed: true, points: 204, superiorId: "YG-0003",
      promotions: [
        { date: "2017-10", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0064", name: "羊明", rankIdx: 2, bureau: "封裂营 · 总局直属", erosion: 55, status: "正常",
      joinDate: "2024-10-24", ghostIds: ["G015","G017","G024"],
      missionsDone: 35, rating: "C", seed: true, points: 362, superiorId: "YG-0004",
      promotions: [
        { date: "2025-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2026-02", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0065", name: "丁雨", rankIdx: 6, bureau: "封裂营 · 总局直属", erosion: 8, status: "正常",
      joinDate: "2022-08-03", ghostIds: ["G017","G001","G009"],
      missionsDone: 68, rating: "B", seed: true, points: 2363, superiorId: "YG-0004",
      promotions: [
        { date: "2023-11", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2023-10", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2024-11", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2025-04", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2027-03", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2030-02", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" }
      ] },
    { id: "YG-0066", name: "司云镇", rankIdx: 3, bureau: "封裂营 · 总局直属", erosion: 14, status: "正常",
      joinDate: "2025-06-19", ghostIds: ["G006","G025","G003"],
      missionsDone: 40, rating: "C", seed: true, points: 850, superiorId: "YG-0004",
      promotions: [
        { date: "2026-01", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2026-08", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2028-09", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0067", name: "仲涵朗", rankIdx: 3, bureau: "封裂营 · 总局直属", erosion: 10, status: "正常",
      joinDate: "2019-09-04", ghostIds: ["G016","G001"],
      missionsDone: 36, rating: "B", seed: true, points: 801, superiorId: "YG-0004",
      promotions: [
        { date: "2020-12", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2020-11", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2021-12", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0068", name: "符七山", rankIdx: 3, bureau: "封裂营 · 总局直属", erosion: 67, status: "正常",
      joinDate: "2024-08-11", ghostIds: ["G024","G006"],
      missionsDone: 43, rating: "A", seed: true, points: 667, superiorId: "YG-0004",
      promotions: [
        { date: "2025-03", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2026-12", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2027-02", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0069", name: "吴云", rankIdx: 6, bureau: "封裂营 · 总局直属", erosion: 67, status: "正常",
      joinDate: "2017-06-11", ghostIds: ["G025","G026","G028"],
      missionsDone: 64, rating: "S", seed: true, points: 2322, superiorId: "YG-0004",
      promotions: [
        { date: "2018-03", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2018-10", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2020-06", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2022-02", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2020-10", title: "晋升五品御鬼者", note: "独立完成3次B级任务" },
        { date: "2021-06", title: "晋升四品御鬼者", note: "参与封印鬼煞1只" }
      ] },
    { id: "YG-0070", name: "谢斩", rankIdx: 3, bureau: "封裂营 · 总局直属", erosion: 27, status: "正常",
      joinDate: "2018-09-19", ghostIds: ["G027","G016","G001"],
      missionsDone: 38, rating: "B", seed: true, points: 952, superiorId: "YG-0004",
      promotions: [
        { date: "2019-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-03", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2020-09", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0071", name: "谢源", rankIdx: 2, bureau: "封裂营 · 总局直属", erosion: 14, status: "正常",
      joinDate: "2017-11-11", ghostIds: ["G023","G001"],
      missionsDone: 36, rating: "A", seed: true, points: 367, superiorId: "YG-0004",
      promotions: [
        { date: "2018-11", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2019-09", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0072", name: "项竹归", rankIdx: 1, bureau: "刑幽署 · 总局直属", erosion: 67, status: "正常",
      joinDate: "2016-05-25", ghostIds: ["G018"],
      missionsDone: 16, rating: "B", seed: true, points: 249, superiorId: "YG-0005",
      promotions: [
        { date: "2017-01", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0073", name: "尹昂", rankIdx: 4, bureau: "刑幽署 · 总局直属", erosion: 80, status: "正常",
      joinDate: "2018-03-31", ghostIds: ["G003"],
      missionsDone: 52, rating: "B", seed: true, points: 1273, superiorId: "YG-0005",
      promotions: [
        { date: "2019-05", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2020-03", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2019-12", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2023-03", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0074", name: "奚魄", rankIdx: 5, bureau: "刑幽署 · 总局直属", erosion: 21, status: "正常",
      joinDate: "2022-02-25", ghostIds: ["G018","G001","G010"],
      missionsDone: 52, rating: "S", seed: true, points: 1792, superiorId: "YG-0005",
      promotions: [
        { date: "2023-02", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2023-04", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2023-11", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2026-02", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2027-02", title: "晋升五品御鬼者", note: "独立完成3次B级任务" }
      ] },
    { id: "YG-0075", name: "於琛素", rankIdx: 4, bureau: "刑幽署 · 总局直属", erosion: 3, status: "正常",
      joinDate: "2016-01-27", ghostIds: ["G002","G020","G006"],
      missionsDone: 49, rating: "B", seed: true, points: 1390, superiorId: "YG-0005",
      promotions: [
        { date: "2017-04", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2017-09", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2019-01", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2020-09", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0076", name: "羊琳镇", rankIdx: 3, bureau: "刑幽署 · 总局直属", erosion: 55, status: "正常",
      joinDate: "2025-02-11", ghostIds: ["G017","G025"],
      missionsDone: 38, rating: "C", seed: true, points: 868, superiorId: "YG-0005",
      promotions: [
        { date: "2026-05", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2026-04", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2027-05", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0077", name: "夏天", rankIdx: 4, bureau: "刑幽署 · 总局直属", erosion: 9, status: "正常",
      joinDate: "2024-05-24", ghostIds: ["G015","G020"],
      missionsDone: 44, rating: "C", seed: true, points: 1205, superiorId: "YG-0005",
      promotions: [
        { date: "2025-08", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2026-03", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2027-05", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2026-09", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0078", name: "车照", rankIdx: 4, bureau: "刑幽署 · 总局直属", erosion: 11, status: "正常",
      joinDate: "2017-09-06", ghostIds: ["G019","G026","G017"],
      missionsDone: 42, rating: "A", seed: true, points: 1441, superiorId: "YG-0005",
      promotions: [
        { date: "2018-09", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2019-03", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2020-06", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2022-09", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0079", name: "叶扶", rankIdx: 2, bureau: "滨江市灵异治安队", erosion: 38, status: "正常",
      joinDate: "2023-10-20", ghostIds: ["G017","G027"],
      missionsDone: 22, rating: "B", seed: true, points: 557, superiorId: "YG-0006",
      promotions: [
        { date: "2024-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2025-02", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0080", name: "仲朴声", rankIdx: 1, bureau: "滨江市灵异治安队", erosion: 43, status: "正常",
      joinDate: "2017-03-06", ghostIds: ["G019"],
      missionsDone: 18, rating: "B", seed: true, points: 139, superiorId: "YG-0006",
      promotions: [
        { date: "2017-12", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0081", name: "叶雨彻", rankIdx: 5, bureau: "滨江市灵异治安队", erosion: 33, status: "正常",
      joinDate: "2023-11-07", ghostIds: ["G028","G003","G021"],
      missionsDone: 54, rating: "A", seed: true, points: 1915, superiorId: "YG-0006",
      promotions: [
        { date: "2024-10", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2026-03", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2026-08", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2026-03", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2026-10", title: "晋升五品御鬼者", note: "独立完成3次B级任务" }
      ] },
    { id: "YG-0082", name: "强敏艳", rankIdx: 1, bureau: "滨江市灵异治安队", erosion: 48, status: "正常",
      joinDate: "2021-12-15", ghostIds: ["G026","G018"],
      missionsDone: 26, rating: "C", seed: true, points: 252, superiorId: "YG-0006",
      promotions: [
        { date: "2022-08", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0083", name: "司朴魂", rankIdx: 4, bureau: "滨江市灵异治安队", erosion: 76, status: "正常",
      joinDate: "2018-12-23", ghostIds: ["G028","G016","G003"],
      missionsDone: 55, rating: "B", seed: true, points: 1173, superiorId: "YG-0006",
      promotions: [
        { date: "2020-01", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-02", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2022-03", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2023-08", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] },
    { id: "YG-0084", name: "宁无山", rankIdx: 5, bureau: "滨江市灵异治安队", erosion: 72, status: "正常",
      joinDate: "2021-03-20", ghostIds: ["G015","G018"],
      missionsDone: 52, rating: "S", seed: true, points: 1558, superiorId: "YG-0006",
      promotions: [
        { date: "2022-01", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2023-07", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2023-06", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2025-03", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" },
        { date: "2024-07", title: "晋升五品御鬼者", note: "独立完成3次B级任务" }
      ] },
    { id: "YG-0085", name: "明琳知", rankIdx: 1, bureau: "滨江市灵异治安队", erosion: 18, status: "正常",
      joinDate: "2017-05-06", ghostIds: ["G027"],
      missionsDone: 25, rating: "B", seed: true, points: 281, superiorId: "YG-0006",
      promotions: [
        { date: "2018-05", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0086", name: "龚寒尘", rankIdx: 0, bureau: "滨江市灵异治安队", erosion: 51, status: "正常",
      joinDate: "2025-06-21", ghostIds: ["G018"],
      missionsDone: 5, rating: "C", seed: true, points: 22, superiorId: "YG-0006",
      promotions: [
        { date: "2025-09", title: "天赋觉醒登记", note: "档案备案完成，入门培训进行中" }
      ] },
    { id: "YG-0087", name: "谷阳", rankIdx: 2, bureau: "滨江市灵异治安队", erosion: 63, status: "正常",
      joinDate: "2019-03-25", ghostIds: ["G001","G018","G027"],
      missionsDone: 23, rating: "A", seed: true, points: 550, superiorId: "YG-0006",
      promotions: [
        { date: "2019-12", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-09", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0088", name: "余魄", rankIdx: 3, bureau: "滨江市灵异治安队", erosion: 15, status: "正常",
      joinDate: "2019-08-22", ghostIds: ["G024","G019"],
      missionsDone: 41, rating: "B", seed: true, points: 706, superiorId: "YG-0006",
      promotions: [
        { date: "2020-04", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-08", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2023-05", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" }
      ] },
    { id: "YG-0089", name: "叶琅", rankIdx: 0, bureau: "滨江市灵异治安队", erosion: 42, status: "正常",
      joinDate: "2025-07-13", ghostIds: [],
      missionsDone: 3, rating: "B", seed: true, points: 27, superiorId: "YG-0006",
      promotions: [
        { date: "2025-10", title: "天赋觉醒登记", note: "档案备案完成，入门培训进行中" }
      ] },
    { id: "YG-0090", name: "隗天川", rankIdx: 2, bureau: "滨江市灵异治安队", erosion: 18, status: "正常",
      joinDate: "2019-05-28", ghostIds: ["G017","G006"],
      missionsDone: 26, rating: "C", seed: true, points: 477, superiorId: "YG-0006",
      promotions: [
        { date: "2020-05", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2021-07", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0091", name: "吉竹", rankIdx: 1, bureau: "城南区县级御鬼者驿站", erosion: 57, status: "正常",
      joinDate: "2019-10-10", ghostIds: ["G016"],
      missionsDone: 18, rating: "C", seed: true, points: 206, superiorId: "YG-0007",
      promotions: [
        { date: "2020-07", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" }
      ] },
    { id: "YG-0092", name: "昌霜", rankIdx: 2, bureau: "城南区县级御鬼者驿站", erosion: 61, status: "正常",
      joinDate: "2022-01-30", ghostIds: ["G026","G001","G016"],
      missionsDone: 26, rating: "B", seed: true, points: 553, superiorId: "YG-0007",
      promotions: [
        { date: "2023-03", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2023-09", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0093", name: "樊斩", rankIdx: 2, bureau: "城南区县级御鬼者驿站", erosion: 5, status: "正常",
      joinDate: "2022-07-08", ghostIds: ["G015","G027"],
      missionsDone: 33, rating: "B", seed: true, points: 518, superiorId: "YG-0007",
      promotions: [
        { date: "2023-10", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2025-01", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0094", name: "韦明", rankIdx: 0, bureau: "城南区县级御鬼者驿站", erosion: 34, status: "正常",
      joinDate: "2018-12-24", ghostIds: [],
      missionsDone: 5, rating: "C", seed: true, points: 60, superiorId: "YG-0007",
      promotions: [
        { date: "2019-03", title: "天赋觉醒登记", note: "档案备案完成，入门培训进行中" }
      ] },
    { id: "YG-0095", name: "计机", rankIdx: 0, bureau: "城南区县级御鬼者驿站", erosion: 60, status: "正常",
      joinDate: "2024-03-21", ghostIds: ["G019"],
      missionsDone: 6, rating: "B", seed: true, points: 31, superiorId: "YG-0007",
      promotions: [
        { date: "2024-05", title: "天赋觉醒登记", note: "档案备案完成，入门培训进行中" }
      ] },
    { id: "YG-0096", name: "石琛止", rankIdx: 0, bureau: "城南区县级御鬼者驿站", erosion: 56, status: "正常",
      joinDate: "2018-09-08", ghostIds: ["G001"],
      missionsDone: 6, rating: "C", seed: true, points: 41, superiorId: "YG-0007",
      promotions: [
        { date: "2018-12", title: "天赋觉醒登记", note: "档案备案完成，入门培训进行中" }
      ] },
    { id: "YG-0097", name: "臧墟", rankIdx: 2, bureau: "城南区县级御鬼者驿站", erosion: 63, status: "正常",
      joinDate: "2021-11-06", ghostIds: ["G024","G003"],
      missionsDone: 23, rating: "B", seed: true, points: 484, superiorId: "YG-0007",
      promotions: [
        { date: "2023-01", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2024-05", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0098", name: "糜雷山", rankIdx: 2, bureau: "城南区县级御鬼者驿站", erosion: 39, status: "正常",
      joinDate: "2016-11-18", ghostIds: ["G019","G006"],
      missionsDone: 31, rating: "B", seed: true, points: 525, superiorId: "YG-0007",
      promotions: [
        { date: "2017-08", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2018-11", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0099", name: "何乾舟", rankIdx: 2, bureau: "城南区县级御鬼者驿站", erosion: 58, status: "正常",
      joinDate: "2020-11-25", ghostIds: ["G025"],
      missionsDone: 27, rating: "B", seed: true, points: 343, superiorId: "YG-0007",
      promotions: [
        { date: "2021-12", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2022-11", title: "晋升八品御鬼者", note: "独立完成2次B级任务" }
      ] },
    { id: "YG-0100", name: "窦瑾墨", rankIdx: 4, bureau: "城南区县级御鬼者驿站", erosion: 34, status: "正常",
      joinDate: "2021-10-19", ghostIds: ["G023","G020","G004"],
      missionsDone: 44, rating: "C", seed: true, points: 1380, superiorId: "YG-0007",
      promotions: [
        { date: "2022-06", title: "晋升九品御鬼者", note: "入门培训全优结业，侵蚀度稳定达标" },
        { date: "2023-10", title: "晋升八品御鬼者", note: "独立完成2次B级任务" },
        { date: "2024-10", title: "晋升七品御鬼者", note: "累计封印厉鬼10只以下" },
        { date: "2024-02", title: "晋升六品御鬼者", note: "参与A级任务、积分达标" }
      ] }
  ];

  /* ---------- 主控台广播 ---------- */
  const BROADCASTS = [
    "【全国阴隙监测网】滨江市阴隙群活跃度上升 <b>37%</b>，封裂营已进驻",
    "【灾害预警】北邙山遗址维持 <b>S级紧急</b> 状态，白骨鬼帅沉睡读数不稳",
    "【通缉协查】刑幽署悬赏：红衣鬼将 G009、千面鬼王 G014 线索即时上报",
    "【装备通告】镇幽玉盒本月审批名额开放，请六品以上御鬼者通过驿站提交",
    "【侵蚀提示】梅雨季节怨气浓度偏高，建议全员随身佩戴镇魂玉佩",
    "【黑灾预案】滨江市全城应急通道已开启，无任务人员禁止靠近阴隙警戒区"
  ];

  /* ---------- 主控台弹窗消息 ---------- */
  const NOTIFICATIONS = [
    { level: "red", icon: "alarm", title: "S级灾害异动", text: "北邙山白骨鬼帅沉睡波动加剧，省级警戒启动中", force: 0 },
    { level: "cyan", icon: "erosion", title: "侵蚀度例行提醒", text: "请于48小时内到驿站完成侵蚀度复检与手环同步", force: 0 }
  ];

  /* ---------- 任务等级 → 所需御鬼者等级索引 ---------- */
  const MISSION_RANK_REQ = { D: 0, C: 1, B: 2, A: 4, S: 9, SS: 10 };
  // 注：S 需一品御鬼者（rankIdx≥9）以上可接；SS 需天御（rankIdx≥10）

  /* ---------- 道具使用效果 ---------- */
  // type=consume：背包中可使用一次并消耗；type=feed：鬼灵仓库喂养用
  // 价格与效果匹配：净化类按 ~3-5 冥币/1% 定价；高价值珍品可直接提升品级（积分）
  const ITEM_EFFECTS = {
    EQ013: { name: "短效净化剂", type: "consume", erosion: -15, desc: "侵蚀度降低 15%" },
    EQ014: { name: "安神药剂", type: "consume", erosion: -8, desc: "侵蚀度降低 8%，精神稳定" },
    EQ015: { name: "契约稳固药剂", type: "consume", erosion: -20, desc: "侵蚀度降低 20%，契约稳固" },
    EQ016: { name: "阴灵口粮", type: "feed", hunger: 40, desc: "于鬼灵仓库喂养契约鬼灵，饱食度 +40" },
    // 装备类：激发装备灵能，一次性消耗（灵能耗尽装备需重新充能/兑换）
    EQ003: { name: "阴能探测棒", type: "consume", erosion: -35, desc: "激发探测棒全域扫描，净化环境阴能，侵蚀度降低 35%" },
    EQ008: { name: "镇魂玉佩", type: "consume", erosion: -60, desc: "激发玉佩镇魂之力，心神大定，侵蚀度降低 60%" },
    EQ009: { name: "抗侵蚀面罩", type: "consume", erosion: -50, desc: "激发面罩过滤阵，逆转呼吸道侵蚀，侵蚀度降低 50%" },
    EQ010: { name: "镇幽短刃", type: "consume", erosion: -80, desc: "以短刃破阴法阵斩断侵体阴丝，侵蚀度降低 80%" },
    // 高价值珍品：直接注入功勋积分，可推动品级晋升（受晋升门槛约束）
    EQ011: { name: "破阴弩", type: "consume", points: 300, desc: "上交军功凭证，功勋积分 +300" },
    EQ012: { name: "镇狱刀", type: "consume", points: 800, desc: "镇狱司记功，功勋积分 +800" },
    EQ005: { name: "镇幽玉盒", type: "consume", points: 120, desc: "献祭盒中封存阴髓，功勋积分 +120" },
    EQ006: { name: "移动封印阵盘", type: "consume", points: 200, desc: "上缴阵盘记录战功，功勋积分 +200" }
  };

  /* ---------- 冥府商城商品（冥币计价） ---------- */
  const SHOP_ITEMS = [
    { id: "EQ016", price: 15,  tag: "热销", blurb: "契约鬼灵每日必需口粮，饱食度归零鬼灵将逃逸" },
    { id: "EQ014", price: 25,  tag: "", blurb: "任务常备，稳定心神抗幻术" },
    { id: "EQ013", price: 40,  tag: "热销", blurb: "紧急净化，侵蚀度立降 15%" },
    { id: "EQ015", price: 90,  tag: "高阶", blurb: "签订契约必备，净化兼稳固" },
    { id: "EQ003", price: 150, tag: "", blurb: "九品制式侦测装备，净化周身阴能" },
    { id: "EQ005", price: 220, tag: "珍品", blurb: "封存阴髓的玉盒，献祭可记功勋 +120 积分" },
    { id: "EQ009", price: 260, tag: "", blurb: "七品防护装备，逆转呼吸道侵蚀" },
    { id: "EQ006", price: 300, tag: "珍品", blurb: "四品封印阵盘，上缴记录战功 +200 积分" },
    { id: "EQ008", price: 320, tag: "限量", blurb: "持续镇魂，侵蚀度大幅回落" },
    { id: "EQ010", price: 500, tag: "管制", blurb: "八品制式武器，斩断侵体阴丝" },
    { id: "EQ011", price: 650, tag: "珍品", blurb: "五品远程管制武器，上交军功凭证 +300 积分" },
    { id: "EQ012", price: 1500, tag: "镇库", blurb: "镇狱司最高管制，记功 +800 积分，可直推品级晋升" }
  ];

  /* ---------- 任务完成机缘配置 ---------- */
  const MISSION_COIN_REWARD = { D: 20, C: 50, B: 120, A: 300, S: 800, SS: 2000 };
  // 各等级任务触发「鬼怪现身」契约机缘的概率
  const MISSION_CONTRACT_CHANCE = { D: 0.10, C: 0.18, B: 0.30, A: 0.45, S: 0.65, SS: 0.9 };

  /* ---------- 晋升契约条件：晋升到该品级需已契约对应等级鬼怪 ---------- */
  // key 为目标 rankIdx，value 为所需鬼怪等级名（需拥有 ≥该等级 order 的契约鬼灵）
  const PROMO_GHOST_REQ = {
    3: "厉鬼",   // 晋升七品
    5: "鬼煞",   // 晋升五品
    7: "鬼将",   // 晋升三品
    8: "鬼帅",   // 晋升二品
    9: "鬼王"    // 晋升一品
  };

  /* ---------- 机构层级（bureau 字段关键字 → 层级，决定可竞选官职范围） ---------- */
  const BUREAU_TIERS = [
    { key: "station",  name: "县级驿站", match: ["驿站"] },
    { key: "city",     name: "市级治安队", match: ["治安队"] },
    { key: "province", name: "省级分局", match: ["分局"] },
    { key: "hq",       name: "总局直属", match: ["总局", "镇狱司", "封裂营", "刑幽署", "总部"] }
  ];
  // 层级序号：驿站0 < 市级1 < 省级2 < 总局3；未知机构按驿站处理
  function bureauTierOf(bureau) {
    const b = String(bureau || "");
    for (let i = BUREAU_TIERS.length - 1; i >= 0; i--) {
      if (BUREAU_TIERS[i].match.some(k => b.includes(k))) return i;
    }
    return 0;
  }

  /* ---------- bureau → 组织架构节点（ORGS.id）：领导管辖范围与组织页领导展示共用 ---------- */
  function orgIdOfBureau(bureau) {
    const b = String(bureau || "");
    if (b.includes("封裂营")) return "FLY";
    if (b.includes("刑幽署")) return "XYS";
    if (b.includes("镇狱司")) return "ZYS";
    if (b.includes("省级") || b.includes("分局")) return "PROV";
    if (b.includes("治安队")) return "CITY";
    if (b.includes("驿站")) return "STATION";
    if (b.includes("总局")) return "HQ";
    return null;
  }

  /* ---------- 官职体系（符合条件后自行申请争取，可晋升改任更高职务） ---------- */
  // coinBonus：任官后每次任务结算的冥币加成；reqTier：所需机构层级（见 BUREAU_TIERS）
  // clearBonus：档案监察权加成 —— 可查看「自身品级 + clearBonus」范围内的详细档案
  const OFFICIALS = [
    { id: "OF1", name: "驿站驿丞",   reqRankIdx: 1, reqPoints: 100,  reqMissions: 3,  coinBonus: 5,  reqTier: 0, tierName: "县级驿站", clearBonus: 1,
      perm: "监察本驿站见习御鬼者档案",
      desc: "执掌一方驿站庶务，统筹见习御鬼者日常巡防" },
    { id: "OF2", name: "县级县尉",   reqRankIdx: 2, reqPoints: 300,  reqMissions: 8,  coinBonus: 15, reqTier: 0, tierName: "县级驿站", clearBonus: 1,
      perm: "监察县域内下级御鬼者档案",
      desc: "总领县域灵异治安，直接指挥辖区御鬼者小队" },
    { id: "OF3", name: "市级镇守使", reqRankIdx: 3, reqPoints: 600,  reqMissions: 15, coinBonus: 30, reqTier: 1, tierName: "市级治安队", clearBonus: 2,
      perm: "跨机构调阅全市御鬼者档案",
      desc: "镇守一市阴阳秩序，可调动市级装备库资源" },
    { id: "OF4", name: "省级巡抚",   reqRankIdx: 4, reqPoints: 1200, reqMissions: 25, coinBonus: 60, reqTier: 2, tierName: "省级分局", clearBonus: 3,
      perm: "省级监察权，可调阅高品级御鬼者机密档案",
      desc: "巡抚一省灵异事务，A级灾害现场最高指挥" },
    { id: "OF5", name: "镇狱司指挥使", reqRankIdx: 5, reqPoints: 2500, reqMissions: 40, coinBonus: 120, reqTier: 3, tierName: "总局直属", clearBonus: 4,
      perm: "总局监察权，可调阅全国各品级档案",
      desc: "执掌镇狱司征伐，持节调动封裂营" },
    { id: "OF6", name: "天御巡察使", reqRankIdx: 7, reqPoints: 6000, reqMissions: 60, coinBonus: 250, reqTier: 3, tierName: "总局直属", clearBonus: 99,
      perm: "代天巡狩，全国档案无密级限制",
      desc: "代天巡狩全国，直达天听，SS级灾害先斩后奏" }
  ];

  /* ---------- 功能解锁表（按有效品级解锁；未列出的页面默认开放） ---------- */
  // value = 解锁所需的 RANKS.idx；未列出的页面默认开放
  const FEATURE_UNLOCK = {
    ghostsMine:   1,  // 鬼灵仓库：九品解锁
    shop:         2,  // 冥府商城：八品解锁
    officials:    3,  // 官职竞选：七品解锁
    organization: 5,  // 组织架构：五品解锁
    disaster:     6   // 灾难预案：四品解锁
  };

  /* ---------- 全国灾难预警节点（虚拟城市名；坐标为 860×620 视区定位，全部约束在球体监测界内） ---------- */
  // base = 基础灾情等级（0 安全，1-6 对应 DISASTERS 蓝/黄/橙/红/黑/灭），实时等级按 30 秒时间桶围绕 base 波动
  const NATION_ZONES = [
    { id: "binjiang",  name: "滨江市",   x: 505, y: 385, base: 5, kw: ["滨江", "青岭", "城南", "南郊", "西郊", "东郊", "老街", "夜市", "填埋", "水库", "暗河", "书院", "戏楼", "监狱", "古镇", "阳光小区", "第三中学", "殡葬巷"] },
    { id: "beimang",   name: "北邙市",   x: 540, y: 295, base: 4, kw: ["北邙", "古战场", "雷暴", "乱葬岗"] },
    { id: "daiyue",    name: "岱岳城",   x: 575, y: 265, base: 3, kw: ["泰山"] },
    { id: "shuoliang", name: "朔凉城",   x: 425, y: 270, base: 3, kw: ["西北", "火山", "油库"] },
    { id: "jinguan",   name: "锦官城",   x: 418, y: 350, base: 2, kw: ["西南", "乱军", "古庙", "葬坑"] },
    { id: "canger",    name: "苍洱城",   x: 415, y: 445, base: 2, kw: ["荒村", "疫"] },
    { id: "changan",   name: "长安城",   x: 485, y: 300, base: 2, kw: ["博物馆", "铜镜"] },
    { id: "shenjing",  name: "神京",     x: 565, y: 225, base: 2, kw: ["总局", "千面", "全国范围"] },
    { id: "bingyuan",  name: "冰渊城",   x: 605, y: 155, base: 1, kw: ["冰渊"] },
    { id: "changbai",  name: "长白城",   x: 628, y: 175, base: 1, kw: ["长白"] },
    { id: "shengjing", name: "盛京城",   x: 598, y: 200, base: 1, kw: ["盛京"] },
    { id: "shuoyuan",  name: "朔原城",   x: 505, y: 190, base: 0, kw: ["草原"] },
    { id: "helan",     name: "贺兰城",   x: 465, y: 235, base: 0, kw: ["贺兰"] },
    { id: "huangshui", name: "湟水城",   x: 395, y: 260, base: 1, kw: ["湟水"] },
    { id: "tianshan",  name: "天山城",   x: 290, y: 200, base: 1, kw: ["天山"] },
    { id: "xueyu",     name: "雪域城",   x: 285, y: 380, base: 1, kw: ["雪域"] },
    { id: "bingzhou",  name: "并州城",   x: 515, y: 245, base: 1, kw: ["并州"] },
    { id: "changshan", name: "常山城",   x: 545, y: 250, base: 0, kw: ["常山"] },
    { id: "jinling",   name: "金陵城",   x: 605, y: 325, base: 1, kw: ["金陵"] },
    { id: "luzhou",    name: "庐州城",   x: 572, y: 345, base: 0, kw: ["庐州"] },
    { id: "shenhai",   name: "申海城",   x: 640, y: 345, base: 1, kw: ["申海"] },
    { id: "linan",     name: "临安城",   x: 620, y: 365, base: 0, kw: ["临安"] },
    { id: "yunmeng",   name: "云梦城",   x: 545, y: 355, base: 1, kw: ["云梦"] },
    { id: "tanzhou",   name: "潭州城",   x: 540, y: 400, base: 1, kw: ["潭州"] },
    { id: "hongdu",    name: "洪都城",   x: 572, y: 390, base: 0, kw: ["洪都"] },
    { id: "minshui",   name: "闽水城",   x: 610, y: 420, base: 1, kw: ["闽水"] },
    { id: "suicheng",  name: "穗城",     x: 540, y: 465, base: 1, kw: ["穗城"] },
    { id: "pengcheng", name: "鹏城",     x: 562, y: 475, base: 0, kw: ["鹏城"] },
    { id: "yongcheng", name: "邕城",     x: 485, y: 465, base: 0, kw: ["邕城"] },
    { id: "zhuoya",    name: "珠崖城",   x: 515, y: 505, base: 0, kw: ["珠崖"] },
    { id: "qianzhong", name: "黔中城",   x: 460, y: 425, base: 1, kw: ["黔中"] },
    { id: "yuzhou",    name: "渝州城",   x: 458, y: 380, base: 1, kw: ["渝州"] }
  ];

  /* ---------- 新任务生成模板（用于自动刷新） ---------- */
  const MISSION_TEMPLATES = [
    { prefix: "城区", names: ["路灯异响排查", "楼道阴气清扫", "废弃储物间处理", "地下停车场巡查", "公园深夜人影", "便利店冰柜异响", "电影院散场幽灵", "出租屋哭声溯源"], levels: ["D", "C"], places: ["城南区", "阳光小区", "滨江新城", "北区商业街", "青河公园", "安平里", "老街夜市", "永安巷"], pointsBase: { D: 12, C: 45 } },
    { prefix: "近郊", names: ["废弃医院巡逻", "工地怨气清理", "旧厂区异常排查", "河道阴气监测", "废弃教堂钟声", "拆迁楼夜半哭喊", "山区隧道阴寒", "古镇戏台回音"], levels: ["C", "B"], places: ["西郊职工医院", "北区工地", "东郊旧厂", "青河下游", "落凤山", "旧城根", "安平古镇", "北岭隧道"], pointsBase: { C: 55, B: 220 } },
    { prefix: "高危", names: ["鬼煞封锁行动", "鬼域边缘勘察", "阴隙裂缝处理", "大型怨气泄漏", "阴兵过境拦截", "鬼潮源头追溯", "镇物加固维护", "裂谷封印加固"], levels: ["A", "S"], places: ["南郊填埋场", "市中心烂尾楼", "青岭水库", "北邙山外围", "西南裂谷", "古城墙遗址", "海底隧道", "无人荒漠"], pointsBase: { A: 850, S: 3200 } }
  ];

  return {
    GHOST_LEVELS, GHOSTS,
    EQUIP_CATEGORIES, EQUIPMENTS,
    MISSIONS, RANKS, DISASTERS, ORGS, BUREAUS,
    SEED_PROFILES, BROADCASTS, NOTIFICATIONS,
    MISSION_RANK_REQ, ITEM_EFFECTS, MISSION_TEMPLATES,
    SHOP_ITEMS, MISSION_COIN_REWARD, MISSION_CONTRACT_CHANCE, OFFICIALS, PROMO_GHOST_REQ,
    BUREAU_TIERS, bureauTierOf, orgIdOfBureau, FEATURE_UNLOCK, REGISTER_BUREAUS, REGISTER_ORGS, NATION_ZONES
  };
})();

/* 组织架构 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { esc, badge, rankCls, statusCls, Profiles } = window.YG;

  const tree = document.getElementById("orgTree");
  const detail = document.getElementById("orgDetail");

  const byId = id => D.ORGS.find(o => o.id === id);

  /* ---------- 各机构最高领导（总局为 YG-0001，其余取种子领导的 orgId 对应） ---------- */
  function orgLeader(o) {
    if (o.top) return D.SEED_PROFILES.find(p => p.id === "YG-0001") || null;
    return D.SEED_PROFILES.find(p => p.leader && p.orgId === o.id) || null;
  }

  /* ---------- 机构成员（种子档案 + 注册用户，品级为实时有效品级） ---------- */
  function orgMembers(o) {
    const all = Profiles.all();
    let list = [];
    if (o.id === "HQ") {
      list = all.filter(p => D.bureauTierOf(p.bureau) === 3);
    } else if (o.direct) {
      list = all.filter(p => p.bureau.includes(o.name));
    } else if (o.id === "PROV") {
      list = all.filter(p => p.bureau.includes("省级") && !p.bureau.startsWith("原"));
    } else if (o.id === "CITY") {
      list = all.filter(p => p.bureau.includes("治安队"));
    } else if (o.id === "STATION") {
      list = all.filter(p => p.bureau.includes("驿站"));
    }
    return list.sort((a, b) => b.rankIdx - a.rankIdx);
  }

  function nodeClass(o) {
    if (o.top) return "org-node glass corner top card-hover";
    if (o.direct) return "org-node glass corner direct card-hover";
    return "org-node glass corner card-hover";
  }

  function nodeHTML(o, delay) {
    const n = orgMembers(o).length;
    const lead = orgLeader(o);
    return `<button class="${nodeClass(o)}" data-id="${o.id}"
       style="border:1px solid ${o.top ? "var(--line-strong)" : "var(--line)"};font-family:inherit;cursor:pointer;animation-delay:${delay}ms">
      <h3>${esc(o.name)}</h3>
      <p>${esc(o.type)} · 在册 ${n} 人</p>
      ${lead ? `<p style="font-size:11.5px;color:var(--gold);margin-top:3px;letter-spacing:1px">最高领导 · ${esc(lead.name)} <span class="mono" style="color:var(--faint)">${lead.id}</span></p>` : ""}
    </button>`;
  }

  const hq = byId("HQ");
  const directsAndProv = ["PROV", "ZYS", "FLY", "XYS"].map(byId);
  const city = byId("CITY");
  const station = byId("STATION");

  tree.innerHTML = `
    ${nodeHTML(hq, 0)}
    <div class="org-connector"></div>
    <div class="org-branch">
      ${directsAndProv.map((o, i) => nodeHTML(o, 100 + i * 80)).join("")}
    </div>
    <div class="org-connector"></div>
    <div style="display:flex;flex-direction:column;align-items:center">
      <small style="color:var(--faint);letter-spacing:2px;font-size:11px;margin-bottom:10px">省级以下 · 垂直管理体系</small>
      ${nodeHTML(city, 420)}
      <div class="org-connector"></div>
      ${nodeHTML(station, 500)}
    </div>
  `;

  function showDetail(id) {
    const o = byId(id);
    tree.querySelectorAll(".org-node").forEach(n => {
      const on = n.dataset.id === id;
      n.style.borderColor = on ? "var(--cyan)" : "";
      n.style.boxShadow = on ? "0 0 26px rgba(46,230,255,.25)" : "";
    });
    detail.style.animation = "none";
    void detail.offsetWidth;
    detail.style.animation = "fadeUp .4s both";
    const members = orgMembers(o);
    const lead = orgLeader(o);
    detail.innerHTML = `
      <h3>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 21v-6h6v6"/></svg>
        ${esc(o.name)}
        <span class="badge" style="color:var(--muted);margin-left:8px"><span class="dot"></span>${esc(o.type)}</span>
      </h3>
      ${lead ? `
      <a href="profile-detail.html?id=${lead.id}" style="display:flex;align-items:center;gap:12px;margin:14px 0;padding:12px 14px;border:1px solid rgba(255,196,82,.35);border-radius:10px;text-decoration:none;background:rgba(255,196,82,.06)">
        <div style="width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--gold),#c98a2b);color:#15121b;font-weight:800;font-size:15px">${esc(lead.name[0])}</div>
        <div>
          <div style="font-size:11px;color:var(--gold);letter-spacing:2px">最高领导</div>
          <b style="color:var(--text-bright);font-size:14px">${esc(lead.name)}</b>
          <span class="mono" style="font-size:11px;color:var(--faint);margin-left:6px">${lead.id}</span>
        </div>
        <span style="margin-left:auto">${badge(rankCls(lead.rankIdx), D.RANKS[lead.rankIdx].name)}</span>
      </a>` : ""}
      <div class="od-grid">
        <div class="od-item">
          <div class="k">核心职能</div>
          <div class="v">${esc(o.func)}</div>
        </div>
        <div class="od-item">
          <div class="k">下辖单位</div>
          <div class="v">${esc(o.units)}</div>
        </div>
      </div>
      <div class="od-item" style="margin-top:14px">
        <div class="k">在册御鬼者（${members.length} 人 · 按品级排序）</div>
        <div style="margin-top:10px;display:flex;flex-direction:column;gap:8px">
          ${members.length ? members.map(p => `
            <a href="profile-detail.html?id=${p.id}" style="display:flex;align-items:center;gap:10px;padding:9px 12px;border:1px solid rgba(116,136,155,.18);border-radius:8px;text-decoration:none">
              <b style="color:var(--text-bright);font-size:13px">${esc(p.name)}</b>
              <span class="mono" style="font-size:11px;color:var(--faint)">${p.id}</span>
              ${badge(rankCls(p.rankIdx), D.RANKS[p.rankIdx].name)}
              <span style="margin-left:auto">${badge(statusCls(p.status), p.status)}</span>
            </a>`).join("")
          : `<p style="font-size:12.5px;color:var(--faint)">该机构在册人员编制保密或未公开</p>`}
        </div>
      </div>
    `;
  }

  tree.addEventListener("click", e => {
    const node = e.target.closest(".org-node");
    if (node) showDetail(node.dataset.id);
  });

  showDetail("HQ");
})();

/* 御鬼者详情 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { qs, esc, rankCls, statusCls, badge, ghostLevelCls, missionCls, seededRand, Profiles, TaskState, GameState, Officials, icon } = window.YG;

  const p = Profiles.find(qs("id"));
  const viewer = Profiles.current();
  const box = document.getElementById("detail");

  document.getElementById("backBtn").addEventListener("click", () => {
    if (history.length > 1) history.back();
    else location.href = "profiles.html";
  });

  if (!p) {
    box.innerHTML = `<div class="glass empty" style="border-radius:14px">未找到该御鬼者档案 <a href="profiles.html" class="text-cyan" style="margin-left:10px">返回列表</a></div>`;
    return;
  }

  const rank = D.RANKS[p.rankIdx];
  document.title = p.name + " · 御鬼者档案 · 全国御鬼者管控系统";

  /* ---------- 档案监察权限：权限不足者仅可见基础公开信息 ---------- */
  const canView = viewer && Officials.canViewDetail(viewer.id, p.id);
  if (!canView) {
    const myClear = Officials.clearance(viewer.id);
    box.innerHTML = `
      <div class="glass corner" style="padding:26px 28px;margin-bottom:18px">
        <div class="profile-hero">
          <div class="big-avatar">${esc(p.name.slice(0, 1))}</div>
          <div style="flex:1;min-width:220px">
            <h2 style="font-size:24px;color:var(--text-bright);letter-spacing:4px;display:flex;gap:12px;align-items:center;flex-wrap:wrap">
              ${esc(p.name)} ${badge(rankCls(p.rankIdx), rank.name)} ${badge(statusCls(p.status), p.status)}
            </h2>
            <div class="profile-meta line" style="margin-top:10px">
              <span>编号 <b class="mono">${p.id}</b></span>
              <span>所属 <b>${esc(p.bureau)}</b></span>
            </div>
          </div>
        </div>
      </div>
      <div class="glass corner" style="padding:44px 30px;text-align:center">
        <div style="color:var(--red);margin-bottom:14px">${icon("alarm")}</div>
        <h3 style="letter-spacing:3px;color:var(--red)">详细档案 · 权限不足</h3>
        <p style="margin-top:14px;color:var(--muted);font-size:13.5px;line-height:2">
          「${esc(p.name)}」为 <b style="color:var(--gold)">${esc(rank.name)}</b>（${p.rankIdx} 品序列），其侵蚀曲线、契约鬼灵、任务战绩与晋升记录属加密档案。<br>
          你的档案监察权限为 <b class="mono text-cyan">${myClear} 级</b>（品级 + 官职加成），需达到 <b class="mono" style="color:var(--red)">${p.rankIdx} 级</b> 方可调阅。<br>
          <span style="font-size:12.5px;color:var(--faint)">提升品级或就任更高官职可获得更多档案监察权限</span>
        </p>
      </div>`;
    return;
  }

  /* ---------- 侵蚀度曲线（近12个月，确定性生成） ---------- */
  function erosionSeries() {
    const rnd = seededRand(p.id + "_erosion");
    const arr = [];
    let v = Math.max(3, p.erosion - 14 - rnd() * 8);
    for (let i = 0; i < 11; i++) {
      v += (rnd() - 0.42) * 7;
      v = Math.max(2, Math.min(96, v));
      arr.push(Math.round(v));
    }
    arr.push(p.erosion);
    return arr;
  }

  function buildChart(data) {
    const W = 620, H = 230, padL = 38, padR = 16, padT = 18, padB = 30;
    const x = i => padL + i * ((W - padL - padR) / (data.length - 1));
    const y = v => padT + (100 - v) * ((H - padT - padB) / 100);
    const line = data.map((v, i) => `${x(i)},${y(v)}`).join(" ");
    const area = `${padL},${H - padB} ${line} ${x(data.length - 1)},${H - padB}`;

    const now = new Date();
    const labels = data.map((_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth() - (11 - i), 1);
      return (d.getMonth() + 1) + "月";
    });

    const grids = [0, 25, 50, 75, 100].map(v => `
      <line x1="${padL}" y1="${y(v)}" x2="${W - padR}" y2="${y(v)}" stroke="rgba(116,136,155,.14)" stroke-dasharray="3 4"/>
      <text x="${padL - 8}" y="${y(v) + 4}" text-anchor="end" fill="#4c5d6e" font-size="10" font-family="monospace">${v}</text>
    `).join("");

    const points = data.map((v, i) => {
      const color = v > 80 ? "#ff3b5c" : v >= 60 ? "#ffc24b" : "#2ee6ff";
      const big = i === data.length - 1;
      return `<circle cx="${x(i)}" cy="${y(v)}" r="${big ? 5 : 3}" fill="${color}" ${big ? `style="filter:drop-shadow(0 0 6px ${color})"` : ""}/>`;
    }).join("");

    const xLabels = labels.map((t, i) =>
      `<text x="${x(i)}" y="${H - 9}" text-anchor="middle" fill="#4c5d6e" font-size="10">${t}</text>`).join("");

    return `
      <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="height:240px">
        <defs>
          <linearGradient id="areaG" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#2ee6ff" stop-opacity=".35"/>
            <stop offset="1" stop-color="#2ee6ff" stop-opacity="0"/>
          </linearGradient>
        </defs>
        ${grids}
        <polygon points="${area}" fill="url(#areaG)"/>
        <polyline points="${line}" fill="none" stroke="#2ee6ff" stroke-width="2.2"
          stroke-linecap="round" stroke-linejoin="round"
          style="filter:drop-shadow(0 0 5px rgba(46,230,255,.6));stroke-dasharray:1200;stroke-dashoffset:1200;animation:drawline 1.6s ease forwards"/>
        ${points}
        ${xLabels}
      </svg>
      <style>@keyframes drawline{to{stroke-dashoffset:0}}</style>
    `;
  }

  /* ---------- 任务战绩（个人存储 + 档案确定性补全） ---------- */
  function missionRecords() {
    const recs = [];
    const mine = TaskState.all(p.id);
    Object.keys(mine).forEach(mid => {
      const m = D.MISSIONS.find(x => x.id === mid);
      if (m && mine[mid].status === "已完成") {
        recs.push({ m, rating: mine[mid].rating || "B", date: mine[mid].date || "—", real: true });
      }
    });
    if (recs.length < 5 && p.missionsDone > 0) {
      const rnd = seededRand(p.id + "_missions");
      const pool = D.MISSIONS.filter(m => {
        const order = { D: 0, C: 1, B: 2, A: 3, S: 4, SS: 5 }[m.level];
        return order <= Math.min(p.rankIdx + 1, 5);
      });
      const need = Math.min(5 - recs.length, p.missionsDone, pool.length);
      const used = new Set(recs.map(r => r.m.id));
      const shuffled = pool.slice().sort(() => rnd() - 0.5);
      let picked = 0;
      for (const m of shuffled) {
        if (picked >= need || used.has(m.id)) continue;
        picked++;
        const d = new Date();
        d.setDate(d.getDate() - Math.floor(rnd() * 180) - 3);
        const ratings = ["S", "A", "A", "B"];
        recs.push({
          m, rating: ratings[Math.floor(rnd() * ratings.length)],
          date: d.toISOString().slice(0, 10), real: false
        });
      }
    }
    return recs.sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);
  }

  const eroCls = p.erosion > 80 ? "danger" : p.erosion >= 60 ? "warn" : "";
  const recs = missionRecords();
  const chain = GameState.superiorChain(p.id);
  const superior = chain[0];
  // 契约鬼灵：以仓库为唯一数据源（种子 ghostIds 首次访问时自动迁移入仓）
  const myGhostList = window.YG.MyGhosts.all(p.id).list;

  box.innerHTML = `
    <!-- 头部 -->
    <div class="glass corner" style="padding:26px 28px;margin-bottom:18px">
      <div class="profile-hero">
        <div class="big-avatar">${esc(p.name.slice(0, 1))}</div>
        <div style="flex:1;min-width:220px">
          <h2 style="font-size:24px;color:var(--text-bright);letter-spacing:4px;display:flex;gap:12px;align-items:center;flex-wrap:wrap">
            ${esc(p.name)} ${badge(rankCls(p.rankIdx), rank.name)} ${badge(statusCls(p.status), p.status)}
          </h2>
          <div class="profile-meta line" style="margin-top:10px">
            <span>编号 <b class="mono">${p.id}</b></span>
            <span>所属 <b>${esc(p.bureau)}</b></span>
            <span>备案日期 <b class="mono">${p.joinDate}</b></span>
          </div>
        </div>
        <div class="erosion ${eroCls}" style="min-width:220px;max-width:300px">
          <div class="erosion-head"><span>当前侵蚀度</span><b class="mono">${p.erosion}%</b></div>
          <div class="bar ${eroCls}"><i style="width:${p.erosion}%"></i></div>
        </div>
      </div>
    </div>

    <div class="section-title">基础信息</div>
    <div class="kv-grid">
      <div class="glass kv"><div class="k">契约鬼上限</div><div class="v">${rank.ghostLimit}</div></div>
      <div class="glass kv"><div class="k">权限范围</div><div class="v" style="font-size:13.5px">${esc(rank.scope)}</div></div>
      <div class="glass kv"><div class="k">累计完成任务</div><div class="v mono">${GameState.missionsTotal(p.id)} <small style="color:var(--faint);font-size:11px">起</small></div></div>
      <div class="glass kv"><div class="k">当前积分</div><div class="v mono" style="color:var(--amber)">${GameState.points(p.id)}</div></div>
      <div class="glass kv"><div class="k">冥币余额</div><div class="v mono" style="color:var(--gold)">${window.YG.Coins.get(p.id)}</div></div>
      <div class="glass kv"><div class="k">官职</div><div class="v" style="color:var(--gold)">${(window.YG.Officials.of(p.id) || {}).name || "白身"}</div></div>
      <div class="glass kv"><div class="k">任务综合评级</div><div class="v" style="color:var(--gold)">${p.rating}</div></div>
      <div class="glass kv"><div class="k">晋升核心条件</div><div class="v" style="font-size:13.5px">${esc(rank.cond)}</div></div>
    </div>

    <div class="section-title">直属上级</div>
    <div class="glass" style="padding:20px 22px">
      ${superior
        ? `<div style="display:flex;align-items:center;gap:12px">
            <a href="profile-detail.html?id=${superior.id}" style="display:flex;align-items:center;gap:12px">
              <div class="big-avatar" style="width:42px;height:42px;font-size:16px">${esc(superior.name.slice(0,1))}</div>
              <div>
                <b style="color:var(--text-bright)">${esc(superior.name)}</b>
                <div style="font-size:12px;color:var(--muted)">${esc(superior.id)} · ${esc(D.RANKS[superior.rankIdx].name)} · ${esc(superior.bureau)}</div>
              </div>
            </a>
          </div>`
        : `<span class="text-muted" style="font-size:13.5px">无直属上级 · 天御级或独立编制</span>`}
      ${chain.length > 1 ? `<div style="margin-top:14px;padding-top:14px;border-top:1px solid var(--line)">
        <div style="font-size:12px;color:var(--muted);margin-bottom:8px">汇报链</div>
        <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center">
          <a href="profile-detail.html?id=${p.id}" class="badge ${rankCls(p.rankIdx)}" style="text-decoration:none">${esc(p.name)}</a>
          ${chain.map(s => `<span style="color:var(--faint)">→</span><a href="profile-detail.html?id=${s.id}" class="badge ${rankCls(s.rankIdx)}" style="text-decoration:none">${esc(s.name)}</a>`).join("")}
        </div>
      </div>` : ""}
    </div>

    <div class="section-title">侵蚀度历史（近 12 个月）</div>
    <div class="glass chart-card">${buildChart(erosionSeries())}</div>

    <div class="section-title">契约鬼灵列表</div>
    <div class="glass" style="padding:20px 22px">
      ${
        myGhostList.length
          ? myGhostList.map(mg => {
              const g = D.GHOSTS.find(x => x.id === mg.gid);
              if (!g) return "";
              const hungry = mg.hunger <= 20;
              return `<a class="ghost-chip ${ghostLevelCls(g.level)}" href="ghost-detail.html?id=${g.id}" style="${hungry ? 'border-color:var(--red);opacity:.85' : ''}">
                <small class="mono">${g.id}</small>${esc(g.name)}${hungry ? ' · 饥饿' : ''}<small>${g.level}</small></a>`;
            }).join("")
          : `<span class="text-muted" style="font-size:13.5px">暂无契约鬼灵 · 完成任务时有概率触发「机缘 · 鬼怪现身」契约事件</span>`
      }
      ${p.id === qs("id") && window.YG.Session.get() === p.id
        ? `<a href="ghosts-mine.html" class="text-cyan" style="display:block;margin-top:12px;font-size:12.5px">前往鬼灵仓库管理 →</a>` : ""}
    </div>

    <div class="section-title">任务战绩 · 历史任务记录</div>
    <div class="glass table-wrap">
      <table class="data">
        <thead><tr><th class="mono">任务编号</th><th>任务名称</th><th>等级</th><th>地点</th><th>完成日期</th><th>评级</th></tr></thead>
        <tbody>
          ${
            recs.length
              ? recs.map(r => `
                <tr onclick="location.href='tasks.html'" style="cursor:pointer">
                  <td class="mono">${r.m.id}</td>
                  <td>${esc(r.m.name)}</td>
                  <td>${badge(missionCls(r.m.level), r.m.level)}</td>
                  <td style="color:var(--muted)">${esc(r.m.place)}</td>
                  <td class="mono" style="color:var(--muted)">${r.date}</td>
                  <td style="color:var(--gold);font-weight:700">${r.rating}${r.real ? '<small style="color:var(--green);margin-left:6px;font-size:10px">本人</small>' : ""}</td>
                </tr>`).join("")
              : `<tr><td colspan="6" class="empty" style="display:block;padding:40px">暂无历史任务记录，可前往<a href="tasks.html" class="text-cyan" style="margin:0 5px">任务大厅</a>接取任务</td></tr>`
          }
        </tbody>
      </table>
    </div>

    <div class="section-title">晋升 / 奖惩记录</div>
    <div class="glass" style="padding:22px 26px">
      <ul class="timeline">
        ${p.promotions.map(r => `
          <li>
            <b><span class="t-date mono">${esc(r.date)}</span>${esc(r.title)}</b>
            <p>${esc(r.note)}</p>
          </li>`).join("")}
      </ul>
    </div>
  `;
})();

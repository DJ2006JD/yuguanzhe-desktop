/* 灾难预警 · 全国态势地图（球体网格背景 + 全国城市节点网络） */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { esc, badge, ghostLevelCls, missionCls, seededRand, FeatureLock, Disaster } = window.YG;

  const me = window.YG.Profiles.current();
  if (!me) return;
  if (!FeatureLock.guardPage("disaster", "灾难预警")) return;

  const ZONES = D.NATION_ZONES;
  const lvInfo = lv => Disaster.info(lv);

  const svg = document.getElementById("threatMap");
  const detailEl = document.getElementById("zoneDetail");
  const legendEl = document.getElementById("mapLegend");
  const clockEl = document.getElementById("mapClock");
  let selectedId = null;

  /* ---------- 球体背景层（参考图①：旋转线框地球，作为底层装饰，一次性构建） ---------- */
  const CX = 430, CY = 300, R = 285;
  function buildGlobe() {
    const lats = [
      { dy: -205, rx: 198, ry: 14 }, { dy: -136, rx: 251, ry: 20 }, { dy: -68, rx: 277, ry: 25 },
      { dy: 0, rx: 285, ry: 29 },
      { dy: 68, rx: 277, ry: 25 }, { dy: 136, rx: 251, ry: 20 }, { dy: 205, rx: 198, ry: 14 }
    ];
    // 经线（SMIL 驱动 rx 往复，模拟球体自转）
    const meridians = [0, -4, -8, -12].map(b =>
      `<ellipse cx="${CX}" cy="${CY}" rx="20" ry="${R - 4}" fill="none" stroke="rgba(94,224,255,.10)" stroke-width="1">
        <animate attributeName="rx" values="18;${R - 6};18" dur="16s" begin="${b}s" repeatCount="indefinite"/>
      </ellipse>`).join("");
    // 轨道卫星光点（参考图①外围轨道装饰）
    const orbiters = [0, 2.7, 5.4].map((b, i) =>
      `<circle r="2.4" fill="rgba(125,240,255,.8)">
        <animateMotion dur="9s" begin="-${b}s" repeatCount="indefinite"
          path="M ${CX - (R + 38)} ${CY} a ${R + 38} ${(R + 38) * 0.32} 0 1 0 ${(R + 38) * 2} 0 a ${R + 38} ${(R + 38) * 0.32} 0 1 0 -${(R + 38) * 2} 0"/>
      </circle>`).join("");
    svg.innerHTML = `
      <defs>
        <radialGradient id="sphereBg" cx="42%" cy="36%" r="78%">
          <stop offset="0%" stop-color="rgba(24,58,86,.92)"/>
          <stop offset="55%" stop-color="rgba(9,20,33,.94)"/>
          <stop offset="100%" stop-color="rgba(4,8,15,.97)"/>
        </radialGradient>
        <radialGradient id="atmos" cx="50%" cy="50%" r="50%">
          <stop offset="86%" stop-color="rgba(46,230,255,0)"/>
          <stop offset="94%" stop-color="rgba(46,230,255,.11)"/>
          <stop offset="100%" stop-color="rgba(46,230,255,0)"/>
        </radialGradient>
        <clipPath id="sphereClip"><circle cx="${CX}" cy="${CY}" r="${R}"/></clipPath>
      </defs>
      <circle cx="${CX}" cy="${CY}" r="${R + 26}" fill="url(#atmos)"/>
      <g transform="rotate(-8 ${CX} ${CY})">
        <ellipse cx="${CX}" cy="${CY}" rx="${R + 38}" ry="${(R + 38) * 0.32}" fill="none"
          stroke="rgba(46,230,255,.16)" stroke-width="1" stroke-dasharray="2 10"/>
        ${orbiters}
      </g>
      <circle cx="${CX}" cy="${CY}" r="${R}" fill="url(#sphereBg)" stroke="rgba(94,224,255,.28)" stroke-width="1.2"/>
      <g clip-path="url(#sphereClip)" opacity=".55">
        ${lats.map(l => `<ellipse cx="${CX}" cy="${CY + l.dy}" rx="${l.rx}" ry="${l.ry}" fill="none" stroke="rgba(94,224,255,${l.dy === 0 ? ".3" : ".12"})" stroke-width="${l.dy === 0 ? 1.2 : 1}"/>`).join("")}
        ${meridians}
      </g>
      <circle cx="${CX - 92}" cy="${CY - 114}" r="150" fill="rgba(125,240,255,.04)"/>
      <text x="${CX}" y="34" text-anchor="middle" fill="rgba(125,240,255,.38)" font-size="11" letter-spacing="6" font-family="monospace">NATIONAL THREAT MONITORING NETWORK</text>
      <g id="linkLayer"></g>
      <g id="zoneLayer"></g>`;
  }

  /* ---------- 网络连线（参考图②：节点与邻近城市连成监测网络） ---------- */
  const LINKS = (function () {
    const links = [];
    ZONES.forEach((a, i) => {
      const near = ZONES.map((b, j) => ({ j, d: Math.hypot(a.x - b.x, a.y - b.y) }))
        .filter(o => o.j !== i).sort((p, q) => p.d - q.d);
      near.slice(0, 2).forEach(o => {
        const key = Math.min(i, o.j) + "-" + Math.max(i, o.j);
        if (!links.some(l => l.key === key)) links.push({ key, a, b: ZONES[o.j] });
      });
    });
    return links;
  })();

  /* ---------- 节点网络层渲染（每 8 秒重算等级） ---------- */
  function renderMap() {
    const linkLayer = document.getElementById("linkLayer");
    const zoneLayer = document.getElementById("zoneLayer");
    const lvMap = {};
    ZONES.forEach(z => { lvMap[z.id] = Disaster.level(z); });

    // 连线：两端任一城市高威胁时染色，否则淡青色
    let linkHtml = "";
    LINKS.forEach(l => {
      const la = lvMap[l.a.id], lb = lvMap[l.b.id];
      const hot = Math.max(la, lb);
      const color = hot >= 3 ? lvInfo(hot).color : "#2ee6ff";
      const op = hot >= 3 ? 0.3 : 0.1;
      linkHtml += `<line x1="${l.a.x}" y1="${l.a.y}" x2="${l.b.x}" y2="${l.b.y}"
        stroke="${color}" stroke-opacity="${op}" stroke-width="1" stroke-dasharray="3 5"/>`;
      // 高威胁链路数据脉冲（光点沿线移动）
      if (hot >= 3) {
        linkHtml += `<circle r="2" fill="${color}" opacity=".85">
          <animateMotion dur="${(3 + (l.key.length % 3))}s" repeatCount="indefinite"
            path="M ${l.a.x} ${l.a.y} L ${l.b.x} ${l.b.y}"/>
        </circle>`;
      }
    });
    linkLayer.innerHTML = linkHtml;

    // 城市节点
    let inner = "";
    ZONES.forEach(z => {
      const lv = lvMap[z.id];
      const info = lvInfo(lv);
      const sel = z.id === selectedId;
      const r = lv >= 5 ? 6.5 : lv >= 3 ? 5 : lv === 0 ? 3 : 4;
      const labelOp = lv === 0 ? ".5" : ".9";
      inner += `<g class="city-node" data-zone="${z.id}" style="cursor:pointer">`;
      // 高威胁脉冲扩散环
      if (lv >= 3) {
        inner += `<circle cx="${z.x}" cy="${z.y}" r="${r}" fill="none" stroke="${info.color}" stroke-width="1">
            <animate attributeName="r" values="${r};${r + 16}" dur="2s" repeatCount="indefinite"/>
            <animate attributeName="opacity" values=".65;0" dur="2s" repeatCount="indefinite"/>
          </circle>`;
      }
      // 选中准星
      if (sel) {
        inner += `<circle cx="${z.x}" cy="${z.y}" r="${r + 9}" fill="none" stroke="${info.color}" stroke-width="1.2" stroke-dasharray="4 4"/>
          <line x1="${z.x - r - 16}" y1="${z.y}" x2="${z.x - r - 6}" y2="${z.y}" stroke="${info.color}" stroke-width="1"/>
          <line x1="${z.x + r + 6}" y1="${z.y}" x2="${z.x + r + 16}" y2="${z.y}" stroke="${info.color}" stroke-width="1"/>
          <line x1="${z.x}" y1="${z.y - r - 16}" x2="${z.x}" y2="${z.y - r - 6}" stroke="${info.color}" stroke-width="1"/>
          <line x1="${z.x}" y1="${z.y + r + 6}" x2="${z.x}" y2="${z.y + r + 16}" stroke="${info.color}" stroke-width="1"/>`;
      }
      // 光晕 + 核心
      inner += `<circle cx="${z.x}" cy="${z.y}" r="${r + 4}" fill="${info.color}" opacity="${lv === 0 ? ".08" : ".18"}"/>
        <circle cx="${z.x}" cy="${z.y}" r="${r}" fill="${info.color}"
          style="filter:drop-shadow(0 0 ${lv >= 3 ? 9 : 5}px ${info.color})"/>
        <text x="${z.x}" y="${z.y + r + 13}" text-anchor="middle" font-size="10" letter-spacing="1"
          fill="${info.color}" opacity="${labelOp}">${z.name}</text>`;
      // 高威胁等级文字标记
      if (lv >= 3) {
        inner += `<text x="${z.x}" y="${z.y - r - 7}" text-anchor="middle" font-size="9.5" font-weight="700"
          fill="${info.color}" font-family="monospace" style="text-shadow:0 0 6px ${info.color}">${info.level}</text>`;
      }
      inner += `</g>`;
    });
    zoneLayer.innerHTML = inner;

    clockEl.textContent = "SYNC " + new Date().toLocaleTimeString("zh-CN", { hour12: false });
  }

  /* ---------- 图例 ---------- */
  legendEl.innerHTML = [`<span class="legend-chip"><i style="background:${Disaster.SAFE.color}"></i>安全</span>`]
    .concat(D.DISASTERS.map(d => `<span class="legend-chip"><i style="background:${d.color}"></i>${d.level} · ${esc(d.power)}</span>`)).join("");

  /* ---------- 关键词无命中时的兜底：按灾情等级确定性生成疑似鬼情/可调度任务（30 分钟桶） ---------- */
  function fallbackThreats(z, lv) {
    const bucket = Math.floor(Date.now() / 1800000);
    const out = { ghosts: [], missions: [] };
    if (lv < 1) return out;
    // 疑似鬼情：等阶与灾情匹配（灾情 lv 对应鬼怪等阶 lv+1 ±1）
    const gpool = D.GHOSTS.filter(g => {
      const order = (D.GHOST_LEVELS.find(l => l.name === g.level) || {}).order || 1;
      return Math.abs(order - (lv + 1)) <= 1 && !/封印|沉睡|镇压/.test(g.status);
    });
    const gUsed = new Set();
    for (let i = 0; i < Math.min(lv, 3) && gUsed.size < gpool.length; i++) {
      const idx = Math.floor(seededRand("zg_" + z.id + "_" + bucket + "_" + i)() * gpool.length);
      if (!gUsed.has(idx)) { gUsed.add(idx); out.ghosts.push(gpool[idx]); }
    }
    // 可调度任务：待领取任务中按灾情等级匹配的难度抽取
    const mLv = Disaster.missionLevelsFor(lv);
    const mpool = D.MISSIONS.filter(m => m.status === "待领取" && mLv.includes(m.level));
    const mUsed = new Set();
    for (let i = 0; i < Math.min(Math.max(1, lv - 1), 2) && mUsed.size < mpool.length; i++) {
      const idx = Math.floor(seededRand("zm_" + z.id + "_" + bucket + "_" + i)() * mpool.length);
      if (!mUsed.has(idx)) { mUsed.add(idx); out.missions.push(mpool[idx]); }
    }
    return out;
  }

  /* ---------- 详情面板 ---------- */
  function renderDetail() {
    if (!selectedId) {
      const counts = Disaster.counts();
      const worst = Disaster.worst();
      const worstInfo = lvInfo(worst.lv);
      const danger = ZONES.filter(z => Disaster.level(z) >= 3).length;
      detailEl.innerHTML = `
        <h3 style="letter-spacing:3px;color:var(--cyan)">全国态势概览</h3>
        <p style="color:var(--muted);font-size:12.5px;margin-top:8px;line-height:1.8">
          全国阴能监测网覆盖 ${ZONES.length} 个重点城市节点，每 30 秒同步一次。<br>节点颜色实时反映灾情等级，点击节点查看该城市灾情详情。
        </p>
        <div style="margin-top:18px;display:grid;grid-template-columns:repeat(2,1fr);gap:10px">
          ${[Disaster.SAFE].concat(D.DISASTERS).map((d, i) => `
            <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border:1px solid rgba(116,136,155,.18);border-radius:8px">
              <i style="width:10px;height:10px;border-radius:2px;background:${d.color};box-shadow:0 0 8px ${d.color}"></i>
              <span style="font-size:12.5px;color:var(--text)">${d.level}</span>
              <b class="mono" style="margin-left:auto;color:${d.color}">${counts[i]} 城</b>
            </div>`).join("")}
        </div>
        <div style="margin-top:14px;display:flex;gap:10px">
          <div style="flex:1;padding:12px 14px;border:1px solid rgba(116,136,155,.18);border-radius:10px;text-align:center">
            <div class="mono" style="font-size:20px;color:var(--cyan)">${ZONES.length}</div>
            <small style="color:var(--muted);letter-spacing:2px">监测节点</small>
          </div>
          <div style="flex:1;padding:12px 14px;border:1px solid rgba(255,148,66,.3);border-radius:10px;text-align:center">
            <div class="mono" style="font-size:20px;color:var(--amber)">${danger}</div>
            <small style="color:var(--muted);letter-spacing:2px">橙灾以上城市</small>
          </div>
        </div>
        <div style="margin-top:14px;padding:14px 16px;border:1px solid ${worstInfo.color}44;border-radius:10px;background:${worstInfo.color}0d">
          <small style="color:var(--muted);letter-spacing:2px">当前最高威胁城市</small>
          <div style="margin-top:6px;font-size:16px;font-weight:700;color:${worstInfo.color}">${esc(worst.zone.name)} · ${worstInfo.level}</div>
          <div style="margin-top:6px;font-size:12.5px;color:var(--muted)">响应：${esc(worstInfo.plan)}</div>
        </div>`;
      return;
    }

    const z = ZONES.find(x => x.id === selectedId);
    const lv = Disaster.level(z);
    const info = lvInfo(lv);
    const energy = Disaster.energy(z, lv);
    const matched = Disaster.threats(z);
    const fb = fallbackThreats(z, lv);
    // 关键词命中优先；无命中时用兜底疑似数据填充，避免空面板
    const ghosts = matched.ghosts.length ? matched.ghosts : fb.ghosts;
    const missions = matched.missions.length ? matched.missions : fb.missions;
    const ghostTitle = matched.ghosts.length ? "区域内活跃鬼怪" : (ghosts.length ? "疑似鬼情活动 · 待核实" : "区域内活跃鬼怪");
    const missionTitle = matched.missions.length ? "区域关联任务" : (missions.length ? "邻近可调度任务" : "区域关联任务");
    const trend = Disaster.trend(z, lv);
    const trendColor = trend === "上升" ? "var(--red)" : trend === "下降" ? "var(--green)" : "var(--cyan)";

    detailEl.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
        <h3 style="letter-spacing:3px">${esc(z.name)}</h3>
        <span class="badge" style="border-color:${info.color};color:${info.color}"><span class="dot" style="background:${info.color};box-shadow:0 0 6px ${info.color}"></span>${info.level}</span>
      </div>
      <div style="display:flex;gap:18px;margin-top:14px;flex-wrap:wrap">
        <div><small style="color:var(--muted)">阴能指数</small><div class="mono" style="font-size:20px;color:${info.color};margin-top:2px">${energy}</div></div>
        <div><small style="color:var(--muted)">趋势</small><div style="font-size:15px;color:${trendColor};margin-top:4px">${trend}</div></div>
        <div><small style="color:var(--muted)">影响范围</small><div style="font-size:13px;color:var(--text);margin-top:4px">${esc(info.range || "片区")}</div></div>
      </div>
      <div style="margin-top:16px">
        <small style="color:var(--muted);letter-spacing:2px">响应预案</small>
        <p style="margin-top:6px;font-size:13px;color:var(--text);line-height:1.8">${esc(info.plan)}${lv >= 4 ? `<br><b style="color:${info.color}">高威胁：建议立即调度高品级御鬼者前往处置</b>` : ""}</p>
      </div>
      <div style="margin-top:16px">
        <small style="color:var(--muted);letter-spacing:2px">${ghostTitle}</small>
        ${ghosts.length ? ghosts.map(g => `
          <a href="ghost-detail.html?id=${g.id}" style="display:flex;align-items:center;gap:10px;margin-top:8px;padding:9px 12px;border:1px solid rgba(116,136,155,.18);border-radius:8px;text-decoration:none">
            <b style="color:var(--text-bright);font-size:13px">${esc(g.name)}</b>
            ${badge(ghostLevelCls(g.level), g.level)}
            <span style="margin-left:auto;font-size:11.5px;color:var(--muted)">${esc(g.status)}</span>
          </a>`).join("")
        : `<p style="margin-top:8px;font-size:12.5px;color:var(--green)">巡逻队驻守中 · 暂无异常上报</p>`}
      </div>
      <div style="margin-top:16px">
        <small style="color:var(--muted);letter-spacing:2px">${missionTitle}</small>
        ${missions.length ? missions.map(m => `
          <a href="tasks.html" style="display:flex;align-items:center;gap:10px;margin-top:8px;padding:9px 12px;border:1px solid rgba(116,136,155,.18);border-radius:8px;text-decoration:none">
            ${badge(missionCls(m.level), m.level)}
            <b style="color:var(--text-bright);font-size:13px">${esc(m.name)}</b>
            <span class="mono" style="margin-left:auto;font-size:11px;color:var(--muted)">${m.id}</span>
          </a>`).join("")
        : `<p style="margin-top:8px;font-size:12.5px;color:var(--green)">暂无待处置任务 · 区域稳定</p>`}
      </div>`;
  }

  svg.addEventListener("click", e => {
    const g = e.target.closest(".city-node");
    if (!g) return;
    selectedId = g.dataset.zone === selectedId ? null : g.dataset.zone;
    renderMap();
    renderDetail();
  });

  buildGlobe();
  renderMap();
  renderDetail();
  // 实时刷新：节点层与详情每 8 秒重算（等级按 30 秒桶变化），时钟每秒走；球体层不重建避免打断自转
  setInterval(() => { renderMap(); renderDetail(); }, 8000);
  setInterval(() => { clockEl.textContent = "SYNC " + new Date().toLocaleTimeString("zh-CN", { hour12: false }); }, 1000);
})();

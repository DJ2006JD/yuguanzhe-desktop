/* 登录页交互 */
(function () {
  "use strict";
  const { Users, Session, icon } = window.YG;

  document.getElementById("authLogo").innerHTML = icon("logo");

  /* ---------- 打字机副标题（循环） ---------- */
  const phrases = [
    "NATIONAL GHOST CONTROL AUTHORITY",
    "机密接入终端 · 未经授权禁止访问",
    "阴隙监测网络 · 全天候在线"
  ];
  const tw = document.getElementById("typewriter");
  let pi = 0, ci = 0, deleting = false;

  function typeLoop() {
    const full = phrases[pi];
    if (!deleting) {
      tw.textContent = full.slice(0, ++ci);
      if (ci === full.length) { deleting = true; setTimeout(typeLoop, 1800); return; }
    } else {
      tw.textContent = full.slice(0, --ci);
      if (ci === 0) { deleting = false; pi = (pi + 1) % phrases.length; }
    }
    setTimeout(typeLoop, deleting ? 35 : 90);
  }
  typeLoop();

  /* ---------- 表单校验 ---------- */
  const form = document.getElementById("loginForm");
  const idInput = document.getElementById("userId");
  const pwInput = document.getElementById("password");
  const btn = document.getElementById("loginBtn");
  const errBox = document.getElementById("formError");

  function syncBtn() {
    btn.disabled = !(idInput.value.trim() && pwInput.value);
  }
  [idInput, pwInput].forEach(inp => {
    inp.addEventListener("input", () => {
      inp.classList.remove("err");
      errBox.textContent = "";
      form.classList.remove("shake");
      syncBtn();
    });
  });

  // 权限守卫跳回提示
  const urlErr = new URLSearchParams(location.search).get("err");
  if (urlErr === "auth") {
    errBox.textContent = "登录态已失效或越权访问，请重新核验身份";
    errBox.style.color = "var(--amber)";
  } else if (urlErr === "dead") {
    errBox.textContent = "该御鬼者侵蚀度突破 90% 已殉职，账号注销。请重新登记备案";
    errBox.style.color = "var(--red)";
  }

  function fail(msg) {
    errBox.textContent = msg;
    [idInput, pwInput].forEach(i => i.classList.add("err"));
    form.classList.remove("shake");
    void form.offsetWidth; // 重启动画
    form.classList.add("shake");
  }

  /* ---------- 登录提交 ---------- */
  form.addEventListener("submit", e => {
    e.preventDefault();
    const id = idInput.value.trim().toUpperCase();
    const pw = pwInput.value;
    if (!id || !pw) { fail("编号与密钥均不能为空"); return; }

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span>密钥核验中';

    setTimeout(async () => {
      // 联机模式：先等云端账号库拉取完成，再向服务端校验并拉回该账号的全设备存档
      await (window.YG.Sync ? window.YG.Sync.ready : Promise.resolve());
      let user = null;
      if (window.YG.Sync && window.YG.Sync.online) {
        const r = await window.YG.Sync.postLogin(id, pw);
        user = r || null; // 服务端明确拒绝（undefined）→ 失败；网络异常（null）时已由 Sync 内部处理
        if (!user && r === null) user = Users.login(id, pw); // 网络抖动兜底
      } else {
        user = Users.login(id, pw); // 离线降级：仅本机账号
      }
      if (!user) {
        fail("编号或密钥错误，请重试。连续失败将被记录追溯");
        btn.disabled = false;
        btn.textContent = "接入系统";
        return;
      }
      Session.set(user.id);
      btn.innerHTML = '<span class="spinner"></span>核验通过 · 正在接入';
      setTimeout(() => { location.href = "dashboard.html"; }, 650);
    }, 900);
  });
})();

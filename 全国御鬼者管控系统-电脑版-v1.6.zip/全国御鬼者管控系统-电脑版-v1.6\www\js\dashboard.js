/* 主控台 */
(function () {
  "use strict";
  const { Profiles, icon, countUp, toast, esc, badge, rankCls, GameState, Coins, Officials, Disaster } = window.YG;
  const D = window.YG_DATA;
  const me = Profiles.current();
  if (!me) return; // 守卫将触发跳转
  const rank = D.RANKS[me.rankIdx];
  const pts = GameState.points(me.id);
  const nextRank = D.RANKS[me.rankIdx + 1];

  /* ---------- 个人信息卡 ---------- */
  document.getElementById("bigAvatar").textContent = me.name.slice(0, 1);
  document.getElementById("pName").innerHTML =
    `${esc(me.name)} ${badgeRank()}`;
  document.getElementById("pId").textContent = me.id;
  document.getElementById("pRank").textContent = rank.name + ` · ${pts} 积分`;
  const ofNow = Officials.of(me.id);
  document.getElementById("pBureau").textContent = me.bureau + (ofNow ? ` · ${ofNow.name}` : "") + ` · 冥币 ${Coins.get(me.id)} 枚`;

  // 整个个人信息卡可点击 → 跳转个人档案
  const pc = document.getElementById("profileCard");
  pc.style.cursor = "pointer";
  pc.title = "点击查看个人档案";
  pc.addEventListener("click", () => { location.href = "profile-detail.html?id=" + encodeURIComponent(me.id); });

  function badgeRank() {
    const cls = rankCls(me.rankIdx);
    return `<span class="badge ${cls}"><span class="dot"></span>${rank.name}</span>`;
  }

  // 晋升进度条（使用动态晋升门槛，后台可调整）
  if (nextRank) {
    const reqs = GameState.rankReqs();
    const prevPts = reqs[me.rankIdx];
    const need = reqs[nextRank.idx] - prevPts;
    const got = Math.min(pts - prevPts, need);
    const pct = Math.round(got / need * 100);
    const rankEl = document.getElementById("pRank");
    rankEl.innerHTML += `<span style="display:block;margin-top:6px;font-size:11px;color:var(--muted);font-weight:400">
      距「${nextRank.name}」<span class="mono" style="color:var(--cyan)">${pts}/${reqs[nextRank.idx]}</span>
      <span style="display:inline-block;width:110px;height:5px;background:rgba(116,136,155,.2);border-radius:3px;margin-left:8px;vertical-align:middle;overflow:hidden">
        <i style="display:block;height:100%;width:${pct}%;background:linear-gradient(90deg,var(--cyan),var(--gold));box-shadow:0 0 6px var(--cyan)"></i>
      </span></span>`;
  }

  /* ---------- 侵蚀度 ---------- */
  const erosion = me.erosion;
  const box = document.getElementById("erosionBox");
  const bar = document.getElementById("erosionBar");
  const tip = document.getElementById("erosionTip");
  const numEl = document.getElementById("erosionNum");

  setTimeout(() => {
    countUp(numEl, erosion, { duration: 1300 });
    bar.firstElementChild.style.width = erosion + "%";
    if (erosion > 80) {
      box.classList.add("danger");
      bar.classList.add("danger");
      tip.textContent = "侵蚀度极度危险 · 立即停止任务并接受净化";
      tip.style.color = "var(--red)";
    } else if (erosion >= 60) {
      box.classList.add("warn");
      bar.classList.add("warn");
      tip.textContent = "侵蚀度偏高 · 建议尽快使用短效净化剂";
      tip.style.color = "var(--amber)";
    } else {
      tip.textContent = "侵蚀度处于安全区间";
      tip.style.color = "var(--green)";
    }
  }, 350);

  /* ---------- 全局数据卡（真实备案数据统计，与后台管理一致） ---------- */
  const allProfiles = Profiles.all();
  const activeProfiles = allProfiles.filter(p => p.status !== "叛逃");
  // 实时在线：按 5 分钟时间桶确定性波动（在岗率 85%-100%）
  const onlineNow = Math.max(1, Math.round(activeProfiles.length * (0.85 + window.YG.seededRand("online_" + Math.floor(Date.now() / 300000))() * 0.15)));
  // 活跃阴隙：按在野（非封印/沉睡/镇压）鬼怪密度推算
  const activeGhosts = D.GHOSTS.filter(g => !/封印|沉睡|镇压/.test(g.status)).length;
  const riftNum = Math.max(2, Math.ceil(activeGhosts / 4));
  // 累计处置事件：全国备案档案任务数汇总（种子基准 + 个人实际完成，与档案页/后台口径一致）
  const tasksDone = allProfiles.reduce((s, p) => s + GameState.missionsTotal(p.id), 0);
  // 当前最高灾害等级：与灾难预警页共用同一实时数据源（全国节点 30 秒桶波动）
  const worst = Disaster.worst();
  const worstInfo = Disaster.info(worst.lv);
  const stats = [
    { ico: "online", num: onlineNow, suffix: "", lbl: "在线御鬼者", sub: `人 · 全国备案 ${allProfiles.length} 人` },
    { ico: "rift", num: riftNum, suffix: "", lbl: "活跃阴隙", sub: "处 · 按鬼情密度推算" },
    { ico: "task", num: tasksDone, suffix: "", lbl: "累计处置事件", sub: "起 · 全国备案汇总" },
    { ico: "alarm", text: worstInfo.level, lbl: "当前最高灾害等级", sub: `${worst.zone.name} · ${worst.lv >= 5 ? "阴隙大规模开启" : worstInfo.plan}`, alarm: worst.lv >= 4 }
  ];
  document.getElementById("statsRow").innerHTML = stats.map((s, i) => `
    <div class="glass corner stat-card card-hover" style="animation:fadeUp .5s both;animation-delay:${i * 70}ms">
      <div class="ico">${icon(s.ico)}</div>
      <div class="num" id="statNum${i}">${s.text ? "—" : "0"}${s.text ? "" : ""}</div>
      <div class="lbl">${s.lbl}</div>
      ${s.sub ? `<div class="field-error" style="margin:6px 0 0;min-height:0;color:var(--faint);font-size:11.5px;letter-spacing:1px">${s.sub}</div>` : ""}
    </div>
  `).join("");

  stats.forEach((s, i) => {
    if (s.text) {
      const el = document.getElementById("statNum" + i);
      el.textContent = s.text;
      if (s.alarm) el.closest(".stat-card").classList.add("alarm");
    } else {
      countUp(document.getElementById("statNum" + i), s.num, {
        duration: 1300, suffix: " " + s.sub.split(" ")[0]
      });
    }
  });

  /* ---------- 快捷入口 ---------- */
  const quick = [
    { ico: "task", title: "任务大厅", sub: "TASK HALL · 接取灾害任务", href: "tasks.html" },
    { ico: "equip", title: "我的背包", sub: "INVENTORY · 道具与药剂", href: "inventory.html" },
    { ico: "ghost", title: "鬼灵仓库", sub: "GHOST VAULT · 契约鬼灵饲养", href: "ghosts-mine.html" },
    { ico: "coin", title: "冥府商城", sub: "NETHER EXCHANGE · 冥币兑换", href: "shop.html" },
    { ico: "medal", title: "官职竞选", sub: "OFFICIAL POST · 凭资历任职", href: "officials.html" },
    { ico: "ghost", title: "鬼怪图鉴", sub: "GHOST INDEX · 32 条收录", href: "ghosts.html" },
    { ico: "profile", title: "个人档案", sub: `MY PROFILE · ${me.id}`, href: `profile-detail.html?id=${me.id}` }
  ];
  document.getElementById("quickGrid").innerHTML = quick.map((q, i) => `
    <a class="glass corner quick-card card-hover" href="${q.href}"
       style="animation:fadeUp .5s both;animation-delay:${280 + i * 70}ms">
      <div class="ico">${icon(q.ico)}</div>
      <b>${q.title}</b>
      <small>${q.sub}</small>
      <span class="go">${icon("arrow")}</span>
    </a>
  `).join("");
})();

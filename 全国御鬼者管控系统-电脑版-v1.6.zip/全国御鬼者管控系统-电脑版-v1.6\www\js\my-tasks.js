/* 任务记录页 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { esc, badge, missionCls, statusCls, rankCls, ghostLevelCls, TaskState, Profiles, GameState, Erosion, Inventory, Coins, MyGhosts, Officials, Discipline, toast, modal, countUp } = window.YG;

  const me = Profiles.current();
  if (!me) return; // 守卫将触发跳转
  const listEl = document.getElementById("taskList");
  const sumEl = document.getElementById("summaryRow");

  const RATING_BY_LEVEL = { SS: "S", S: "S", A: "A", B: "A", C: "B", D: "B" };
  let currentFilter = "doing"; // 'all' | 'doing' | 'done'

  function allMissions() {
    return D.MISSIONS.concat(GameState.extraMissions(me.id));
  }

  function records() {
    const state = TaskState.all(me.id);
    return Object.keys(state).map(mid => {
      const m = allMissions().find(x => x.id === mid);
      return m ? { m, st: state[mid] } : null;
    }).filter(Boolean).sort((a, b) => (b.st.date || "").localeCompare(a.st.date || ""));
  }

  function renderSummary(recs) {
    const done = recs.filter(r => r.st.status === "已完成");
    const doing = recs.filter(r => r.st.status === "进行中");
    const points = GameState.points(me.id);

    const cards = [
      { lbl: "累计积分", value: points, suffix: " 分", ico: "points", color: "var(--amber)", filter: "all" },
      { lbl: "冥币余额", value: Coins.get(me.id), suffix: " 枚", ico: "coin", color: "var(--gold)", filter: "all" },
      { lbl: "已完成任务", value: done.length, suffix: " 起", ico: "task", color: "var(--cyan)", filter: "done" },
      { lbl: "进行中任务", value: doing.length, suffix: " 起", ico: "bell", color: "var(--green)", filter: "doing" }
    ];
    sumEl.innerHTML = cards.map((c, i) => `
      <div class="glass corner stat-card card-hover" data-filter="${c.filter}"
           style="animation:fadeUp .5s both;animation-delay:${i * 70}ms;cursor:pointer;${currentFilter === c.filter ? "border-color:rgba(232,195,106,.6)" : ""}">
        <div class="ico" style="color:${c.color}">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
            ${c.ico === "points" ? '<circle cx="12" cy="12" r="8"/><path d="M12 8v8M9.5 10.5c0-1 .9-1.7 2.5-1.7s2.5.7 2.5 1.7-.9 1.5-2.5 1.8-2.5.8-2.5 1.8 1 1.7 2.5 1.7 2.5-.7 2.5-1.7"/>' : ""}
            ${c.ico === "task" ? '<path d="M9 3h6a1 1 0 0 1 1 1v1h3v16H5V5h3V4a1 1 0 0 1 1-1Z"/><path d="m9 13 2 2 4-4.5"/>' : ""}
            ${c.ico === "bell" ? '<path d="M18 9a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7"/><path d="M10.5 20a2 2 0 0 0 3 0"/>' : ""}
            ${c.ico === "coin" ? '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><path d="M12 3.5v2M12 18.5v2M3.5 12h2M18.5 12h2"/>' : ""}
          </svg>
        </div>
        <div class="num" id="sumNum${i}" style="color:${c.color}">0</div>
        <div class="lbl">${c.lbl}</div>
      </div>
    `).join("");
    cards.forEach((c, i) => countUp(document.getElementById("sumNum" + i), c.value, { duration: 1000, suffix: c.suffix }));
    sumEl.querySelectorAll("[data-filter]").forEach(el => {
      el.addEventListener("click", () => { currentFilter = el.dataset.filter; render(); });
    });
  }

  function cardHTML(r, i) {
    const { m, st } = r;
    const cls = missionCls(m.level);
    const done = st.status === "已完成";
    return `
      <div class="glass corner task-card card-hover ${cls}" data-id="${m.id}"
           style="animation:fadeUp .45s both;animation-delay:${i * 45}ms">
        <div class="task-rank">${m.level}</div>
        <div>
          <h3>${esc(m.name)}</h3>
          <div class="task-meta">
            <span class="mono">${m.id}</span>
            <span>地点 <b>${esc(m.place)}</b></span>
            <span>领取/完成日期 <b>${st.date || "—"}</b></span>
            ${done ? `<span>完成评级 <b style="color:var(--gold)">${st.rating || "B"}</b></span>` : ""}
          </div>
          <div class="task-desc">${esc(m.desc)}</div>
        </div>
        <div class="task-side">
          <div class="task-points" style="${done ? "" : "color:var(--faint);text-shadow:none"}">${m.points}<small> 积分${done ? "已结算" : ""}</small></div>
          ${done
            ? badge("st-已完成", "已完成")
            : `<button class="btn btn-primary btn-sm" data-act="complete" data-id="${m.id}">提交完成</button>`}
        </div>
      </div>`;
  }

  function render() {
    const allRecs = records();
    renderSummary(allRecs);
    const recs = allRecs.filter(r =>
      currentFilter === "all" ? true :
      currentFilter === "done" ? r.st.status === "已完成" :
      r.st.status === "进行中"
    );
    const encHtml = pendingEncounter ? encounterBannerHTML(pendingEncounter) : "";
    const filterName = { all: "全部任务", doing: "进行中任务", done: "已完成任务" }[currentFilter];
    listEl.innerHTML = encHtml + (recs.length
      ? recs.map(cardHTML).join("")
      : `<div class="glass empty" style="border-radius:14px;padding:60px 20px">
          暂无${filterName}<br><br>
          <a href="tasks.html" class="btn btn-primary btn-sm">前往任务大厅接取任务</a>
        </div>`);
  }

  // 机缘：鬼怪现身 → 卡片内嵌决策（不弹遮罩窗，避免黑屏闪烁）
  let pendingEncounter = null;
  function encounterBannerHTML(g) {
    const cls = ghostLevelCls(g.level);
    const limit = MyGhosts.limit(me.id);
    const cur = MyGhosts.all(me.id).list.length;
    const full = cur >= limit;
    return `
      <div class="glass corner task-card card-hover" id="encCard" style="border-color:rgba(232,195,106,.55)">
        <div class="task-rank" style="color:var(--gold)">缘</div>
        <div>
          <h3>✦ 机缘 · 鬼怪现身 ✦</h3>
          <div class="task-meta">
            <span><b>${esc(g.name)}</b></span>
            ${badge(cls, g.level)} ${badge(statusCls(g.status), g.status)}
            <span>契约容量 <b class="${full ? "" : "text-cyan"}" style="${full ? "color:var(--red)" : ""}">${cur} / ${limit}</b>${full ? "（已满，可先解约）" : ""}</span>
          </div>
          <div class="task-desc">任务现场的鬼怪被你的战力折服，愿意与你签订契约。</div>
        </div>
        <div class="task-side">
          <button class="btn btn-primary btn-sm" data-enc="yes" ${full ? "disabled style='opacity:.45;cursor:not-allowed'" : ""}>签订契约</button>
          <button class="btn btn-ghost btn-sm" data-enc="no" style="margin-top:8px">放其离开</button>
        </div>
      </div>`;
  }

  // 完成结算：侵蚀上升 → 冥币结算 → 机缘掉落 → 晋升检测 → 任务池刷新
  function settleMission(m) {
    // 侵蚀度上升（按任务等级）
    const erosionUp = { D: 3, C: 6, B: 12, A: 20, S: 35, SS: 50 }[m.level] || 5;
    Erosion.add(me.id, erosionUp);

    // 殉职判定：侵蚀度突破 90% 直接销户
    if (Discipline.checkDeath(me.id)) {
      return { dead: true };
    }

    // 冥币奖励（阴司通货，按任务等级发放 + 官职加成）
    const of = Officials.of(me.id);
    const coinGain = (D.MISSION_COIN_REWARD[m.level] || 20) + Math.floor(Math.random() * 10) + (of ? of.coinBonus : 0);
    Coins.add(me.id, coinGain);

    // 总局嘉奖令附加奖励（后台发布的冥币/装备/鬼怪）
    let extraReward = null;
    if (m.rewards) {
      extraReward = { coins: 0, items: [], ghost: null, ghostFull: null };
      if (m.rewards.coins) { Coins.add(me.id, m.rewards.coins); extraReward.coins = m.rewards.coins; }
      (m.rewards.items || []).forEach(it => {
        Inventory.add(me.id, it.id, it.n || 1);
        const eq = D.EQUIPMENTS.find(e => e.id === it.id);
        if (eq) extraReward.items.push(`${eq.name}×${it.n || 1}`);
      });
      if (m.rewards.ghostId) {
        const g = D.GHOSTS.find(x => x.id === m.rewards.ghostId);
        if (g) {
          if (MyGhosts.add(me.id, g.id)) extraReward.ghost = g;
          else extraReward.ghostFull = g; // 仓库已满或重复契约
        }
      }
    }

    // 机缘掉落（B 级以上概率掉落净化剂）
    const rnd = Math.random();
    let drop = null;
    if ((m.level === "B" && rnd < 0.4) || (m.level === "A" && rnd < 0.7) || (m.level === "S" || m.level === "SS")) {
      drop = "EQ013";
      Inventory.add(me.id, "EQ013", 1);
    } else if (m.level === "C" && rnd < 0.2) {
      drop = "EQ014";
      Inventory.add(me.id, "EQ014", 1);
    } else if (rnd < 0.12) {
      // 低概率机缘：阴灵口粮
      drop = "EQ016";
      Inventory.add(me.id, "EQ016", 1);
    }

    // 机缘：鬼怪现身（可选择契约）
    let encounter = null;
    const chance = D.MISSION_CONTRACT_CHANCE[m.level] || 0;
    if (Math.random() < chance) {
      const myIds = new Set(MyGhosts.all(me.id).list.map(g => g.gid));
      const rankIdx = GameState.effectiveRankIdx(me.id);
      // 只能契约不超过自身等级 1 阶以内的鬼怪（等级低不会遇到高等级怪物）
      const pool = D.GHOSTS.filter(g => {
        const order = (D.GHOST_LEVELS.find(l => l.name === g.level) || {}).order || 0;
        return order <= Math.min(rankIdx + 1, 7) && !myIds.has(g.id);
      });
      if (pool.length) encounter = pool[Math.floor(Math.random() * pool.length)];
    }

    // 晋升检测
    const promo = GameState.checkPromotion(me.id);

    // 任务全部完成 → 自动刷新新任务
    const newMissions = GameState.refreshMissionsIfNeeded(me.id);

    return { erosionUp, coinGain, drop, encounter, promo, newMissions, extraReward };
  }

  // 晋升提示（不弹遮罩窗，改用金色 toast 通报）
  function notifyPromo(promo) {
    toast({
      level: "gold", icon: "medal", title: "晋升仪式 · 授衔",
      text: `${promo.old.name} → ${promo.now.name}，权限范围已更新`
    });
  }

  listEl.addEventListener("click", e => {
    // 机缘卡片内嵌决策
    const encBtn = e.target.closest("[data-enc]");
    if (encBtn && pendingEncounter) {
      e.stopPropagation();
      const g = pendingEncounter;
      pendingEncounter = null;
      if (encBtn.dataset.enc === "yes") {
        if (MyGhosts.add(me.id, g.id)) {
          toast({ level: "green", icon: "ghost", title: "契约达成", text: `「${g.name}」已入住鬼灵仓库，记得定期喂养` });
          const promo2 = GameState.checkPromotion(me.id);
          if (promo2 && !promo2.blocked) setTimeout(() => notifyPromo(promo2), 400);
        } else {
          toast({ level: "amber", icon: "alarm", title: "契约失败", text: "契约容量已达上限或重复契约" });
        }
      } else {
        toast({ level: "cyan", icon: "ghost", title: "已放其离开", text: `「${g.name}」消散于阴隙之中` });
      }
      render();
      return;
    }

    const completeBtn = e.target.closest('[data-act="complete"]');
    const card = e.target.closest(".task-card");
    if (!card) return;
    const m = allMissions().find(x => x.id === card.dataset.id);
    if (!m) return; // 机缘决策卡等非任务卡片

    if (completeBtn) {
      e.stopPropagation();
      const rating = RATING_BY_LEVEL[m.level] || "B";
      completeBtn.disabled = true;
      completeBtn.textContent = "核验中";
      // 直接结算，全程无遮罩弹窗（仅 toast 通报），避免黑屏闪烁
      TaskState.complete(me.id, m.id, rating);
      const r = settleMission(m);

      // 殉职：侵蚀度 ≥90% 销户，直接跳转登录页（登录页展示殉职原因）
      if (r.dead) {
        toast({ level: "red", icon: "alarm", title: "殉职 · 魂归阴司", text: "侵蚀度突破 90%，账号已注销，档案封存", force: 1200 });
        setTimeout(() => { location.href = "index.html?err=dead"; }, 1300);
        return;
      }
      // 晋升授衔（罕见关键事件，保留金色通报）；契约门槛未满足则提示受阻
      if (r.promo && !r.promo.blocked) {
        notifyPromo(r.promo);
      } else if (r.promo && r.promo.blocked) {
        toast({
          level: "amber", icon: "alarm",
          title: "晋升受阻 · 契约未达标",
          text: `积分已满足晋升「${r.promo.target.name}」，需先契约 ${r.promo.need} 级及以上鬼灵（任务机缘中可遇）`
        });
      }
      // 其余结算（积分/冥币/掉落/嘉奖/新任务）一律静默，无任何消息提醒
      if (r.encounter) {
        // 机缘：仅在列表顶部内嵌抉择卡片，不弹提醒
        pendingEncounter = r.encounter;
      }
      render();
      return;
    }

    // 点击任务卡片其他区域：不弹窗、不提醒
  });

  render();
})();

/* 鬼怪图鉴列表 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { esc, icon, ghostLevelCls, statusCls, badge } = window.YG;

  const grid = document.getElementById("ghostGrid");
  const search = document.getElementById("searchInput");
  const chipsBox = document.getElementById("levelChips");
  let activeLevel = "全部";

  /* ---------- 等级筛选 chips ---------- */
  const levels = ["全部"].concat(D.GHOST_LEVELS.map(l => l.name));
  chipsBox.innerHTML = levels.map(l => {
    if (l === "全部") return `<button class="chip active" data-level="全部">${l}</button>`;
    const lv = D.GHOST_LEVELS.find(x => x.name === l);
    return `<button class="chip" data-level="${l}">
      <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${lv.color};box-shadow:0 0 7px ${lv.color};margin-right:7px;vertical-align:1px"></span>${l}</button>`;
  }).join("");

  chipsBox.addEventListener("click", e => {
    const btn = e.target.closest(".chip");
    if (!btn) return;
    chipsBox.querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
    btn.classList.add("active");
    activeLevel = btn.dataset.level;
    render();
  });

  search.addEventListener("input", render);

  /* ---------- 渲染 ---------- */
  const { MyGhosts, Profiles } = window.YG;
  const me = Profiles.current();
  const ownedIds = () => new Set(me ? MyGhosts.all(me.id).list.map(mg => mg.gid) : []);

  function cardHTML(g, i) {
    const cls = ghostLevelCls(g.level);
    const isKing = g.level === "鬼王";
    const owned = ownedIds().has(g.id);
    return `
      <div class="glass corner ghost-card card-hover ${cls} ${isKing ? "king" : ""}"
           data-id="${g.id}" style="animation-delay:${i * 45}ms">
        <img class="ghost-img" src="${g.img}" alt="${esc(g.name)}" loading="lazy">
        <div class="top">
          <div class="ghost-rune">${esc(g.rune)}</div>
          <div>
            <h3>${esc(g.name)}</h3>
            <div class="code">${g.id} · NATIONAL ARCHIVE</div>
          </div>
        </div>
        <div class="desc">${esc(g.ability)}</div>
        <div class="foot">
          <span>${badge(cls, g.level)}</span>
          ${owned ? badge("st-已完成", "已契约") : badge(statusCls(g.status), g.status)}
        </div>
      </div>`;
  }

  function render() {
    const kw = search.value.trim();
    const list = D.GHOSTS.filter(g =>
      (activeLevel === "全部" || g.level === activeLevel) &&
      (!kw || g.name.includes(kw))
    );
    grid.style.opacity = "0";
    setTimeout(() => {
      grid.innerHTML = list.length
        ? list.map(cardHTML).join("")
        : `<div class="empty">${icon("search")}<br><br>未检索到匹配的鬼怪档案</div>`;
      grid.style.opacity = "1";
    }, 120);
  }
  grid.style.transition = "opacity .18s";

  grid.addEventListener("click", e => {
    const card = e.target.closest(".ghost-card");
    if (card) location.href = "ghost-detail.html?id=" + encodeURIComponent(card.dataset.id);
  });

  render();
})();

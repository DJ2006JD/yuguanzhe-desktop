/* 冥府商城 */
(function () {
  "use strict";
  const D = window.YG_DATA;
  const { esc, icon, Profiles, Inventory, Coins, FeatureLock, toast, modal } = window.YG;

  const me = Profiles.current();
  if (!me) return;
  if (!FeatureLock.guardPage("shop", "冥府商城")) return;
  const grid = document.getElementById("shopGrid");
  const coinNum = document.getElementById("coinNum");

  function renderCoin() {
    coinNum.textContent = Coins.get(me.id);
  }

  function render() {
    renderCoin();
    grid.innerHTML = D.SHOP_ITEMS.map((s, i) => {
      const eq = D.EQUIPMENTS.find(e => e.id === s.id);
      if (!eq) return "";
      const eff = D.ITEM_EFFECTS[s.id];
      const afford = Coins.get(me.id) >= s.price;
      return `
        <div class="glass corner equip-card card-hover" style="animation:fadeUp .4s both;animation-delay:${i * 55}ms">
          <div class="top">
            <div class="equip-ico">${icon("cat-" + eq.category)}</div>
            <div>
              <h3>${esc(eq.name)} ${s.tag ? `<span class="badge" style="color:var(--gold);font-size:10.5px"><span class="dot"></span>${s.tag}</span>` : ""}</h3>
              <div class="code">${eq.id} · ${esc(eq.category)}</div>
            </div>
          </div>
          <p>${esc(eq.func)}</p>
          ${eff ? `<p style="color:var(--green);font-size:12.5px;margin-top:6px">${esc(eff.desc)}</p>` : ""}
          <p style="color:var(--muted);font-size:12px;margin-top:4px">${esc(s.blurb)}</p>
          <div class="tags" style="margin-top:12px;display:flex;gap:8px;align-items:center">
            <span style="color:var(--gold);font-weight:700" class="mono">${s.price} 冥币</span>
            <button class="btn btn-primary btn-sm" data-buy="${s.id}" style="margin-left:auto"
              ${afford ? "" : "disabled style='opacity:.45;cursor:not-allowed'"}>${afford ? "兑换" : "冥币不足"}</button>
          </div>
        </div>`;
    }).join("");
  }

  grid.addEventListener("click", e => {
    const btn = e.target.closest("[data-buy]");
    if (!btn || btn.disabled) return;
    const s = D.SHOP_ITEMS.find(x => x.id === btn.dataset.buy);
    const eq = D.EQUIPMENTS.find(x => x.id === s.id);
    // 直接兑换，不弹确认窗（按钮已显示价格，余额不足时按钮为禁用态）
    btn.disabled = true;
    if (!Coins.spend(me.id, s.price)) {
      btn.disabled = false;
      toast({ level: "red", icon: "alarm", title: "冥币不足", text: "请前往任务大厅完成任务赚取冥币" });
      return;
    }
    Inventory.add(me.id, s.id, 1);
    toast({ level: "green", icon: "check", title: "兑换成功", text: `「${eq.name}」×1 已放入背包，冥币 -${s.price}` });
    render();
  });

  render();
})();
